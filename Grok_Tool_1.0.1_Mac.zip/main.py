from __future__ import annotations

import sys
from pathlib import Path

from PyQt6.QtCore import Qt, pyqtSignal, QThread
from PyQt6.QtGui import QFont, QAction
from PyQt6.QtWidgets import (
    QDialog,
    QApplication,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QProgressBar,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView,
    QCheckBox,
)

from grok_workers import (
    GrokCreateImageWorker,
    GrokTextToVideoWorker,
    GrokImageToVideoWorker,
    GrokRefImageWorker,
    GrokUpdateUsageWorker,
)
from grok_chrome_manager import open_profile_chrome, resolve_profile_dir
from theme import COLORS, STYLESHEET
from result_table import ResultTable
import grok_account_manager


if getattr(sys, 'frozen', False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT = str(APP_DIR / "downloads")
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}


def section_title(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("sectionTitle")
    return lbl


def hint(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("hint")
    lbl.setWordWrap(True)
    return lbl


class DropZone(QLabel):
    dropped = pyqtSignal(list)

    def __init__(self, placeholder: str, parent=None):
        super().__init__(parent)
        self._placeholder = placeholder
        self.setObjectName("dropzone")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setAcceptDrops(True)
        self.setMinimumHeight(82)
        self.setWordWrap(True)
        self.setText(placeholder)
        self.setProperty("filled", "false")

    def _restyle(self, active=False):
        self.setProperty("active", "true" if active else "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def set_filled(self, text: str):
        self.setText(text)
        self.setProperty("filled", "true")
        self.style().unpolish(self)
        self.style().polish(self)

    def set_image(self, file_path: str):
        if not file_path:
            self.reset()
            return
        p = Path(file_path)
        if p.exists():
            from PyQt6.QtGui import QPixmap
            pix = QPixmap(str(p))
            if not pix.isNull():
                pix_scaled = pix.scaled(140, 140, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                self.setPixmap(pix_scaled)
                self.setProperty("filled", "true")
                self.setToolTip(file_path)
                self.style().unpolish(self)
                self.style().polish(self)
                return
        self.setText(f"❌ Lỗi ảnh:\n{p.name}")
        self.setProperty("filled", "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def reset(self):
        from PyQt6.QtGui import QPixmap
        self.setPixmap(QPixmap())
        self.setText(self._placeholder)
        self.setProperty("filled", "false")
        self.setToolTip("")
        self.style().unpolish(self)
        self.style().polish(self)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._restyle(True)

    def dragLeaveEvent(self, e):
        self._restyle(False)

    def dropEvent(self, e):
        self._restyle(False)
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.toLocalFile()]
        if paths:
            self.dropped.emit(paths)


def make_config_row(items):
    row = QHBoxLayout()
    row.setSpacing(10)
    for label, widget in items:
        if label:
            row.addWidget(QLabel(label))
        row.addWidget(widget)
    row.addStretch(1)
    return row


class FfmpegDownloadThread(QThread):
    progress = pyqtSignal(int)
    finished_success = pyqtSignal(str)
    finished_error = pyqtSignal(str)
    
    def __init__(self, dest_path):
        super().__init__()
        self.dest_path = dest_path
        self.is_cancelled = False
        
    def run(self):
        import urllib.request
        import zipfile
        import io
        from pathlib import Path
        
        try:
            url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                total_size = int(response.info().get('Content-Length', 0))
                downloaded = 0
                chunk_size = 1024 * 64
                data_buffer = io.BytesIO()
                
                while not self.is_cancelled:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    data_buffer.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = int((downloaded / total_size) * 100)
                        self.progress.emit(percent)
                        
                if self.is_cancelled:
                    return
                    
                self.progress.emit(99)
                
                data_buffer.seek(0)
                with zipfile.ZipFile(data_buffer) as z:
                    ffmpeg_member = None
                    for name in z.namelist():
                        if name.endswith("ffmpeg.exe"):
                            ffmpeg_member = name
                            break
                            
                    if ffmpeg_member:
                        Path(self.dest_path).parent.mkdir(parents=True, exist_ok=True)
                        with z.open(ffmpeg_member) as source, open(self.dest_path, "wb") as target:
                            target.write(source.read())
                        self.finished_success.emit(str(self.dest_path))
                    else:
                        self.finished_error.emit("Không tìm thấy tệp ffmpeg.exe trong file nén tải về.")
        except Exception as e:
            self.finished_error.emit(str(e))


class FfmpegDownloaderDialog(QDialog):
    def __init__(self, dest_path, parent=None):
        super().__init__(parent)
        from PyQt6.QtWidgets import QLabel, QProgressBar, QPushButton, QVBoxLayout
        self.setWindowTitle("Tải FFMPEG tự động")
        self.setFixedSize(380, 130)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)
        
        layout = QVBoxLayout(self)
        self.lbl = QLabel("Đang kết nối để tải thư viện FFMPEG (khoảng 35MB)...")
        self.lbl.setWordWrap(True)
        layout.addWidget(self.lbl)
        
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        layout.addWidget(self.bar)
        
        self.btn_cancel = QPushButton("Hủy")
        self.btn_cancel.clicked.connect(self.cancel_download)
        layout.addWidget(self.btn_cancel, 0, Qt.AlignmentFlag.AlignRight)
        
        self.thread = FfmpegDownloadThread(dest_path)
        self.thread.progress.connect(self.on_progress)
        self.thread.finished_success.connect(self.on_success)
        self.thread.finished_error.connect(self.on_error)
        
        self.success = False
        self.thread.start()
        
    def on_progress(self, val):
        self.bar.setValue(val)
        self.lbl.setText(f"Đang tải thư viện: {val}%...")
        
    def on_success(self, path):
        self.success = True
        QMessageBox.information(self, "Tải thành công", "Thư viện FFMPEG đã được cài đặt thành công!")
        self.accept()
        
    def on_error(self, err):
        QMessageBox.critical(self, "Lỗi tải thư viện", f"Không thể tải FFMPEG tự động:\n{err}\n\nVui lòng tải thủ công.")
        self.reject()
        
    def cancel_download(self):
        self.thread.is_cancelled = True
        self.thread.wait()
        self.reject()
        
    def closeEvent(self, event):
        self.cancel_download()
        super().closeEvent(event)


class BaseTab(QWidget):
    MODE = ""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker = None

    def _download_ffmpeg_ui(self, dest_path: Path) -> bool:
        dlg = FfmpegDownloaderDialog(dest_path, self)
        dlg.exec()
        return dlg.success

    def _make_output_row(self):
        out = QHBoxLayout()
        out.setSpacing(8)
        out.addWidget(QLabel("📁 Lưu vào:"))
        self.output_dir = QLineEdit(DEFAULT_OUTPUT)
        out.addWidget(self.output_dir, 1)
        btn = QPushButton("Chọn...")
        btn.clicked.connect(self._choose_dir)
        out.addWidget(btn)
        return out

    def _make_run_buttons(self, run_text="▶  Bắt đầu"):
        btns = QHBoxLayout()
        btns.setSpacing(10)
        self.btn_run = QPushButton(run_text)
        self.btn_run.setObjectName("primary")
        self.btn_run.setMinimumHeight(42)
        self.btn_run.clicked.connect(self._start)
        self.btn_stop = QPushButton("■  Dừng")
        self.btn_stop.setObjectName("danger")
        self.btn_stop.setMinimumHeight(42)
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self._stop)
        btns.addWidget(self.btn_run, 2)
        btns.addWidget(self.btn_stop, 1)
        return btns

    def _make_result_table(self, show_video_tools=True):
        self.results = ResultTable(mode_label=self.MODE, show_video_tools=show_video_tools)
        self.results.edit_prompt.connect(self._on_edit_prompt)
        self.results.retry_selected.connect(self._on_retry_selected)
        self.results.retry_failed.connect(self._on_retry_failed)
        self.results.clear_results.connect(self._on_clear_results)
        self.results.merge_videos.connect(self._on_merge_videos)
        self.results.cut_last_frame.connect(self._on_cut_last_frame)
        return self.results

    def _make_log(self):
        self.log = QPlainTextEdit()
        self.log.setObjectName("log")
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(120)
        return self.log

    def _choose_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Chọn thư mục lưu", self.output_dir.text() or DEFAULT_OUTPUT)
        if d:
            self.output_dir.setText(d)

    def _append_log(self, msg: str):
        self.log.appendPlainText(str(msg))
        sb = self.log.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _on_status(self, payload):
        pid = str(payload.get("prompt_id") or "")
        if "status_text" in payload:
            self.results.set_status(pid, text=str(payload["status_text"]))
        elif "progress" in payload:
            self.results.set_status(pid, progress=int(payload["progress"]))

    def _on_done(self, payload):
        pid = str(payload.get("_prompt_id") or "")
        path = str(payload.get("video_path") or "")
        self.results.set_media(pid, path)

    def _on_complete(self):
        self.btn_run.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self._worker = None
        self._append_log("━━━━━━ Hoàn tất ━━━━━━")

        # Cập nhật lại bảng cài đặt
        win = self.window()
        if win and hasattr(win, "settings_tab"):
            try:
                win.settings_tab._refresh_table()
            except Exception:
                pass

        # Kiểm tra nếu tất cả tài khoản hết lượt
        import grok_account_manager
        if grok_account_manager.all_profiles_rate_limited():
            QMessageBox.critical(
                self,
                "Hết tài khoản khả dụng",
                "Tất cả các tài khoản đăng nhập đều đã báo HẾT LƯỢT tạo ảnh/video!\n\n"
                "👉 Vui lòng mở tab 'Cài đặt' để thêm tài khoản mới hoặc click chọn một tài khoản rồi bấm 'Khôi phục lượt dùng'!"
            )

    def _stop(self):
        if self._worker is not None:
            self._append_log("🛑 Đang dừng...")
            self._worker.stop()
            self.btn_stop.setEnabled(False)

    def _wire_worker(self):
        self._worker.log_message.connect(self._append_log)
        self._worker.status_updated.connect(self._on_status)
        self._worker.video_updated.connect(self._on_done)
        self._worker.automation_complete.connect(self._on_complete)
        self.btn_run.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self._worker.start()

    # ----- signal handlers từ ResultTable -----
    def _on_edit_prompt(self, row: int):
        cur = self.results.get_prompt(row)
        text, ok = QInputDialog.getMultiLineText(self, "Sửa prompt", "Nội dung prompt:", cur)
        if ok:
            self.results.set_prompt(row, text.strip())

    def _on_retry_selected(self, rows: list):
        if not rows:
            QMessageBox.information(self, "Tạo lại", "Hãy tích chọn ít nhất 1 dòng để tạo lại.")
            return
        self._start(only_rows=rows)

    def _on_retry_failed(self):
        rows = self.results.failed_rows()
        if not rows:
            QMessageBox.information(self, "Tạo lại lỗi", "Không có dòng nào bị lỗi.")
            return
        self._start(only_rows=rows)

    def _on_clear_results(self):
        self.results.set_rows([])

    def _on_merge_videos(self, rows: list):
        import tempfile
        import subprocess
        import shutil
        import os
        from result_table import open_in_explorer

        # 1. Lấy danh sách tệp video được chọn
        paths = []
        for r in rows:
            p = self.results.get_video_path(r)
            if p and Path(p).is_file():
                paths.append(str(Path(p).resolve()))
                
        if len(paths) < 2:
            QMessageBox.warning(self, "Nối video", "Vui lòng chọn từ 2 video trở lên để nối!")
            return
            
        # 2. Tìm ffmpeg
        ffmpeg_bin = None
        ffmpeg_name = "ffmpeg.exe" if sys.platform == "win32" else "ffmpeg"
        local_ffmpeg = APP_DIR / ffmpeg_name
        if local_ffmpeg.is_file():
            ffmpeg_bin = str(local_ffmpeg)
        else:
            if getattr(sys, 'frozen', False):
                exe_ffmpeg = Path(sys.executable).resolve().parent / ffmpeg_name
                if exe_ffmpeg.is_file():
                    ffmpeg_bin = str(exe_ffmpeg)
            
            if not ffmpeg_bin:
                import shutil
                sys_ffmpeg = shutil.which("ffmpeg")
                if sys_ffmpeg:
                    ffmpeg_bin = sys_ffmpeg
                    
        if not ffmpeg_bin:
            if sys.platform != "win32":
                QMessageBox.critical(
                    self,
                    "Thiếu thư viện FFMPEG",
                    "Tính năng nối video cần thư viện FFMPEG.\n\n"
                    "Vui lòng mở Terminal và cài đặt bằng lệnh:\n"
                    "brew install ffmpeg"
                )
                return
            
            reply = QMessageBox.question(
                self, 
                "Thiếu thư viện FFMPEG", 
                "Tính năng nối video cần thư viện 'ffmpeg.exe'.\n\n"
                "Bạn có muốn Tool tự động tải và cài đặt (khoảng 35MB) không?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                target_dest = APP_DIR / ffmpeg_name
                success = self._download_ffmpeg_ui(target_dest)
                if success and target_dest.is_file():
                    ffmpeg_bin = str(target_dest)
                else:
                    return
            else:
                return
            
        # 3. Chọn đường dẫn lưu file kết quả
        first_dir = str(Path(paths[0]).parent)
        out_path, _ = QFileDialog.getSaveFileName(
            self, "Lưu video nối", str(Path(first_dir) / "merged.mp4"), "Video (*.mp4 *.mov *.avi)"
        )
        if not out_path:
            return
            
        # 4. Viết file tạm list input cho ffmpeg concat demuxer
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
                temp_txt = f.name
                for p in paths:
                    p_esc = p.replace("\\", "/")
                    f.write(f"file '{p_esc}'\n")
                    
            # 5. Chạy lệnh ffmpeg concat copy (cực nhanh, không mã hóa lại)
            cmd = [ffmpeg_bin, "-y", "-f", "concat", "-safe", "0", "-i", temp_txt, "-c", "copy", out_path]
            
            startupinfo = None
            if sys.platform.startswith("win"):
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                
            res = subprocess.run(cmd, capture_output=True, text=True, startupinfo=startupinfo)
            
            try:
                os.unlink(temp_txt)
            except Exception:
                pass
                
            if res.returncode == 0:
                reply = QMessageBox.question(
                    self, "Thành công", "Nối video thành công!\nBạn có muốn mở thư mục chứa video không?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if reply == QMessageBox.StandardButton.Yes:
                    open_in_explorer(out_path)
            else:
                QMessageBox.critical(self, "Lỗi nối video", f"ffmpeg báo lỗi:\n{res.stderr}")
                
        except Exception as e:
            QMessageBox.critical(self, "Lỗi hệ thống", f"Không thể nối video:\n{e}")

    def _on_cut_last_frame(self, rows: list):
        import subprocess
        import shutil
        from result_table import open_in_explorer

        # 1. Lấy danh sách tệp video
        paths = []
        for r in rows:
            p = self.results.get_video_path(r)
            if p and Path(p).is_file():
                paths.append(str(Path(p).resolve()))
                
        if not paths:
            QMessageBox.warning(self, "Cắt ảnh cuối", "Vui lòng chọn ít nhất 1 video để cắt ảnh cuối!")
            return
            
        # 2. Tìm ffmpeg
        ffmpeg_bin = None
        ffmpeg_name = "ffmpeg.exe" if sys.platform == "win32" else "ffmpeg"
        local_ffmpeg = APP_DIR / ffmpeg_name
        if local_ffmpeg.is_file():
            ffmpeg_bin = str(local_ffmpeg)
        else:
            if getattr(sys, 'frozen', False):
                exe_ffmpeg = Path(sys.executable).resolve().parent / ffmpeg_name
                if exe_ffmpeg.is_file():
                    ffmpeg_bin = str(exe_ffmpeg)
            
            if not ffmpeg_bin:
                import shutil
                sys_ffmpeg = shutil.which("ffmpeg")
                if sys_ffmpeg:
                    ffmpeg_bin = sys_ffmpeg
                    
        if not ffmpeg_bin:
            if sys.platform != "win32":
                QMessageBox.critical(
                    self,
                    "Thiếu thư viện FFMPEG",
                    "Tính năng cắt ảnh cuối cần thư viện FFMPEG.\n\n"
                    "Vui lòng mở Terminal và cài đặt bằng lệnh:\n"
                    "brew install ffmpeg"
                )
                return
            
            reply = QMessageBox.question(
                self, 
                "Thiếu thư viện FFMPEG", 
                "Tính năng cắt ảnh cuối cần thư viện 'ffmpeg.exe'.\n\n"
                "Bạn có muốn Tool tự động tải và cài đặt (khoảng 35MB) không?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                target_dest = APP_DIR / ffmpeg_name
                success = self._download_ffmpeg_ui(target_dest)
                if success and target_dest.is_file():
                    ffmpeg_bin = str(target_dest)
                else:
                    return
            else:
                return
            
        # 3. Tiến hành cắt ảnh cuối cho từng video
        success_count = 0
        error_msgs = []
        
        startupinfo = None
        if sys.platform.startswith("win"):
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            
        for p in paths:
            pp = Path(p)
            out_img = str(pp.parent / f"{pp.stem}_last_frame.png")
            # sseof -0.1 seek tới 0.1 giây cuối của video
            cmd = [ffmpeg_bin, "-y", "-sseof", "-0.1", "-i", p, "-update", "1", "-q:v", "2", "-frames:v", "1", out_img]
            try:
                res = subprocess.run(cmd, capture_output=True, text=True, startupinfo=startupinfo)
                if res.returncode == 0 and Path(out_img).is_file():
                    success_count += 1
                else:
                    error_msgs.append(f"{pp.name}: {res.stderr or 'Lỗi không xác định'}")
            except Exception as e:
                error_msgs.append(f"{pp.name}: {e}")
                
        if success_count > 0:
            msg = f"Đã cắt ảnh cuối thành công cho {success_count}/{len(paths)} video!"
            if error_msgs:
                msg += "\n\nMột số file bị lỗi:\n" + "\n".join(error_msgs)
            QMessageBox.information(self, "Thành công", msg)
            try:
                open_in_explorer(str(Path(paths[0]).parent))
            except Exception:
                pass
        else:
            QMessageBox.critical(self, "Lỗi cắt ảnh cuối", "Không thể cắt ảnh cuối cho video nào!\n\nChi tiết:\n" + "\n".join(error_msgs))

    def _start(self, only_rows=None):
        raise NotImplementedError


class CreateImageTab(BaseTab):
    MODE = "GROK - Tạo ảnh"

    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(0)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left Panel (Inputs & Controls)
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(6, 6, 12, 6)
        left_layout.setSpacing(12)

        left_layout.addWidget(section_title("🎨  Tạo ảnh từ prompt"))
        left_layout.addWidget(hint("Mỗi dòng là 1 prompt → tạo ra 1 (hoặc nhiều) ảnh."))

        self.prompts = QPlainTextEdit()
        self.prompts.setPlaceholderText(
            "Một con mèo đeo kính đọc sách trong quán cà phê, ánh sáng ấm\n"
            "Cảnh hoàng hôn trên biển, phong cách cinematic, 4K"
        )
        self.prompts.setMinimumHeight(150)
        left_layout.addWidget(self.prompts)

        self.aspect = QComboBox(); self.aspect.addItems(["1:1", "16:9", "9:16", "4:3", "3:4", "2:3", "3:2"])
        self.image_count = QSpinBox(); self.image_count.setRange(1, 4); self.image_count.setValue(2)
        self.concurrency = QSpinBox(); self.concurrency.setRange(1, 5); self.concurrency.setValue(3)
        self.upscale = QComboBox(); self.upscale.addItems(["Không nâng cấp", "2K (Ultra HD - AI)", "4K (Ultra HD - AI)"])
        left_layout.addLayout(make_config_row([
            ("🖼 Tỷ lệ:", self.aspect),
            ("🔢 Số ảnh/prompt:", self.image_count),
            ("⚡ Luồng:", self.concurrency),
        ]))
        left_layout.addLayout(make_config_row([
            ("✨ Nâng cấp AI:", self.upscale),
        ]))

        left_layout.addLayout(self._make_output_row())
        left_layout.addLayout(self._make_run_buttons("▶  Tạo ảnh"))
        left_layout.addStretch(1)

        # Right Panel (Results & Logs)
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(12, 6, 6, 6)
        right_layout.setSpacing(12)

        right_layout.addWidget(self._make_result_table(show_video_tools=False), 1)
        right_layout.addWidget(self._make_log())

        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 6)
        splitter.setSizes([420, 580])

        root.addWidget(splitter)

    def _get_prompts(self):
        raw = self.prompts.toPlainText() or ""
        return [ln.strip() for ln in raw.replace("\r\n", "\n").split("\n") if ln.strip()]

    def _start(self, only_rows=None):
        if self._worker is not None:
            return
        if only_rows:
            prompts = [self.results.get_prompt(r) for r in only_rows]
            ids = [str(r + 1) for r in only_rows]
        else:
            prompts = self._get_prompts()
            if not prompts:
                QMessageBox.warning(self, "Thiếu prompt", "Hãy nhập ít nhất 1 prompt.")
                return
            ids = [str(i + 1) for i in range(len(prompts))]
            self.results.set_rows([{"id": ids[i], "prompt": prompts[i], "mode": self.MODE}
                                   for i in range(len(prompts))])
        # Check if upscaler is required
        if "AI" in self.upscale.currentText():
            from grok_upscaler import ensure_realesrgan_installed
            if not ensure_realesrgan_installed(self):
                return

        self._worker = GrokCreateImageWorker(
            prompts=prompts, prompt_ids=ids,
            aspect_ratio=self.aspect.currentText(),
            image_count=self.image_count.value(),
            output_dir=self.output_dir.text().strip() or DEFAULT_OUTPUT,
            max_concurrency=self.concurrency.value(),
            offscreen_chrome=False,
            upscale_mode=self.upscale.currentText(),
        )
        self._wire_worker()


class TextToVideoTab(BaseTab):
    MODE = "GROK - Tạo video từ văn bản"

    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(0)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left Panel (Inputs & Controls)
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(6, 6, 12, 6)
        left_layout.setSpacing(12)

        left_layout.addWidget(section_title("🎬  Tạo video từ văn bản"))
        left_layout.addWidget(hint("Mỗi dòng là 1 prompt → tạo ra 1 video."))

        self.prompts = QPlainTextEdit()
        self.prompts.setPlaceholderText(
            "Một con chó chạy trên bãi biển lúc hoàng hôn, cinematic\n"
            "Drone bay qua thành phố ban đêm, đèn neon rực rỡ"
        )
        self.prompts.setMinimumHeight(150)
        left_layout.addWidget(self.prompts)

        self.aspect = QComboBox(); self.aspect.addItems(["9:16", "16:9"])
        self.length = QComboBox(); self.length.addItems(["6", "10", "15"])
        self.resolution = QComboBox(); self.resolution.addItems(["480p", "720p"])
        self.concurrency = QSpinBox(); self.concurrency.setRange(1, 5); self.concurrency.setValue(3)

        self.retry_on_fail = QCheckBox("Tự động tạo lại video lỗi/timeout")
        self.retry_on_fail.setChecked(True)
        self.retry_limit = QSpinBox(); self.retry_limit.setRange(1, 10); self.retry_limit.setValue(3)
        self.upscale = QComboBox(); self.upscale.addItems(["Không nâng cấp", "1080p (Full HD - AI)", "2K (Ultra HD - AI)", "4K (Ultra HD - AI)"])

        left_layout.addLayout(make_config_row([
            ("🖼 Tỷ lệ:", self.aspect),
            ("⏱ Độ dài (s):", self.length),
            ("📺 Phân giải:", self.resolution),
            ("⚡ Luồng:", self.concurrency),
        ]))
        left_layout.addLayout(make_config_row([
            ("", self.retry_on_fail),
            ("Số lần:", self.retry_limit),
            ("✨ Nâng cấp AI:", self.upscale),
        ]))

        left_layout.addLayout(self._make_output_row())
        left_layout.addLayout(self._make_run_buttons("▶  Tạo video"))
        left_layout.addStretch(1)

        # Right Panel (Results & Logs)
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(12, 6, 6, 6)
        right_layout.setSpacing(12)

        right_layout.addWidget(self._make_result_table(show_video_tools=True), 1)
        right_layout.addWidget(self._make_log())

        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 6)
        splitter.setSizes([420, 580])

        root.addWidget(splitter)

    def _get_prompts(self):
        raw = self.prompts.toPlainText() or ""
        return [ln.strip() for ln in raw.replace("\r\n", "\n").split("\n") if ln.strip()]

    def _start(self, only_rows=None):
        if self._worker is not None:
            return
        # Kiểm tra tải bộ nâng cấp AI nếu chọn nâng cấp
        upscale_mode = self.upscale.currentText()
        if "AI" in upscale_mode:
            from grok_upscaler import ensure_realesrgan_installed
            if not ensure_realesrgan_installed(self):
                return
        if only_rows:
            prompts = [self.results.get_prompt(r) for r in only_rows]
            ids = [self.results.table.item(r, 1).text() for r in only_rows]
        else:
            prompts = self._get_prompts()
            if not prompts:
                QMessageBox.warning(self, "Thiếu prompt", "Hãy nhập ít nhất 1 prompt.")
                return
            current_count = self.results.table.rowCount()
            ids = [str(current_count + i + 1) for i in range(len(prompts))]
            self.results.add_rows([{"id": ids[i], "prompt": prompts[i], "mode": self.MODE}
                                   for i in range(len(prompts))])
        
        max_retries = self.retry_limit.value() if self.retry_on_fail.isChecked() else 0
        self._worker = GrokTextToVideoWorker(
            prompts=prompts, prompt_ids=ids,
            aspect_ratio=self.aspect.currentText(),
            video_length_seconds=int(self.length.currentText()),
            resolution_name=self.resolution.currentText(),
            output_dir=self.output_dir.text().strip() or DEFAULT_OUTPUT,
            max_concurrency=self.concurrency.value(),
            offscreen_chrome=False,
            max_job_retries=max_retries,
            upscale_mode=self.upscale.currentText(),
        )
        self._wire_worker()


def make_thumbnail_widget(image_path: str) -> QWidget:
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(2, 2, 2, 2)
    lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
    
    lbl = QLabel()
    lbl.setFixedSize(54, 54)
    
    if not image_path:
        lbl.setText("Trống")
        lbl.setStyleSheet("color: #6b7280; font-size: 11px; border: 1.5px dashed #4b5563; border-radius: 6px; background: #111827;")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
    else:
        p = Path(image_path)
        if p.exists():
            from PyQt6.QtGui import QPixmap
            pix = QPixmap(str(p))
            if not pix.isNull():
                pix_scaled = pix.scaled(50, 50, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                lbl.setPixmap(pix_scaled)
                lbl.setStyleSheet("border: 1px solid #374151; border-radius: 6px; background: #111827;")
                lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            else:
                lbl.setText("Lỗi")
                lbl.setStyleSheet("color: #ef4444; font-size: 11px; border: 1px solid #374151; border-radius: 6px; background: #111827;")
                lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        else:
            lbl.setText("Mất file")
            lbl.setStyleSheet("color: #f97316; font-size: 11px; border: 1px solid #374151; border-radius: 6px; background: #111827;")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            
    lay.addWidget(lbl)
    return w


def make_file_action_widget(image_path: str, on_change_callback) -> QWidget:
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(6, 2, 6, 2)
    lay.setSpacing(6)
    
    if image_path:
        name = Path(image_path).name
        tooltip = image_path
        color = "#e5e7eb"
    else:
        name = "(Chưa chọn ảnh)"
        tooltip = "Hãy bấm Chọn/Đổi ảnh để thêm ảnh"
        color = "#9ca3af"
        
    name_lbl = QLabel(name)
    name_lbl.setToolTip(tooltip)
    name_lbl.setStyleSheet(f"font-weight: bold; color: {color};")
    
    btn_change = QPushButton("Chọn" if not image_path else "Đổi")
    btn_change.setFixedWidth(50)
    btn_change.setCursor(Qt.CursorShape.PointingHandCursor)
    btn_change.setStyleSheet("""
        QPushButton {
            background-color: #374151;
            color: #f3f4f6;
            border-radius: 6px;
            padding: 3px 8px;
            font-size: 11px;
            border: 1px solid #4b5563;
        }
        QPushButton:hover {
            background-color: #4b5563;
            border: 1px solid #6b7280;
        }
    """)
    btn_change.clicked.connect(on_change_callback)
    
    lay.addWidget(name_lbl, 1)
    lay.addWidget(btn_change)
    return w


def make_delete_button_widget(on_delete_callback) -> QWidget:
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(2, 2, 2, 2)
    lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
    
    btn_del = QPushButton("❌")
    btn_del.setFixedSize(28, 28)
    btn_del.setCursor(Qt.CursorShape.PointingHandCursor)
    btn_del.setStyleSheet("""
        QPushButton {
            background-color: #7f1d1d;
            color: #fca5a5;
            border-radius: 6px;
            border: none;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #b91c1c;
            color: #ffffff;
        }
    """)
    btn_del.clicked.connect(on_delete_callback)
    
    lay.addWidget(btn_del)
    return w


class JobTableWidget(QTableWidget):
    dropped_files = pyqtSignal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setColumnCount(5)
        self.setHorizontalHeaderLabels([
            "STT",
            "Ảnh",
            "Tên tệp / Đổi ảnh",
            "Prompt (Nhấp gõ chữ trực tiếp)",
            "Xóa"
        ])
        self.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        self.setColumnWidth(1, 74)
        self.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setAcceptDrops(True)
        self.verticalHeader().setDefaultSectionSize(64)
        self.verticalHeader().setVisible(False)
        self.setStyleSheet("""
            QTableWidget {
                background-color: #1f2937;
                border: 1px solid #374151;
                border-radius: 8px;
                gridline-color: #374151;
            }
            QHeaderView::section {
                background-color: #111827;
                color: #9ca3af;
                padding: 6px;
                font-weight: bold;
                border: 1px solid #374151;
            }
        """)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.toLocalFile()]
        if paths:
            self.dropped_files.emit(paths)



class ImageToVideoTab(BaseTab):
    MODE = "GROK - Tạo video từ Ảnh"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._jobs = []

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(0)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left Panel (Inputs & Controls)
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(6, 6, 12, 6)
        left_layout.setSpacing(12)

        left_layout.addWidget(section_title("🖼  Tạo video từ ảnh"))
        left_layout.addWidget(hint(
            "Thêm danh sách ảnh và nhập prompt tương ứng để tạo video.<br>"
            "• Bạn có thể **kéo thả trực tiếp tệp ảnh** hoặc file prompt (txt/excel) vào bảng.<br>"
            "• Gõ prompt trực tiếp vào cột Prompt hoặc nạp từ file Excel/Txt."
        ))

        # Toolbar
        toolbar = QHBoxLayout()
        toolbar.setSpacing(8)
        
        self.btn_add_imgs = QPushButton("➕  Thêm ảnh...")
        self.btn_add_imgs.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_add_imgs.clicked.connect(self._choose_images)
        toolbar.addWidget(self.btn_add_imgs)
        
        self.btn_import = QPushButton("📂  Nhập file (TXT/Excel)...")
        self.btn_import.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_import.clicked.connect(self._choose_prompt_file)
        toolbar.addWidget(self.btn_import)
        
        self.btn_clear = QPushButton("❌  Xóa tất cả")
        self.btn_clear.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_clear.clicked.connect(self._on_clear_results)
        toolbar.addWidget(self.btn_clear)
        
        left_layout.addLayout(toolbar)

        # Job Table
        self.table_jobs = JobTableWidget()
        self.table_jobs.dropped_files.connect(self._on_drop_files)
        left_layout.addWidget(self.table_jobs, 1)

        self.aspect = QComboBox(); self.aspect.addItems(["9:16", "16:9"])
        self.length = QComboBox(); self.length.addItems(["6", "10", "15"])
        self.resolution = QComboBox(); self.resolution.addItems(["480p", "720p"])
        self.concurrency = QSpinBox(); self.concurrency.setRange(1, 5); self.concurrency.setValue(3)

        self.retry_on_fail = QCheckBox("Tự động tạo lại video lỗi/timeout")
        self.retry_on_fail.setChecked(True)
        self.retry_limit = QSpinBox(); self.retry_limit.setRange(1, 10); self.retry_limit.setValue(3)
        self.upscale = QComboBox(); self.upscale.addItems(["Không nâng cấp", "1080p (Full HD - AI)", "2K (Ultra HD - AI)", "4K (Ultra HD - AI)"])

        left_layout.addLayout(make_config_row([
            ("🖼 Tỷ lệ:", self.aspect),
            ("⏱ Độ dài (s):", self.length),
            ("📺 Phân giải:", self.resolution),
            ("⚡ Luồng:", self.concurrency),
        ]))
        left_layout.addLayout(make_config_row([
            ("", self.retry_on_fail),
            ("Số lần:", self.retry_limit),
            ("✨ Nâng cấp AI:", self.upscale),
        ]))

        left_layout.addLayout(self._make_output_row())
        left_layout.addLayout(self._make_run_buttons("▶  Tạo video"))

        # Right Panel (Results & Logs)
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(12, 6, 6, 6)
        right_layout.setSpacing(12)

        right_layout.addWidget(self._make_result_table(show_video_tools=True), 1)
        right_layout.addWidget(self._make_log())

        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setStretchFactor(0, 5)
        splitter.setStretchFactor(1, 5)
        splitter.setSizes([450, 550])

        root.addWidget(splitter)

    def _add_images(self, paths):
        for p in paths:
            pp = Path(p)
            if pp.is_dir():
                for f in sorted(pp.iterdir()):
                    if f.suffix.lower() in IMAGE_EXTS:
                        self._jobs.append({"image_path": str(f), "prompt": ""})
            elif pp.suffix.lower() in IMAGE_EXTS:
                self._jobs.append({"image_path": str(pp), "prompt": ""})
        self._update_table_ui()
        self._rebuild_preview()

    def _on_drop_files(self, paths):
        image_paths = []
        doc_paths = []
        for p in paths:
            pp = Path(p)
            if pp.is_dir() or pp.suffix.lower() in IMAGE_EXTS:
                image_paths.append(p)
            elif pp.suffix.lower() in {".txt", ".csv", ".xlsx"}:
                doc_paths.append(p)
                
        if image_paths:
            self._add_images(image_paths)
        if doc_paths:
            self._load_doc_file(doc_paths[0])

    def _choose_images(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Chọn ảnh", "", "Ảnh (*.png *.jpg *.jpeg *.webp *.gif *.bmp)")
        if files:
            self._add_images(files)

    def _choose_prompt_file(self):
        f, _ = QFileDialog.getOpenFileName(
            self, 
            "Chọn file nạp prompt", 
            "", 
            "File dữ liệu (*.txt *.csv *.xlsx);;Text (*.txt);;CSV (*.csv);;Excel (*.xlsx)"
        )
        if f:
            self._load_doc_file(f)

    def _load_doc_file(self, path_str):
        p = Path(path_str)
        if not p.exists():
            return
            
        ext = p.suffix.lower()
        try:
            if ext == ".txt":
                txt = p.read_text(encoding="utf-8", errors="ignore")
                prompts = [ln.strip() for ln in txt.replace("\r\n", "\n").split("\n") if ln.strip()]
                self._import_only_prompts(prompts)
            elif ext == ".csv":
                import csv
                prompts_with_images = []
                with open(p, "r", encoding="utf-8", errors="ignore") as f:
                    reader = csv.reader(f)
                    for r in reader:
                        if not r:
                            continue
                        img = r[0].strip() if len(r) > 0 else ""
                        prm = r[1].strip() if len(r) > 1 else ""
                        if img or prm:
                            # Resolve relative path if needed
                            res_img = self._resolve_relative_image(img, p.parent)
                            prompts_with_images.append((res_img, prm))
                self._import_pairs(prompts_with_images)
            elif ext == ".xlsx":
                import openpyxl
                wb = openpyxl.load_workbook(str(p), read_only=True)
                sheet = wb.active
                prompts_with_images = []
                for r in sheet.iter_rows(values_only=True):
                    if not r:
                        continue
                    img = str(r[0] or "").strip() if len(r) > 0 else ""
                    prm = str(r[1] or "").strip() if len(r) > 1 else ""
                    if img or prm:
                        res_img = self._resolve_relative_image(img, p.parent)
                        prompts_with_images.append((res_img, prm))
                wb.close()
                self._import_pairs(prompts_with_images)
        except Exception as e:
            QMessageBox.critical(self, "Lỗi đọc file", f"Không thể đọc file dữ liệu:\n{e}")

    def _resolve_relative_image(self, img_path_str, base_dir):
        if not img_path_str:
            return ""
        p = Path(img_path_str)
        if p.is_absolute() and p.exists():
            return str(p)
        p2 = base_dir / img_path_str
        if p2.exists():
            return str(p2)
        # Fallback to absolute/original if not found
        return img_path_str

    def _import_only_prompts(self, prompts):
        if not prompts:
            return
        # Nếu đã có sẵn ảnh trong bảng, cập nhật prompt cho các ảnh đó
        for i in range(max(len(self._jobs), len(prompts))):
            if i < len(self._jobs):
                if i < len(prompts):
                    self._jobs[i]["prompt"] = prompts[i]
            else:
                self._jobs.append({"image_path": "", "prompt": prompts[i]})
        self._update_table_ui()
        self._rebuild_preview()

    def _import_pairs(self, pairs):
        if not pairs:
            return
        # Nạp đè hoặc thêm vào bảng
        reply = QMessageBox.question(
            self, 
            "Lựa chọn nạp dữ liệu", 
            "Bạn có muốn XÓA danh sách hiện tại trước khi nạp dữ liệu mới không?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel
        )
        if reply == QMessageBox.StandardButton.Cancel:
            return
        if reply == QMessageBox.StandardButton.Yes:
            self._jobs.clear()
            
        for img, prm in pairs:
            self._jobs.append({"image_path": img, "prompt": prm})
            
        self._update_table_ui()
        self._rebuild_preview()

    def _update_table_ui(self):
        self.table_jobs.blockSignals(True)
        self.table_jobs.setRowCount(len(self._jobs))
        for i, job in enumerate(self._jobs):
            # 0. STT
            stt_item = QTableWidgetItem(str(i + 1))
            stt_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            stt_item.setFlags(stt_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.table_jobs.setItem(i, 0, stt_item)
            
            # 1. Thumbnail
            self.table_jobs.setCellWidget(i, 1, make_thumbnail_widget(job["image_path"]))
            
            # 2. File Action/Change
            self.table_jobs.setCellWidget(
                i, 2, 
                make_file_action_widget(
                    job["image_path"], 
                    lambda checked, idx=i: self._change_image_at(idx)
                )
            )
            
            # 3. Prompt Line Edit
            prompt_edit = QLineEdit(job["prompt"])
            prompt_edit.setPlaceholderText("Gõ prompt cho ảnh này ở đây...")
            prompt_edit.setStyleSheet("""
                QLineEdit {
                    background-color: #111827;
                    border: 1.5px solid #374151;
                    border-radius: 6px;
                    padding: 4px 8px;
                    color: #f3f4f6;
                }
                QLineEdit:focus {
                    border: 1.5px solid #3b82f6;
                }
            """)
            prompt_edit.textChanged.connect(lambda text, idx=i: self._on_prompt_changed(idx, text))
            self.table_jobs.setCellWidget(i, 3, prompt_edit)
            
            # 4. Delete Action
            self.table_jobs.setCellWidget(
                i, 4, 
                make_delete_button_widget(
                    lambda checked, idx=i: self._delete_row_at(idx)
                )
            )
            
        self.table_jobs.blockSignals(False)

    def _on_prompt_changed(self, idx, text):
        if 0 <= idx < len(self._jobs):
            self._jobs[idx]["prompt"] = text
            self._rebuild_preview()

    def _delete_row_at(self, idx):
        if 0 <= idx < len(self._jobs):
            self._jobs.pop(idx)
            self._update_table_ui()
            self._rebuild_preview()

    def _change_image_at(self, idx):
        if not (0 <= idx < len(self._jobs)):
            return
        f, _ = QFileDialog.getOpenFileName(
            self, "Chọn ảnh mới", "", "Ảnh (*.png *.jpg *.jpeg *.webp *.gif *.bmp)")
        if f:
            self._jobs[idx]["image_path"] = f
            self._update_table_ui()
            self._rebuild_preview()

    def _pairs(self):
        return self._jobs

    def _rebuild_preview(self):
        pairs = self._pairs()
        rows = []
        for i, it in enumerate(pairs):
            img_name = Path(it['image_path']).name if it['image_path'] else "(Chưa chọn ảnh)"
            label = f"{img_name} | {it['prompt'] or '(không prompt)'}"
            rows.append({"id": str(i + 1), "prompt": label, "mode": self.MODE})
        self.results.set_rows(rows)

    def _on_clear_results(self):
        self._jobs.clear()
        self.table_jobs.setRowCount(0)
        self.results.set_rows([])

    def _start(self, only_rows=None):
        if self._worker is not None:
            return
        # Kiểm tra tải bộ nâng cấp AI nếu chọn nâng cấp
        upscale_mode = self.upscale.currentText()
        if "AI" in upscale_mode:
            from grok_upscaler import ensure_realesrgan_installed
            if not ensure_realesrgan_installed(self):
                return
        pairs = self._pairs()
        if not pairs:
            QMessageBox.warning(self, "Thiếu dữ liệu", "Hãy thêm ít nhất 1 ảnh để tạo video.")
            return
            
        # Kiểm tra xem có hàng nào thiếu ảnh không
        for idx, item in enumerate(pairs):
            if not item.get("image_path"):
                QMessageBox.warning(self, "Thiếu ảnh", f"Dòng số {idx + 1} chưa chọn ảnh đầu vào. Vui lòng chọn ảnh trước khi chạy.")
                return

        if only_rows:
            pairs = [pairs[r] for r in only_rows if 0 <= r < len(pairs)]
            ids = [str(r + 1) for r in only_rows]
        else:
            self._rebuild_preview()
            ids = [str(i + 1) for i in range(len(pairs))]

        max_retries = self.retry_limit.value() if self.retry_on_fail.isChecked() else 0
        self._worker = GrokImageToVideoWorker(
            items=pairs, prompt_ids=ids,
            aspect_ratio=self.aspect.currentText(),
            video_length_seconds=int(self.length.currentText()),
            resolution_name=self.resolution.currentText(),
            output_dir=self.output_dir.text().strip() or DEFAULT_OUTPUT,
            max_concurrency=self.concurrency.value(),
            offscreen_chrome=False,
            max_job_retries=max_retries,
            upscale_mode=self.upscale.currentText(),
        )
        self._wire_worker()



class OutfitSwapperTab(BaseTab):
    MODE = "GROK - Ghép Trang Phục"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._char_image = ""
        self._outfit_image = ""

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(0)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left Panel (Inputs & Controls)
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(6, 6, 12, 6)
        left_layout.setSpacing(12)

        left_layout.addWidget(section_title("👗  Ghép Trang Phục 6 Góc"))
        left_layout.addWidget(hint(
            "Kéo-thả (hoặc chọn) <b>ảnh nhân vật</b> và <b>ảnh trang phục</b>.<br>"
            "Tool tự động tạo ra 6 ảnh với 6 góc chụp khác nhau."
        ))

        zones = QHBoxLayout()
        zones.setSpacing(10)

        char_box = QVBoxLayout(); char_box.setSpacing(6)
        self.drop_char = DropZone("👤\nKéo-thả ảnh NHÂN VẬT")
        self.drop_char.setMinimumHeight(150)
        self.drop_char.dropped.connect(self._on_drop_char)
        char_box.addWidget(self.drop_char)
        btn_char = QPushButton("Chọn nhân vật...")
        btn_char.clicked.connect(self._choose_char)
        char_box.addWidget(btn_char)
        zones.addLayout(char_box)

        outfit_box = QVBoxLayout(); outfit_box.setSpacing(6)
        self.drop_outfit = DropZone("👚\nKéo-thả ảnh TRANG PHỤC")
        self.drop_outfit.setMinimumHeight(150)
        self.drop_outfit.dropped.connect(self._on_drop_outfit)
        outfit_box.addWidget(self.drop_outfit)
        btn_outfit = QPushButton("Chọn trang phục...")
        btn_outfit.clicked.connect(self._choose_outfit)
        outfit_box.addWidget(btn_outfit)
        zones.addLayout(outfit_box)

        left_layout.addLayout(zones)

        left_layout.addWidget(QLabel(" Ghi chú / Yêu cầu chung (Ví dụ: màu sắc, bỏ mũ...):"))
        self.common_prompt = QPlainTextEdit()
        self.common_prompt.setPlaceholderText(
            "Ví dụ: tone màu hồng pastel chủ đạo, không đội mũ, chất lượng studio ảnh chụp quảng cáo..."
        )
        self.common_prompt.setMaximumHeight(80)
        self.common_prompt.textChanged.connect(self._on_common_prompt_changed)
        left_layout.addWidget(self.common_prompt)

        self.aspect = QComboBox(); self.aspect.addItems(["3:4", "1:1", "16:9", "9:16", "4:3", "2:3", "3:2"])
        self.concurrency = QSpinBox(); self.concurrency.setRange(1, 5); self.concurrency.setValue(3)
        self.upscale = QComboBox(); self.upscale.addItems(["Không nâng cấp", "2K (Ultra HD - AI)", "4K (Ultra HD - AI)"])
        left_layout.addLayout(make_config_row([
            ("🖼 Tỷ lệ:", self.aspect),
            ("⚡ Luồng song song:", self.concurrency),
        ]))
        left_layout.addLayout(make_config_row([
            ("✨ Nâng cấp AI:", self.upscale),
        ]))

        left_layout.addLayout(self._make_output_row())
        left_layout.addLayout(self._make_run_buttons("▶  Ghép trang phục"))
        left_layout.addStretch(1)

        # Right Panel (Results & Logs)
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(12, 6, 6, 6)
        right_layout.setSpacing(12)

        right_layout.addWidget(self._make_result_table(show_video_tools=False), 1)
        right_layout.addWidget(self._make_log())

        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 6)
        splitter.setSizes([420, 580])

        root.addWidget(splitter)

    def _on_drop_char(self, paths):
        imgs = [p for p in paths if Path(p).suffix.lower() in IMAGE_EXTS]
        if imgs:
            self._char_image = imgs[0]
            self._refresh_zones()
            self._rebuild_preview(clear_state=True)

    def _choose_char(self):
        f, _ = QFileDialog.getOpenFileName(
            self, "Chọn ảnh nhân vật", "", "Ảnh (*.png *.jpg *.jpeg *.webp *.gif *.bmp)")
        if f:
            self._char_image = f
            self._refresh_zones()
            self._rebuild_preview(clear_state=True)

    def _on_drop_outfit(self, paths):
        imgs = [p for p in paths if Path(p).suffix.lower() in IMAGE_EXTS]
        if imgs:
            self._outfit_image = imgs[0]
            self._refresh_zones()
            self._rebuild_preview(clear_state=True)

    def _choose_outfit(self):
        f, _ = QFileDialog.getOpenFileName(
            self, "Chọn ảnh trang phục", "", "Ảnh (*.png *.jpg *.jpeg *.webp *.gif *.bmp)")
        if f:
            self._outfit_image = f
            self._refresh_zones()
            self._rebuild_preview(clear_state=True)

    def _refresh_zones(self):
        if self._char_image:
            self.drop_char.set_image(self._char_image)
        else:
            self.drop_char.reset()
        if self._outfit_image:
            self.drop_outfit.set_image(self._outfit_image)
        else:
            self.drop_outfit.reset()

    def _get_default_prompt(self, idx: int) -> str:
        ANGLES = [
            ("truoc_1", "front view, full body shot, standing straight"),
            ("truoc_2", "slight front three-quarters angle view, full body shot"),
            ("ben_1", "left side profile view, full body shot"),
            ("ben_2", "right side profile view, full body shot"),
            ("sau_1", "back view, full body shot, standing straight"),
            ("sau_2", "back three-quarters angle view, full body shot"),
        ]
        if not (0 <= idx < len(ANGLES)):
            return ""
        code, desc = ANGLES[idx]
        prm = f"A high-quality full-body fashion photograph of the character from reference image 1, wearing the exact same outfit shown in reference image 2. Camera angle: {desc}."
        common = self.common_prompt.toPlainText().strip()
        if common:
            prm += f" Additional requirements: {common}."
        return prm

    def _on_common_prompt_changed(self):
        # Khi yêu cầu chung thay đổi, tự động tạo lại danh sách prompt mặc định
        self._rebuild_preview()

    def _rebuild_preview(self, clear_state: bool = False):
        rows = []
        for i in range(6):
            prm = self._get_default_prompt(i)
            rows.append({"id": str(i + 1), "prompt": prm, "mode": self.MODE})
        self.results.set_rows(rows, clear_state=clear_state)

    def _on_clear_results(self):
        self._char_image = ""
        self._outfit_image = ""
        self.common_prompt.blockSignals(True)
        self.common_prompt.clear()
        self.common_prompt.blockSignals(False)
        self.results.set_rows([])
        self._refresh_zones()

    def _start(self, only_rows=None):
        if self._worker is not None:
            return
        if not self._char_image or not self._outfit_image:
            QMessageBox.warning(self, "Thiếu ảnh", "Hãy chọn cả ảnh nhân vật và ảnh trang phục.")
            return

        # Chỉ khởi tạo lại danh sách prompt mặc định nếu bảng đang hoàn toàn trống
        if self.results.table.rowCount() == 0:
            self._rebuild_preview()

        # Check if upscaler is required
        if "AI" in self.upscale.currentText():
            from grok_upscaler import ensure_realesrgan_installed
            if not ensure_realesrgan_installed(self):
                return

        # Đọc danh sách prompt hiện tại từ kết quả hiển thị (có thể chứa prompt đã sửa đổi)
        custom_prompts = []
        for r in range(self.results.table.rowCount()):
            custom_prompts.append(self.results.get_prompt(r))

        run_indices = None
        if only_rows:
            run_indices = only_rows

        self._worker = GrokRefImageWorker(
            char_image_path=self._char_image,
            outfit_image_path=self._outfit_image,
            common_prompt=self.common_prompt.toPlainText().strip(),
            aspect_ratio=self.aspect.currentText(),
            output_dir=self.output_dir.text().strip() or DEFAULT_OUTPUT,
            max_concurrency=self.concurrency.value(),
            offscreen_chrome=False,
            upscale_mode=self.upscale.currentText(),
            custom_prompts=custom_prompts,
            run_indices=run_indices,
        )
        self._worker.status_updated.connect(self._on_status)
        self._worker.video_updated.connect(self._on_done)
        self._worker.automation_complete.connect(self._on_complete)
        self._worker.log_message.connect(self._append_log)
        self.btn_run.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self._worker.start()
class TableLineEdit(QLineEdit):
    def __init__(self, text, row_idx, table, parent=None):
        super().__init__(text, parent)
        self.row_idx = row_idx
        self.table = table
        
    def focusInEvent(self, event):
        super().focusInEvent(event)
        try:
            self.table.selectRow(self.row_idx)
        except Exception:
            pass

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        event.accept()

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        event.accept()

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        event.accept()

    def mouseDoubleClickEvent(self, event):
        super().mouseDoubleClickEvent(event)
        self.selectAll()
        # Tự động copy vào bộ nhớ đệm khi nhấp đúp chuột
        clipboard = QApplication.clipboard()
        if clipboard:
            clipboard.setText(self.text())

class SettingsTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Bố cục chính chia làm 2 phần: Bảng danh sách bên trái, Các nút điều khiển bên phải
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(14)
        root.addWidget(section_title("⚙  Cài đặt & Đăng nhập đa tài khoản"))

        content_layout = QHBoxLayout()
        content_layout.setSpacing(14)

        # 1. Bảng danh sách tài khoản (Trái)
        self.table_profiles = QTableWidget()
        self.table_profiles.setColumnCount(5)
        self.table_profiles.setHorizontalHeaderLabels([
            "Tên tài khoản (Profile)",
            "Tài khoản (Email)",
            "Mật khẩu",
            "Hạn mức sử dụng",
            "Trạng thái hoạt động"
        ])
        self.table_profiles.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table_profiles.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table_profiles.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table_profiles.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table_profiles.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table_profiles.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table_profiles.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table_profiles.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table_profiles.itemSelectionChanged.connect(self._on_selection_changed)
        content_layout.addWidget(self.table_profiles, 7)

        # 2. Bảng các nút điều khiển (Phải)
        right_panel = QWidget()
        right_panel.setObjectName("card")
        rl = QVBoxLayout(right_panel)
        rl.setContentsMargins(14, 14, 14, 14)
        rl.setSpacing(10)

        rl.addWidget(QLabel("<b>Thao tác tài khoản:</b>"))
        
        self.btn_login = QPushButton("🌐  Đăng nhập Chrome")
        self.btn_login.setObjectName("primary")
        self.btn_login.setMinimumHeight(38)
        self.btn_login.clicked.connect(self._open_login)
        rl.addWidget(self.btn_login)

        self.btn_update_usage = QPushButton("📊  Cập nhật hạn mức")
        self.btn_update_usage.setMinimumHeight(34)
        self.btn_update_usage.clicked.connect(self._update_profile_usage_clicked)
        rl.addWidget(self.btn_update_usage)

        self.btn_add = QPushButton("➕  Thêm tài khoản")
        self.btn_add.setMinimumHeight(34)
        self.btn_add.clicked.connect(self._add_profile)
        rl.addWidget(self.btn_add)

        self.btn_delete = QPushButton("❌  Xóa tài khoản")
        self.btn_delete.setMinimumHeight(34)
        self.btn_delete.clicked.connect(self._delete_profile)
        rl.addWidget(self.btn_delete)

        self.btn_reset = QPushButton("🔄  Reset trạng thái")
        self.btn_reset.setMinimumHeight(34)
        self.btn_reset.clicked.connect(self._reset_profiles)
        rl.addWidget(self.btn_reset)
        
        rl.addStretch(1)
        content_layout.addWidget(right_panel, 3)

        root.addLayout(content_layout, 1)

        # Log log hiển thị tiến độ hoặc lỗi
        self.login_log = QPlainTextEdit()
        self.login_log.setObjectName("log")
        self.login_log.setReadOnly(True)
        self.login_log.setMaximumHeight(100)
        root.addWidget(self.login_log)

        # Dòng liên kết hỗ trợ Zalo & Group hướng dẫn
        support_layout = QHBoxLayout()
        support_layout.setContentsMargins(0, 4, 0, 4)
        support_layout.setSpacing(14)
        
        btn_acc = QPushButton("💬  Cấp tài khoản AI (Zalo)")
        btn_acc.setMinimumHeight(32)
        btn_acc.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_acc.setStyleSheet("""
            QPushButton {
                background-color: #2563eb;
                color: #ffffff;
                border-radius: 6px;
                font-weight: bold;
                padding: 6px 12px;
                font-size: 12px;
                border: none;
            }
            QPushButton:hover {
                background-color: #1d4ed8;
            }
        """)
        import webbrowser
        btn_acc.clicked.connect(lambda: webbrowser.open("https://zalo.me/g/qdnhrq213"))
        
        btn_guide = QPushButton("📖  Hướng dẫn sử dụng Tool (Zalo)")
        btn_guide.setMinimumHeight(32)
        btn_guide.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_guide.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                color: #ffffff;
                border-radius: 6px;
                font-weight: bold;
                padding: 6px 12px;
                font-size: 12px;
                border: none;
            }
            QPushButton:hover {
                background-color: #047857;
            }
        """)
        btn_guide.clicked.connect(lambda: webbrowser.open("https://zalo.me/g/uewifyd3hbt2vedxxvdq"))
        
        support_layout.addWidget(btn_acc)
        support_layout.addWidget(btn_guide)
        root.addLayout(support_layout)

        ver = QLabel("Tool Grok Độc V05-07  •  Đa tài khoản & Tự động xoay vòng")
        ver.setObjectName("hint")
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(ver)

        self._refresh_table()

    def _on_credentials_changed(self, profile_name: str, email: str | None, password: str | None):
        for r in range(self.table_profiles.rowCount()):
            item = self.table_profiles.item(r, 0)
            if item and item.data(Qt.ItemDataRole.UserRole) == profile_name:
                email_edit = self.table_profiles.cellWidget(r, 1)
                pass_edit = self.table_profiles.cellWidget(r, 2)
                # Password field has a widget holder, get lineedit inside layout
                if isinstance(pass_edit, QWidget):
                    pass_edit = pass_edit.findChild(QLineEdit)
                if isinstance(email_edit, QLineEdit) and isinstance(pass_edit, QLineEdit):
                    grok_account_manager.update_profile_credentials(
                        profile_name,
                        email_edit.text(),
                        pass_edit.text()
                    )
                break

    def _refresh_table(self):
        self.table_profiles.setRowCount(0)
        profiles = grok_account_manager.get_profiles()
        active_prof = grok_account_manager.get_active_profile()
        prof_info = grok_account_manager.load_profiles_info()
        
        # Đọc dữ liệu hạn mức từ cache
        import json
        usage_cache = {}
        cache_file = APP_DIR / "grok_cache.json"
        if cache_file.is_file():
            try:
                with open(cache_file, "r", encoding="utf-8") as f:
                    cache_data = json.load(f)
                    usage_cache = cache_data.get("profiles", {})
            except Exception:
                pass
        
        for p in profiles:
            row = self.table_profiles.rowCount()
            self.table_profiles.insertRow(row)
            
            # Tên profile
            display_name = p
            if p == active_prof:
                display_name += "  ★ (Đang dùng)"
            name_item = QTableWidgetItem(display_name)
            name_item.setData(Qt.ItemDataRole.UserRole, p)
            self.table_profiles.setItem(row, 0, name_item)
            
            # Tài khoản (Email)
            p_data = prof_info.get(p, {})
            email = p_data.get("email") or ""
            email_edit = TableLineEdit(email, row, self.table_profiles)
            email_edit.setPlaceholderText("Nhập email...")
            email_edit.setStyleSheet("background: transparent; border: none; padding: 0px; color: #e8e6f5;")
            email_edit.textChanged.connect(lambda txt, prof=p: self._on_credentials_changed(prof, txt, None))
            self.table_profiles.setCellWidget(row, 1, email_edit)
            
            # Mật khẩu
            password = p_data.get("password") or ""
            pass_edit = TableLineEdit(password, row, self.table_profiles)
            pass_edit.setPlaceholderText("Nhập mật khẩu...")
            pass_edit.setEchoMode(QLineEdit.EchoMode.Password)
            pass_edit.setStyleSheet("background: transparent; border: none; padding: 0px; color: #e8e6f5;")
            pass_edit.textChanged.connect(lambda txt, prof=p: self._on_credentials_changed(prof, None, txt))
            
            # Layout mật khẩu + nút ẩn hiện kế bên
            pass_holder = QWidget()
            pass_layout = QHBoxLayout(pass_holder)
            pass_layout.setContentsMargins(4, 0, 4, 0)
            pass_layout.setSpacing(4)
            pass_layout.addWidget(pass_edit, 1)
            
            btn_show = QPushButton("👁")
            btn_show.setFixedSize(20, 20)
            btn_show.setCursor(Qt.CursorShape.PointingHandCursor)
            btn_show.setStyleSheet("background: transparent; border: none; padding: 0px; font-size: 14px; color: #fbbf24; font-weight: bold;")
            
            def make_toggle_callback(edit=pass_edit, btn=btn_show):
                def toggle():
                    if edit.echoMode() == QLineEdit.EchoMode.Password:
                        edit.setEchoMode(QLineEdit.EchoMode.Normal)
                        btn.setText("🔒")
                    else:
                        edit.setEchoMode(QLineEdit.EchoMode.Password)
                        btn.setText("👁")
                return toggle
            btn_show.clicked.connect(make_toggle_callback())
            pass_layout.addWidget(btn_show)
            
            self.table_profiles.setCellWidget(row, 2, pass_holder)
            
            # Trạng thái & Hạn mức sử dụng
            is_limited = grok_account_manager.is_profile_rate_limited(p)
            p_info = usage_cache.get(p, {})
            percent_str = p_info.get("usage_percent")
            
            # Biểu đồ hạn mức
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setAlignment(Qt.AlignmentFlag.AlignCenter)
            
            percent_val = 0
            if is_limited:
                percent_val = 100
                bar_color = "#ef4444"  # Red
                bar_text = "Hết lượt (100%)"
            elif percent_str:
                try:
                    import re
                    m = re.search(r"(\d+)", percent_str)
                    if m:
                        percent_val = int(m.group(1))
                except Exception:
                    pass
                bar_color = "#3b82f6"  # Blue like Grok website!
                bar_text = f"{percent_val}% đã sử dụng"
            else:
                bar_color = "#3b82f6"  # Blue
                bar_text = "0% đã sử dụng"
                
            bar.setValue(percent_val)
            bar.setFormat(bar_text)
            bar.setStyleSheet(f"""
                QProgressBar {{
                    border: 1px solid {COLORS['border']};
                    border-radius: 4px;
                    text-align: center;
                    background: {COLORS['bg2']};
                    color: #ffffff;
                    font-weight: bold;
                    font-size: 11px;
                    height: 18px;
                    min-width: 110px;
                }}
                QProgressBar::chunk {{
                    background-color: {bar_color};
                    border-radius: 3px;
                }}
            """)
            
            bar_holder = QWidget()
            bar_layout = QHBoxLayout(bar_holder)
            bar_layout.setContentsMargins(6, 4, 6, 4)
            bar_layout.addWidget(bar)
            self.table_profiles.setCellWidget(row, 3, bar_holder)
            
            # Trạng thái hoạt động
            status = "Sẵn sàng"
            reset = p_info.get("usage_reset")
            if is_limited:
                if reset:
                    status = f"❌ Hết lượt (Đặt lại: {reset})"
                else:
                    status = "❌ Hết lượt (Rate Limited)"
            else:
                profile_dir = resolve_profile_dir(p)
                if profile_dir.is_dir():
                    if reset:
                        status = f"Đã đăng nhập (Đặt lại: {reset})"
                    else:
                        status = "Đã đăng nhập"
                else:
                    status = "Chưa thiết lập"
            
            status_item = QTableWidgetItem(status)
            self.table_profiles.setItem(row, 4, status_item)
            
        # Select active profile
        for r in range(self.table_profiles.rowCount()):
            item = self.table_profiles.item(r, 0)
            if item and item.data(Qt.ItemDataRole.UserRole) == active_prof:
                self.table_profiles.selectRow(r)
                break

    def _on_selection_changed(self):
        selected_rows = self.table_profiles.selectionModel().selectedRows()
        if selected_rows:
            r = selected_rows[0].row()
            p = self.table_profiles.item(r, 0).data(Qt.ItemDataRole.UserRole)
            grok_account_manager.set_active_profile(p)

    def _open_login(self):
        selected_rows = self.table_profiles.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "Chọn tài khoản", "Hãy chọn một tài khoản trong bảng để mở Chrome đăng nhập.")
            return
        r = selected_rows[0].row()
        p = self.table_profiles.item(r, 0).data(Qt.ItemDataRole.UserRole)
        
        try:
            self.login_log.appendPlainText(f"Đang mở Chrome cho {p}... ĐĂNG NHẬP XONG HÃY ĐÓNG CỦA SỔ CHROME LẠI.")
            open_profile_chrome(profile_name=p)
            self.login_log.appendPlainText(f"✅ Đã mở Chrome cho {p}. Hãy đăng nhập GROK, sau khi đăng nhập xong hãy ĐÓNG Chrome lại rồi mới bấm nút Tạo video!")
            self._refresh_table()
        except Exception as e:
            self.login_log.appendPlainText(f"❌ Lỗi: {e}")
            QMessageBox.critical(self, "Lỗi", f"Không mở được Chrome cho {p}:\n{e}")

    def _update_profile_usage_clicked(self):
        selected_rows = self.table_profiles.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "Chọn tài khoản", "Hãy chọn một tài khoản để cập nhật hạn mức.")
            return
        r = selected_rows[0].row()
        p = self.table_profiles.item(r, 0).data(Qt.ItemDataRole.UserRole)
        
        self.btn_update_usage.setEnabled(False)
        self.btn_login.setEnabled(False)
        self.btn_add.setEnabled(False)
        self.btn_delete.setEnabled(False)
        self.btn_reset.setEnabled(False)
        self.table_profiles.setEnabled(False)
        
        self.login_log.appendPlainText(f"🚀 Bắt đầu quét hạn mức cho {p}...")
        
        self.usage_worker = GrokUpdateUsageWorker(p)
        self.usage_worker.info_signal.connect(self.login_log.appendPlainText)
        
        def on_finished(success, message):
            self.btn_update_usage.setEnabled(True)
            self.btn_login.setEnabled(True)
            self.btn_add.setEnabled(True)
            self.btn_delete.setEnabled(True)
            self.btn_reset.setEnabled(True)
            self.table_profiles.setEnabled(True)
            
            if success:
                self.login_log.appendPlainText(f"✅ Hoàn thành: {message}")
            else:
                self.login_log.appendPlainText(f"❌ Thất bại: {message}")
                QMessageBox.warning(self, "Quét hạn mức thất bại", f"Không thể lấy hạn mức của {p}:\n{message}")
                
            self._refresh_table()
            
        self.usage_worker.finished_signal.connect(on_finished)
        self.usage_worker.start()

    def _add_profile(self):
        try:
            new_p = grok_account_manager.add_profile()
            self.login_log.appendPlainText(f"➕ Đã thêm tài khoản mới: {new_p}")
            self._refresh_table()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Không thể thêm tài khoản:\n{e}")

    def _delete_profile(self):
        selected_rows = self.table_profiles.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "Chọn tài khoản", "Hãy chọn một tài khoản để xóa.")
            return
        r = selected_rows[0].row()
        p = self.table_profiles.item(r, 0).data(Qt.ItemDataRole.UserRole)
        
        if p == "PROFILE_1" and len(grok_account_manager.get_profiles()) == 1:
            QMessageBox.warning(self, "Không thể xóa", "Không thể xóa tài khoản duy nhất còn lại.")
            return
            
        reply = QMessageBox.question(
            self, "Xác nhận xóa", f"Bạn có chắc muốn xóa cấu hình tài khoản {p}?\nDữ liệu Chrome đăng nhập của tài khoản này vẫn được giữ lại trên ổ cứng.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            grok_account_manager.delete_profile(p)
            self.login_log.appendPlainText(f"❌ Đã xóa cấu hình tài khoản: {p}")
            self._refresh_table()

    def _reset_profiles(self):
        grok_account_manager.reset_rate_limits()
        self.login_log.appendPlainText("🔄 Đã khôi phục trạng thái hoạt động cho tất cả các tài khoản!")
        self._refresh_table()
APP_VERSION = "1.0.0"
UPDATE_URL = "https://raw.githubusercontent.com/giadinhunin2024/grok-tool-releases/main/version.json"


class UpdateCheckerThread(QThread):
    update_available = pyqtSignal(dict)

    def __init__(self, current_version: str, update_url: str):
        super().__init__()
        self.current_version = current_version
        self.update_url = update_url

    def run(self):
        import urllib.request
        import json
        
        if "YOUR_GITHUB_USERNAME" in self.update_url:
            return
            
        try:
            req = urllib.request.Request(
                self.update_url, 
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            )
            with urllib.request.urlopen(req, timeout=8) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode('utf-8'))
                    online_ver = str(data.get("version", "")).strip()
                    if online_ver and self._is_newer(online_ver, self.current_version):
                        self.update_available.emit(data)
        except Exception:
            pass

    def _is_newer(self, online_ver: str, local_ver: str) -> bool:
        try:
            online_parts = [int(x) for x in online_ver.split(".")]
            local_parts = [int(x) for x in local_ver.split(".")]
            max_len = max(len(online_parts), len(local_parts))
            online_parts += [0] * (max_len - len(online_parts))
            local_parts += [0] * (max_len - len(local_parts))
            return online_parts > local_parts
        except Exception:
            return online_ver != local_ver


class UpdateDialog(QDialog):
    def __init__(self, update_info: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("📢 Phát hiện bản cập nhật mới!")
        self.setFixedSize(450, 300)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)
        
        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e24;
                color: #e2e2e7;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            QLabel {
                color: #e2e2e7;
            }
            QPlainTextEdit {
                background-color: #121216;
                color: #a1a1aa;
                border: 1px solid #2e2e38;
                border-radius: 6px;
                font-size: 13px;
            }
            QPushButton#primary {
                background-color: #3b82f6;
                color: white;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                padding: 8px 16px;
            }
            QPushButton#primary:hover {
                background-color: #2563eb;
            }
            QPushButton#secondary {
                background-color: #2e2e38;
                color: #e2e2e7;
                border: 1px solid #3e3e4c;
                border-radius: 6px;
                padding: 8px 16px;
            }
            QPushButton#secondary:hover {
                background-color: #3e3e4c;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        online_ver = update_info.get("version", "Mới")
        title_lbl = QLabel(f"<b>Đã có phiên bản mới V{online_ver}!</b>")
        title_lbl.setStyleSheet("font-size: 16px; color: #3b82f6;")
        layout.addWidget(title_lbl)
        
        desc_lbl = QLabel("Danh sách thay đổi:")
        desc_lbl.setStyleSheet("font-weight: bold; font-size: 13px;")
        layout.addWidget(desc_lbl)
        
        self.changelog_txt = QPlainTextEdit()
        self.changelog_txt.setReadOnly(True)
        changelog = update_info.get("changelog", "Sửa một số lỗi và tối ưu hóa hiệu năng.")
        self.changelog_txt.setPlainText(changelog)
        layout.addWidget(self.changelog_txt, 1)
        
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)
        btn_layout.addStretch(1)
        
        self.btn_skip = QPushButton("Bỏ qua")
        self.btn_skip.setObjectName("secondary")
        self.btn_skip.clicked.connect(self.reject)
        
        self.btn_update = QPushButton("Cập nhật ngay")
        self.btn_update.setObjectName("primary")
        
        download_url = update_info.get("download_url_windows", "")
        if sys.platform == "darwin":
            download_url = update_info.get("download_url_macos", download_url)
        elif sys.platform == "linux":
            download_url = update_info.get("download_url_linux", download_url)
            
        if not download_url:
            download_url = "https://github.com/YOUR_GITHUB_USERNAME/grok-tool-releases/releases"
            
        self.download_url = download_url
        self.btn_update.clicked.connect(self.do_update)
        
        btn_layout.addWidget(self.btn_skip)
        btn_layout.addWidget(self.btn_update)
        layout.addLayout(btn_layout)
        
    def do_update(self):
        import webbrowser
        try:
            url = self.download_url
            if "YOUR_GITHUB_USERNAME" in url:
                url = "https://github.com"
            webbrowser.open(url)
        except Exception:
            pass
        self.accept()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Tool Grok Độc V05-07")
        self.resize(1040, 880)

        # Khởi chạy luồng kiểm tra cập nhật ngầm
        self._check_for_updates()

        root = QWidget(); root.setObjectName("root")
        layout = QVBoxLayout(root)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(14)

        header = QWidget(); header.setObjectName("headerBar")
        hl = QHBoxLayout(header); hl.setContentsMargins(22, 14, 22, 14)
        logo = QLabel("⚡"); logo.setStyleSheet("font-size: 30px;")
        hl.addWidget(logo)
        tcol = QVBoxLayout(); tcol.setSpacing(0)
        t = QLabel("GROK STUDIO"); t.setObjectName("appTitle")
        s = QLabel("Tạo ảnh & video AI — nhanh, nhiều luồng"); s.setObjectName("appSubtitle")
        tcol.addWidget(t); tcol.addWidget(s)
        hl.addLayout(tcol)
        hl.addStretch(1)
        layout.addWidget(header)

        self.tabs = QTabWidget()
        self.settings_tab = SettingsTab()
        self.tabs.addTab(CreateImageTab(), "🎨  Tạo ảnh")
        self.tabs.addTab(OutfitSwapperTab(), "👗  Ghép Trang Phục")
        self.tabs.addTab(TextToVideoTab(), "🎬  Text → Video")
        self.tabs.addTab(ImageToVideoTab(), "🖼  Image → Video")
        self.tabs.addTab(self.settings_tab, "⚙  Cài đặt")
        self.tabs.currentChanged.connect(self._on_tab_changed)
        layout.addWidget(self.tabs, 1)

        self.setCentralWidget(root)

    def _check_for_updates(self):
        self._update_worker = UpdateCheckerThread(APP_VERSION, UPDATE_URL)
        self._update_worker.update_available.connect(self._show_update_dialog)
        self._update_worker.start()

    def _show_update_dialog(self, update_info: dict):
        dlg = UpdateDialog(update_info, self)
        dlg.exec()

    def _on_tab_changed(self, index):
        try:
            widget = self.tabs.widget(index)
            if hasattr(widget, "_refresh_table"):
                widget._refresh_table()
        except Exception:
            pass


def main():
    try:
        Path(DEFAULT_OUTPUT).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))
    app.setStyleSheet(STYLESHEET)

    # Kiểm tra bản quyền trực tuyến trước khi vào ứng dụng
    from grok_license import check_license_silent, LicenseDialog
    if not check_license_silent():
        dlg = LicenseDialog()
        if dlg.exec() != LicenseDialog.DialogCode.Accepted:
            sys.exit(0)

    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

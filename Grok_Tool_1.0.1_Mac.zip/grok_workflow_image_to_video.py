from __future__ import annotations

import asyncio
import datetime
import os
import re
import threading
from pathlib import Path
from typing import Callable

from grok_api_image_to_video import (
    ImageToVideoConfig,
    api_create_image_post_in_page,
    api_image_to_video_in_page,
    api_upload_image_in_page,
    api_upscale_video_in_page,
)
from grok_api_text_to_video import (
    auto_discover_statsig_headers,
    download_mp4,
    get_oauth_api_token,
    generate_i2v_via_api,
)
from grok_chrome_manager import open_chrome_session, resolve_profile_dir, update_profile_usage_via_dom
import grok_account_manager


CDP_HOST = os.getenv("GROK_CDP_HOST", os.getenv("CDP_HOST", "127.0.0.1"))
CDP_PORT = int(os.getenv("GROK_CDP_PORT", os.getenv("CDP_PORT", "9223")))

import sys

if getattr(sys, 'frozen', False):
    WORKSPACE_DIR = Path(sys.executable).resolve().parent
else:
    WORKSPACE_DIR = Path(__file__).resolve().parent
CHROME_USER_DATA_ROOT = Path(
    os.getenv("GROK_CHROME_USER_DATA_ROOT", str(WORKSPACE_DIR / "chrome_user_data_grok"))
)
PROFILE_NAME = os.getenv("GROK_PROFILE_NAME", os.getenv("PROFILE_NAME", "PROFILE_1"))
USER_DATA_DIR = resolve_profile_dir(PROFILE_NAME)
CACHE_PATH = Path(os.getenv("GROK_CACHE_PATH", str(WORKSPACE_DIR / "grok_cache.json")))

STREAM_TIMEOUT_SECONDS = int(os.getenv("GROK_STREAM_TIMEOUT", "300"))
DOWNLOAD_DIR = Path(os.getenv("GROK_DOWNLOAD_DIR", str(WORKSPACE_DIR / "downloads")))
DOWNLOAD_TIMEOUT_MS = int(os.getenv("GROK_DOWNLOAD_TIMEOUT_MS", "180000"))
JOB_HARD_TIMEOUT_SECONDS = int(os.getenv("GROK_JOB_HARD_TIMEOUT_SECONDS", "420"))

StatusCallback = Callable[[int, str], None]
ProgressCallback = Callable[[int, int], None]
VideoCallback = Callable[[int, str], None]
InfoCallback = Callable[[str], None]


def _safe_call(cb, *args) -> None:
    try:
        if cb:
            cb(*args)
    except Exception:
        pass


def crop_image_to_aspect_ratio(image_path: Path, target_ratio_str: str) -> Path:
    """
    Tự động cắt (center-crop) ảnh về tỷ lệ khung hình mục tiêu (ví dụ '9:16' hoặc '16:9')
    để tránh bị méo hình/bóp hình khi đưa vào Grok.
    Trả về đường dẫn tệp ảnh tạm thời mới được tạo.
    """
    from PIL import Image
    import tempfile
    
    try:
        # Phân tích tỷ lệ mục tiêu
        parts = target_ratio_str.split(":")
        if len(parts) != 2:
            return image_path
        target_w = float(parts[0])
        target_h = float(parts[1])
        target_ratio = target_w / target_h
    except Exception:
        return image_path
        
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            current_ratio = width / height
            
            # Nếu tỷ lệ đã chuẩn, không cần cắt
            if abs(current_ratio - target_ratio) < 0.01:
                return image_path
                
            if current_ratio > target_ratio:
                # Ảnh hiện tại quá rộng -> Cắt bớt hai bên (trái, phải)
                new_width = int(height * target_ratio)
                left = (width - new_width) // 2
                right = left + new_width
                crop_box = (left, 0, right, height)
            else:
                # Ảnh hiện tại quá cao -> Cắt bớt hai đầu (trên, dưới)
                new_height = int(width / target_ratio)
                top = (height - new_height) // 2
                bottom = top + new_height
                crop_box = (0, top, width, bottom)
                
            cropped_img = img.crop(crop_box)
            
            suffix = image_path.suffix.lower()
            if suffix not in {".png", ".jpg", ".jpeg", ".webp"}:
                suffix = ".png"
            
            temp_file = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
            temp_path = Path(temp_file.name)
            temp_file.close()
            
            save_format = "PNG" if suffix == ".png" else "JPEG"
            if suffix == ".webp":
                save_format = "WEBP"
                
            cropped_img.save(temp_path, format=save_format, quality=95)
            return temp_path
            
    except Exception as e:
        print(f"Lỗi khi tự động cắt ảnh: {e}", flush=True)
        return image_path


def _safe_filename(value: str, fallback: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return fallback
    raw = re.sub(r"[^A-Za-z0-9._-]+", "_", raw)
    raw = raw.strip("._ ")
    return raw or fallback


def _build_unique_video_name(prompt_index: int, prompt: str | None, image_path: str | None) -> str:
    try:
        pid = f"{int(prompt_index):03d}"
    except Exception:
        pid = "000"
    prompt_part = _safe_filename(str(prompt or "")[:30], "prompt")
    image_part = _safe_filename(Path(str(image_path or "")).stem[:30], "image")
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    base = f"{pid}_{image_part}_{prompt_part}_{ts}"
    if len(base) > 180:
        base = base[:180].rstrip("._- ")
    return f"{base}.mp4"


async def _run_jobs_async_ui(
    items: list[dict[str, str]],
    cfg: ImageToVideoConfig,
    max_concurrency: int,
    on_status: StatusCallback | None,
    on_progress: ProgressCallback | None,
    on_video: VideoCallback | None,
    on_info: InfoCallback | None,
    stop_event: threading.Event | None = None,
    offscreen_chrome: bool = False,
    max_job_retries: int = 0,
    upscale_mode: str = "Không nâng cấp",
) -> None:
    def _stop_requested() -> bool:
        try:
            return bool(stop_event is not None and stop_event.is_set())
        except Exception:
            return False

    async def _await_with_stop(coro, *, step_name: str, idx: int | None = None, check_interval: float = 0.2):
        task = asyncio.create_task(coro)
        interval = max(0.05, float(check_interval or 0.2))
        try:
            while True:
                if _stop_requested():
                    try:
                        task.cancel()
                    except Exception:
                        pass
                    await asyncio.gather(task, return_exceptions=True)
                    if isinstance(idx, int):
                        _safe_call(on_status, idx, "Stop")
                    _safe_call(on_info, f"🛑 Dừng ở bước {step_name}" + (f" (job {idx+1})" if isinstance(idx, int) else ""))
                    raise asyncio.CancelledError()
                if task.done():
                    return await task
                await asyncio.sleep(interval)
        finally:
            if _stop_requested() and not task.done():
                try:
                    task.cancel()
                except Exception:
                    pass

    async def _wait_for_grok_login(page_obj) -> bool:
        while True:
            if _stop_requested():
                return False
            state = 'ok'
            try:
                state = await page_obj.evaluate(
                    """() => {
                      const url = window.location.href;
                      const title = document.title || '';
                      if (url.includes('__cf_chl_f_tk') || title.includes('Just a moment')) {
                        return 'cloudflare';
                      }
                      const text = document.body ? document.body.innerText : '';
                      if (text.includes('Verify you are human') || text.includes('checking your browser') || text.includes('security check')) {
                        return 'cloudflare';
                      }
                      if (url.includes('accounts.x.ai') || url.includes('/login')) {
                        return 'login';
                      }
                      const has_login_btn = Array.from(document.querySelectorAll('button, a, div[role="button"]')).some(el => {
                        const t = el.innerText || '';
                        return t.includes('Sign in') || t.includes('Log in') || t.includes('Đăng nhập') || t.includes('Se connecter');
                      });
                      if (has_login_btn) {
                        return 'login';
                      }
                      return 'ok';
                    }"""
                )
            except Exception:
                pass

            if state == 'cloudflare':
                _safe_call(on_info, "🔐 Đang chờ xác thực Cloudflare... Vui lòng click chọn xác minh người máy trên cửa sổ Chrome.")
                await asyncio.sleep(4)
            elif state == 'login':
                _safe_call(on_info, "🔐 Phát hiện chưa đăng nhập. Vui lòng hoàn tất đăng nhập Grok trên cửa sổ Chrome để tiếp tục...")
                await asyncio.sleep(4)
            else:
                return True

    if _stop_requested():
        _safe_call(on_info, "🛑 Đã nhận STOP trước khi mở Chrome GROK")
        return

    current_profile = grok_account_manager.get_active_profile()
    _safe_call(on_info, f"👤 Khởi chạy bằng tài khoản: {current_profile}")
    user_data_dir = resolve_profile_dir(current_profile)

    session = await open_chrome_session(
        host=CDP_HOST,
        port=CDP_PORT,
        user_data_dir=user_data_dir,
        start_url="https://grok.com/",
        cdp_wait_seconds=30,
        offscreen=bool(offscreen_chrome),
    )

    try:
        if _stop_requested():
            _safe_call(on_info, "🛑 Đã nhận STOP, thoát trước khi khởi tạo page")
            return

        context = session.context
        page = None
        for candidate in list(context.pages):
            try:
                if not candidate.is_closed() and "grok.com" in (candidate.url or ""):
                    page = candidate
                    break
            except Exception:
                continue
        if page is None:
            page = await context.new_page()

        try:
            await _await_with_stop(
                page.goto("https://grok.com/", wait_until="domcontentloaded", timeout=30000),
                step_name="mở trang GROK",
            )
        except Exception:
            pass

        # Chờ người dùng đăng nhập xong nếu trang bị chặn ở màn hình login/Cloudflare
        if not await _wait_for_grok_login(page):
            return

        # Tự động cập nhật hạn mức sử dụng từ DOM vào cache
        try:
            await update_profile_usage_via_dom(page, CACHE_PATH, current_profile, on_info)
        except Exception as e:
            _safe_call(on_info, f"⚠️ Cảnh báo: Không cập nhật được hạn mức ({e}), vẫn tiếp tục tạo video...")

        if _stop_requested():
            _safe_call(on_info, "🛑 Đã nhận STOP sau khi mở trang GROK")
            return

        _safe_call(on_info, "🔖 PHIÊN BẢN I2V: REST-API-v16 (Xoay vòng tài khoản tự động)")
        api_token = await _await_with_stop(
            get_oauth_api_token(page, on_info=on_info),
            step_name="lấy OAuth token",
        )
        if not api_token:
            _safe_call(on_info, "❌ Không lấy được OAuth token. Hãy đăng nhập Grok trong Chrome.")
            return

        # Token/Profile holder dùng chung giữa các luồng
        token_holder = {"token": api_token, "profile": current_profile}
        token_lock = asyncio.Lock()

        async def _rotate_account(failed_profile: str) -> dict:
            nonlocal session, page, context
            async with token_lock:
                if token_holder["profile"] != failed_profile:
                    return token_holder["token"]
                
                _safe_call(on_info, f"⚠️ Tài khoản {failed_profile} đã báo HẾT LƯỢT. Đang chuyển đổi...")
                grok_account_manager.mark_profile_rate_limited(failed_profile)
                
                # Lấy profile tiếp theo trước khi đóng session cũ
                next_prof = grok_account_manager.get_next_active_profile()

                try:
                    await session.close(keep_chrome=False)
                except Exception:
                    pass
                
                _safe_call(on_info, f"🔄 Đang mở Chrome cho tài khoản tiếp theo: {next_prof}...")
                
                next_dir = resolve_profile_dir(next_prof)
                session = await open_chrome_session(
                    host=CDP_HOST,
                    port=CDP_PORT,
                    user_data_dir=next_dir,
                    start_url="https://grok.com/",
                    cdp_wait_seconds=30,
                    offscreen=bool(offscreen_chrome),
                )
                
                context = session.context
                page = None
                for candidate in list(context.pages):
                    try:
                        if not candidate.is_closed() and "grok.com" in (candidate.url or ""):
                            page = candidate
                            break
                    except Exception:
                        continue
                if page is None:
                    page = await context.new_page()
                    
                try:
                    await page.goto("https://grok.com/", wait_until="domcontentloaded", timeout=30000)
                except Exception:
                    pass
                    
                # Chờ đăng nhập cho tài khoản tiếp theo nếu cần
                if not await _wait_for_grok_login(page):
                    raise RuntimeError(f"Huỷ bỏ hoặc không đăng nhập được tài khoản {next_prof}!")
                    
                try:
                    await update_profile_usage_via_dom(page, CACHE_PATH, next_prof, on_info)
                except Exception as e:
                    _safe_call(on_info, f"⚠️ Cảnh báo: Không cập nhật được hạn mức ({e}), vẫn tiếp tục...")
                    
                new_token = await get_oauth_api_token(page, on_info=on_info)
                if not new_token:
                    raise RuntimeError(f"Không lấy được Token của tài khoản {next_prof}!")
                    
                # Re-expose progress functions to the new page
                try:
                    await page.expose_function("py_progress", js_progress)
                except Exception:
                    pass
                try:
                    await page.expose_function("py_log", js_log)
                except Exception:
                    pass
                    
                token_holder["token"] = new_token
                token_holder["profile"] = next_prof
                _safe_call(on_info, f"✅ Đã chuyển thành công sang tài khoản {next_prof}!")
                return new_token

        async def js_progress(payload):
            if _stop_requested() or not isinstance(payload, dict):
                return
            idx = payload.get("index")
            pct = payload.get("progress")
            if isinstance(idx, int) and isinstance(pct, (int, float)):
                _safe_call(on_progress, idx, int(max(0, min(100, pct))))

        async def js_log(payload):
            if _stop_requested() or not isinstance(payload, dict):
                return
            idx = payload.get("index")
            msg = str(payload.get("message") or "")
            data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
            if not isinstance(idx, int):
                return

            if msg == "conversation_start":
                _safe_call(on_status, idx, "Đang Tạo video")
            elif msg == "conversation_status":
                _safe_call(on_status, idx, "Đang Tạo video")
            elif msg == "video_generated":
                _safe_call(on_progress, idx, 100)
                _safe_call(on_status, idx, "Tạo xong")
            elif msg in {"upscale_attempt", "upscale_retry"}:
                _safe_call(on_status, idx, "Đang Tải video")
            elif msg == "upscale_success":
                _safe_call(on_status, idx, "Tải HD")
            elif msg.endswith("_error"):
                _safe_call(on_status, idx, f"Lỗi {msg}")
            elif data:
                _safe_call(on_info, f"[GROK-I2V {idx+1}] {msg}: {data}")

        try:
            await page.expose_function("py_progress", js_progress)
        except Exception:
            pass
        try:
            await page.expose_function("py_log", js_log)
        except Exception:
            pass

        GROK_API_CONCURRENCY = 3
        GROK_API_DELAY = 5.0
        sem = asyncio.Semaphore(GROK_API_CONCURRENCY)
        headers_lock = asyncio.Lock()
        _gap_lock = asyncio.Lock()
        _last_send = {"t": 0.0}
        async def _api_throttle():
            async with _gap_lock:
                import time as _t
                now = _t.monotonic()
                wait = GROK_API_DELAY - (now - _last_send["t"])
                if wait > 0:
                    await asyncio.sleep(wait)
                _last_send["t"] = _t.monotonic()

        async def run_one_job(idx: int, job: dict[str, str]) -> bool:
            if _stop_requested():
                _safe_call(on_status, idx, "Stop")
                return False

            async def handle_upscale_if_needed(out_path: Path) -> Path:
                if "AI" in upscale_mode:
                    _safe_call(on_status, idx, "Nâng cấp AI")
                    _safe_call(on_info, f"[GROK-I2V {idx+1}] Đang nâng cấp AI ({upscale_mode}) cho video...")
                    suffix_lbl = "1080p" if "1080p" in upscale_mode else ("4k" if "4K" in upscale_mode else "2k")
                    upscale_out = out_path.parent / f"{out_path.stem}_{suffix_lbl}.mp4"
                    loop = asyncio.get_running_loop()
                    from grok_upscaler import upscale_video_ai
                    upscale_ok = await loop.run_in_executor(
                        None,
                        upscale_video_ai,
                        out_path,
                        upscale_out,
                        upscale_mode,
                        lambda msg: _safe_call(on_info, f"[GROK-I2V {idx+1}] {msg}")
                    )
                    if upscale_ok and upscale_out.exists():
                        try:
                            out_path.unlink(missing_ok=True)
                        except Exception:
                            pass
                        return upscale_out
                    else:
                        _safe_call(on_info, f"[GROK-I2V {idx+1}] ⚠️ Nâng cấp AI thất bại. Sử dụng video gốc.")
                return out_path

            orig_image_path = Path(str(job.get("image_path") or "").strip())
            prompt = str(job.get("prompt") or "").strip()

            if not orig_image_path.is_file():
                _safe_call(on_status, idx, "Lỗi ảnh")
                _safe_call(on_info, f"[GROK-I2V {idx+1}] ảnh không tồn tại: {orig_image_path}")
                return False

            target_ratio_str = getattr(cfg, 'aspect_ratio', '9:16')
            _safe_call(on_info, f"[GROK-I2V {idx+1}] bắt đầu job | image={orig_image_path.name}")
            
            image_path = orig_image_path
            temp_cropped_created = False
            try:
                # Tự động cắt (center-crop) ảnh để khớp tỷ lệ khung hình mục tiêu
                image_path = crop_image_to_aspect_ratio(orig_image_path, target_ratio_str)
                if image_path != orig_image_path:
                    temp_cropped_created = True
                    _safe_call(on_info, f"[GROK-I2V {idx+1}] ✂️ Tự động cắt (Center-Crop) ảnh sang tỷ lệ {target_ratio_str} để tránh méo hình")

                _safe_call(
                    on_info,
                    f"[GROK-I2V {idx+1}] config: aspect={target_ratio_str} | "
                    f"length={getattr(cfg, 'video_length_seconds', 6)} | res={getattr(cfg, 'resolution_name', '480p')}",
                )

                retries = 5
                api_res = None
                
                while retries > 0:
                    current_token = token_holder["token"]
                    current_prof = token_holder["profile"]
                    
                    await _api_throttle()
                    _safe_call(on_status, idx, "Đang Tạo video")
                    _safe_call(on_info, f"[GROK-I2V {idx+1}] gửi request tạo video (API) qua tài khoản {current_prof}...")
                    
                    api_res = await _await_with_stop(
                        generate_i2v_via_api(
                            page,
                            image_path,
                            prompt,
                            current_token,
                            cfg,
                            on_progress=lambda p: _safe_call(on_progress, idx, p),
                            timeout_seconds=max(120, int(STREAM_TIMEOUT_SECONDS or 900)),
                        ),
                        step_name="api.x.ai i2v gen",
                        idx=idx,
                    )
                    
                    if _stop_requested():
                        _safe_call(on_status, idx, "Stop")
                        return False
 
                    # Kiểm tra xem có lỗi từ API không
                    if isinstance(api_res, dict) and api_res.get("error"):
                        err_msg = str(api_res["error"])
                        _safe_call(on_info, f"[GROK-I2V {idx+1}] ⚠️ API báo lỗi: {err_msg}")
                        
                        # 1. Kiểm tra lỗi Rate Limit thực sự (429 hoặc có chữ 'limit'/'rate')
                        is_rate_limit = False
                        if "429" in err_msg or "limit" in err_msg.lower():
                            is_rate_limit = True
                            
                        if is_rate_limit:
                            try:
                                await _rotate_account(current_prof)
                                retries -= 1
                                continue
                            except grok_account_manager.AllAccountsExhaustedError as ae:
                                _safe_call(on_status, idx, "Hết tài khoản")
                                _safe_call(on_info, f"[GROK-I2V {idx+1}] dừng toàn bộ luồng: {ae}")
                                if stop_event is not None:
                                    stop_event.set()
                                return False
                            except Exception as rotate_exc:
                                _safe_call(on_status, idx, "Lỗi")
                                _safe_call(on_info, f"[GROK-I2V {idx+1}] lỗi chuyển tài khoản: {rotate_exc}")
                                return False
                                
                        # 2. Kiểm tra lỗi Chưa đăng nhập / Hết hạn token (401 hoặc 403 hoặc 'unauthorized')
                        is_token_issue = False
                        if "401" in err_msg or "403" in err_msg or "unauthorized" in err_msg.lower() or "chưa đăng nhập" in err_msg.lower():
                            is_token_issue = True
                            
                        if is_token_issue:
                            _safe_call(on_info, f"[GROK-I2V {idx+1}] 🔄 Token của {current_prof} hết hạn hoặc lỗi xác thực. Đang tự động làm mới token...")
                            new_token = await get_oauth_api_token(page, on_info=on_info)
                            if new_token:
                                token_holder["token"] = new_token
                                _safe_call(on_info, f"[GROK-I2V {idx+1}] ✅ Đã làm mới token thành công cho {current_prof}, thử lại...")
                                retries -= 1
                                continue
                            else:
                                # Không refresh được -> báo lỗi đăng nhập
                                _safe_call(on_status, idx, "Chưa đăng nhập")
                                _safe_call(on_info, f"[GROK-I2V {idx+1}] ❌ Không thể làm mới token cho {current_prof}. Vui lòng bấm 'Đăng nhập Chrome' để đăng nhập lại.")
                                if stop_event is not None:
                                    stop_event.set()
                                return False
                                
                        # 3. Lỗi khác
                        _safe_call(on_status, idx, "Lỗi")
                        _safe_call(on_info, f"[GROK-I2V {idx+1}] lỗi API không phục hồi được: {err_msg}")
                        return False

                    break

                if not isinstance(api_res, dict) or api_res.get("error"):
                    err = (api_res or {}).get("error") if isinstance(api_res, dict) else "unknown"
                    _safe_call(on_status, idx, "Lỗi")
                    _safe_call(on_info, f"[GROK-I2V {idx+1}] lỗi API: {err}")
                    return False

                source_url = api_res.get("videoUrl") or api_res.get("hdMediaUrl") or api_res.get("mediaUrl") or (api_res.get("lastEvent") or {}).get("videoUrl")
                _safe_call(on_progress, idx, 100)
                _safe_call(on_status, idx, "Tải video")
                if not (isinstance(source_url, str) and source_url.strip()):
                    _safe_call(on_status, idx, "Lỗi")
                    _safe_call(on_info, f"[GROK-I2V {idx+1}] không có video URL")
                    return False

                out_path = DOWNLOAD_DIR / _build_unique_video_name(idx + 1, prompt, str(orig_image_path))
                _safe_call(on_info, f"[GROK-I2V {idx+1}] tải video về: {out_path.name}")
                ok = await _await_with_stop(
                    download_mp4(context, source_url.strip(), out_path, timeout_ms=DOWNLOAD_TIMEOUT_MS, page=page),
                    step_name="tải video",
                    idx=idx,
                )
                if not ok:
                    # thử lại 1 lần
                    ok = await _await_with_stop(
                        download_mp4(context, source_url.strip(), out_path, timeout_ms=DOWNLOAD_TIMEOUT_MS, page=page),
                        step_name="tải lại",
                        idx=idx,
                    )
                if not ok:
                    _safe_call(on_status, idx, "Lỗi tải")
                    _safe_call(on_info, f"[GROK-I2V {idx+1}] tải thất bại")
                    return False

                final_path = await handle_upscale_if_needed(out_path)
                _safe_call(on_video, idx, str(final_path))
                _safe_call(on_status, idx, "Hoàn thành")
                _safe_call(on_info, f"[GROK-I2V {idx+1}] hoàn thành")
                return True
            finally:
                # Xóa file ảnh tạm đã cắt
                if temp_cropped_created and image_path.is_file():
                    try:
                        image_path.unlink()
                    except Exception:
                        pass


        async def run_one_job_guarded(idx: int, job: dict[str, str]) -> None:
            async with sem:
                timeout_seconds = max(60, int(JOB_HARD_TIMEOUT_SECONDS or 420))
                retry_count = 0
                max_retries = int(max_job_retries or 0)
                while True:
                    if _stop_requested():
                        return
                    try:
                        ok = await asyncio.wait_for(run_one_job(idx, job), timeout=timeout_seconds)
                        if ok:
                            return
                        if _stop_requested():
                            return
                        if retry_count < max_retries:
                            retry_count += 1
                            _safe_call(on_info, f"[GROK-I2V {idx+1}] Thử lại lần {retry_count}/{max_retries}...")
                            _safe_call(on_status, idx, f"Thử lại {retry_count}/{max_retries}")
                            await asyncio.sleep(2.0)
                            continue
                        else:
                            return
                    except asyncio.TimeoutError:
                        if _stop_requested():
                            return
                        if retry_count < max_retries:
                            retry_count += 1
                            _safe_call(on_info, f"[GROK-I2V {idx+1}] Timeout. Thử lại lần {retry_count}/{max_retries}...")
                            _safe_call(on_status, idx, f"Thử lại {retry_count}/{max_retries}")
                            await asyncio.sleep(2.0)
                            continue
                        else:
                            _safe_call(on_status, idx, "Lỗi timeout")
                            _safe_call(on_info, f"[GROK-I2V {idx+1}] timeout sau {timeout_seconds}s, bỏ qua job để tránh kẹt luồng")
                            return
                    except asyncio.CancelledError:
                        raise
                    except Exception as exc:
                        if _stop_requested():
                            return
                        if retry_count < max_retries:
                            retry_count += 1
                            _safe_call(on_info, f"[GROK-I2V {idx+1}] Lỗi runtime: {exc}. Thử lại lần {retry_count}/{max_retries}...")
                            _safe_call(on_status, idx, f"Thử lại {retry_count}/{max_retries}")
                            await asyncio.sleep(2.0)
                            continue
                        else:
                            _safe_call(on_status, idx, "Lỗi")
                            _safe_call(on_info, f"[GROK-I2V {idx+1}] lỗi runtime: {exc}")
                            return

        tasks = [asyncio.create_task(run_one_job_guarded(i, item)) for i, item in enumerate(items)]

        async def _wait_stop() -> bool:
            if stop_event is None:
                return False
            while True:
                if _stop_requested():
                    return True
                await asyncio.sleep(0.2)

        if tasks:
            if stop_event is None:
                await asyncio.gather(*tasks)
            else:
                stop_task = asyncio.create_task(_wait_stop())
                pending_tasks = list(tasks)
                try:
                    while pending_tasks:
                        done, _ = await asyncio.wait(
                            pending_tasks + [stop_task],
                            return_when=asyncio.FIRST_COMPLETED,
                        )
                        if stop_task in done:
                            for t in pending_tasks:
                                try:
                                    t.cancel()
                                except Exception:
                                    pass
                            for i in range(len(items)):
                                _safe_call(on_status, i, "Stop")
                            await asyncio.gather(*tasks, return_exceptions=True)
                            return
                        pending_tasks = [t for t in pending_tasks if not t.done()]
                    await asyncio.gather(*tasks)
                finally:
                    try:
                        stop_task.cancel()
                    except Exception:
                        pass
                    await asyncio.gather(stop_task, return_exceptions=True)

    finally:
        await session.close()


def run_image_to_video_jobs(
    items: list[dict[str, str]],
    aspect_ratio: str,
    video_length_seconds: int,
    resolution_name: str,
    max_concurrency: int,
    download_dir: str | None = None,
    offscreen_chrome: bool = False,
    stop_event: threading.Event | None = None,
    on_status: StatusCallback | None = None,
    on_progress: ProgressCallback | None = None,
    on_video: VideoCallback | None = None,
    on_info: InfoCallback | None = None,
    max_job_retries: int = 0,
    upscale_mode: str = "Không nâng cấp",
) -> None:
    global DOWNLOAD_DIR

    clean_items: list[dict[str, str]] = []
    for raw in items or []:
        if not isinstance(raw, dict):
            continue
        image_path = str(raw.get("image_path") or "").strip()
        if not image_path:
            continue
        clean_items.append({"image_path": image_path, "prompt": str(raw.get("prompt") or "").strip()})

    if not clean_items:
        raise ValueError("Danh sách GROK Image to Video rỗng.")

    if isinstance(download_dir, str) and download_dir.strip():
        DOWNLOAD_DIR = Path(download_dir.strip()) / "grok_video"
    else:
        DOWNLOAD_DIR = Path(DOWNLOAD_DIR) / "grok_video"
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

    runtime_resolution_name = str(resolution_name or "480p")
    if runtime_resolution_name not in {"480p", "720p"}:
        runtime_resolution_name = "480p"

    runtime_aspect_ratio = str(aspect_ratio or "9:16").strip()
    if runtime_aspect_ratio not in {"9:16", "16:9"}:
        runtime_aspect_ratio = "9:16"

    cfg = ImageToVideoConfig(
        aspect_ratio=runtime_aspect_ratio,
        video_length_seconds=int(video_length_seconds or 6),
        resolution_name=runtime_resolution_name,
    )

    asyncio.run(
        _run_jobs_async_ui(
            items=clean_items,
            cfg=cfg,
            max_concurrency=max_concurrency,
            on_status=on_status,
            on_progress=on_progress,
            on_video=on_video,
            on_info=on_info,
            stop_event=stop_event,
            offscreen_chrome=bool(offscreen_chrome),
            max_job_retries=max_job_retries,
            upscale_mode=upscale_mode,
        )
    )

from __future__ import annotations

import asyncio
import os
import re
import threading
from pathlib import Path
from typing import Callable

from grok_api_create_image import (
    CreateImageConfig,
    generate_image_in_page,
    download_image,
    save_base64_image,
)
from grok_api_text_to_video import auto_discover_statsig_headers
from grok_chrome_manager import open_chrome_session, resolve_profile_dir
import grok_account_manager


CDP_HOST = os.getenv("GROK_CDP_HOST", os.getenv("CDP_HOST", "127.0.0.1"))
CDP_PORT = int(os.getenv("GROK_CDP_PORT", os.getenv("CDP_PORT", "9223")))

import sys

if getattr(sys, 'frozen', False):
    WORKSPACE_DIR = Path(sys.executable).resolve().parent
else:
    WORKSPACE_DIR = Path(__file__).resolve().parent
PROFILE_NAME = os.getenv("GROK_PROFILE_NAME", os.getenv("PROFILE_NAME", "PROFILE_1"))
USER_DATA_DIR = resolve_profile_dir(PROFILE_NAME)
CACHE_PATH = Path(os.getenv("GROK_CACHE_PATH", str(WORKSPACE_DIR / "grok_cache.json")))

DOWNLOAD_DIR = Path(os.getenv("GROK_DOWNLOAD_DIR", str(WORKSPACE_DIR / "downloads")))
DOWNLOAD_TIMEOUT_MS = int(os.getenv("GROK_DOWNLOAD_TIMEOUT_MS", "120000"))
STREAM_TIMEOUT_SECONDS = int(os.getenv("GROK_IMG_STREAM_TIMEOUT", "180"))
JOB_HARD_TIMEOUT_SECONDS = int(os.getenv("GROK_IMG_JOB_TIMEOUT", "240"))

StatusCallback = Callable[[int, str], None]
ProgressCallback = Callable[[int, int], None]
ImageCallback = Callable[[int, str], None]
InfoCallback = Callable[[str], None]


def _safe_call(cb, *args) -> None:
    try:
        if cb:
            cb(*args)
    except Exception:
        pass


def _safe_filename(value: str, fallback: str) -> str:
    raw = (value or "").strip()
    raw = re.sub(r"[^a-zA-Z0-9\u00C0-\u024F\u1E00-\u1EFF ]", "", raw)
    raw = re.sub(r"\s+", "_", raw).strip("_")
    return raw[:50] or fallback


def _build_image_basename(idx: int, prompt: str | None, title: str | None) -> str:
    import datetime
    num = str(idx + 1).zfill(3)
    slug = _safe_filename(title or prompt or "", "image")
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return f"{num}_{slug}_{ts}"


async def _run_image_jobs_async_ui(
    prompts: list[str],
    cfg: CreateImageConfig,
    max_concurrency: int,
    on_status: StatusCallback | None,
    on_progress: ProgressCallback | None,
    on_image: ImageCallback | None,
    on_info: InfoCallback | None,
    stop_event: threading.Event | None = None,
    offscreen_chrome: bool = True,
    upscale_mode: str = "Không nâng cấp",
) -> None:
    def _stop_requested() -> bool:
        try:
            return bool(stop_event is not None and stop_event.is_set())
        except Exception:
            return False

    async def _await_with_stop(coro, *, step_name: str, idx: int | None = None, check_interval: float = 0.2):
        task = asyncio.create_task(coro)
        interval = max(0.05, float(check_interval or 0.2))
        try:
            while True:
                if _stop_requested():
                    try:
                        task.cancel()
                    except Exception:
                        pass
                    await asyncio.gather(task, return_exceptions=True)
                    if isinstance(idx, int):
                        _safe_call(on_status, idx, "Stop")
                    raise asyncio.CancelledError()
                if task.done():
                    return await task
                await asyncio.sleep(interval)
        finally:
            if _stop_requested() and not task.done():
                try:
                    task.cancel()
                except Exception:
                    pass

    if _stop_requested():
        _safe_call(on_info, "🛑 Đã nhận STOP trước khi mở Chrome GROK")
        return

    current_profile = grok_account_manager.get_active_profile()
    _safe_call(on_info, f"👤 Khởi chạy bằng tài khoản: {current_profile}")
    user_data_dir = resolve_profile_dir(current_profile)

    session = await open_chrome_session(
        host=CDP_HOST,
        port=CDP_PORT,
        user_data_dir=user_data_dir,
        start_url="https://grok.com/",
        cdp_wait_seconds=30,
        offscreen=bool(offscreen_chrome),
    )

    try:
        context = session.context
        page = None
        for candidate in list(context.pages):
            try:
                if not candidate.is_closed() and "grok.com" in (candidate.url or ""):
                    page = candidate
                    break
            except Exception:
                continue
        if page is None:
            page = await context.new_page()

        try:
            await _await_with_stop(
                page.goto("https://grok.com/", wait_until="domcontentloaded", timeout=30000),
                step_name="mở trang GROK",
            )
        except Exception:
            pass

        if _stop_requested():
            return

        _safe_call(on_info, "🔖 PHIÊN BẢN ẢNH: CREATE-IMAGE-v3 (Xoay vòng tài khoản tự động)")
        _safe_call(on_info, f"Lấy headers từ {current_profile}")
        headers = await _await_with_stop(
            auto_discover_statsig_headers(page, CACHE_PATH, current_profile, force=False, persist=True),
            step_name="lấy headers",
        )
        if _stop_requested():
            return

        # Token/Headers holder dùng chung giữa các luồng
        token_holder = {"headers": headers, "profile": current_profile}
        token_lock = asyncio.Lock()

        async def _rotate_account(failed_profile: str) -> dict:
            nonlocal session, page, context
            async with token_lock:
                if token_holder["profile"] != failed_profile:
                    return token_holder["headers"]
                
                _safe_call(on_info, f"⚠️ Tài khoản {failed_profile} đã báo HẾT LƯỢT. Đang chuyển đổi...")
                grok_account_manager.mark_profile_rate_limited(failed_profile)
                
                # Lấy profile tiếp theo trước khi đóng session cũ
                next_prof = grok_account_manager.get_next_active_profile()

                try:
                    await session.close(keep_chrome=False)
                except Exception:
                    pass
                
                _safe_call(on_info, f"🔄 Đang mở Chrome cho tài khoản tiếp theo: {next_prof}...")
                
                next_dir = resolve_profile_dir(next_prof)
                session = await open_chrome_session(
                    host=CDP_HOST,
                    port=CDP_PORT,
                    user_data_dir=next_dir,
                    start_url="https://grok.com/",
                    cdp_wait_seconds=30,
                    offscreen=bool(offscreen_chrome),
                )
                
                context = session.context
                page = None
                for candidate in list(context.pages):
                    try:
                        if not candidate.is_closed() and "grok.com" in (candidate.url or ""):
                            page = candidate
                            break
                    except Exception:
                        continue
                if page is None:
                    page = await context.new_page()
                    
                try:
                    await page.goto("https://grok.com/", wait_until="domcontentloaded", timeout=30000)
                except Exception:
                    pass
                    
                new_hd = await auto_discover_statsig_headers(page, CACHE_PATH, next_prof, force=True, persist=True)
                if not new_hd:
                    raise RuntimeError(f"Không lấy được Headers của tài khoản {next_prof}!")
                    
                try:
                    await page.goto("https://grok.com/imagine", wait_until="domcontentloaded", timeout=20000)
                except Exception:
                    pass
                    
                token_holder["headers"] = new_hd
                token_holder["profile"] = next_prof
                _safe_call(on_info, f"✅ Đã chuyển thành công sang tài khoản {next_prof}!")
                return new_hd

        # Throttle: tạo ảnh dùng web endpoint -> giãn cách request chống 403.
        # Ảnh nhanh hơn video nên gap ngắn hơn (2s), 3 luồng.
        GROK_IMG_CONCURRENCY = 3
        GROK_IMG_DELAY = 2.0
        sem = asyncio.Semaphore(GROK_IMG_CONCURRENCY)
        headers_lock = asyncio.Lock()
        _gap_lock = asyncio.Lock()
        _last_send = {"t": 0.0}

        async def _throttle():
            async with _gap_lock:
                import time as _t
                now = _t.monotonic()
                wait = GROK_IMG_DELAY - (now - _last_send["t"])
                if wait > 0:
                    await asyncio.sleep(wait)
                _last_send["t"] = _t.monotonic()

        async def run_one_job(idx: int, prompt: str) -> None:
            if _stop_requested():
                _safe_call(on_status, idx, "Stop")
                return

            async def handle_image_upscale_if_needed(saved_paths: list[str]) -> list[str]:
                if "AI" not in upscale_mode:
                    return saved_paths
                
                _safe_call(on_status, idx, "Nâng cấp AI")
                _safe_call(on_info, f"[GROK-IMG {idx+1}] Đang nâng cấp ảnh AI ({upscale_mode})...")
                
                loop = asyncio.get_running_loop()
                from grok_upscaler import upscale_image_ai
                
                new_saved = []
                for path_str in saved_paths:
                    path = Path(path_str)
                    suffix_lbl = "2k" if "2K" in upscale_mode else "4k"
                    out_path = path.parent / f"{path.stem}_{suffix_lbl}{path.suffix}"
                    
                    ok = await loop.run_in_executor(
                        None,
                        upscale_image_ai,
                        path,
                        out_path,
                        upscale_mode,
                        lambda msg: _safe_call(on_info, f"[GROK-IMG {idx+1}] {msg}")
                    )
                    if ok and out_path.exists():
                        try:
                            path.unlink(missing_ok=True)
                        except Exception:
                            pass
                        new_saved.append(str(out_path))
                    else:
                        new_saved.append(path_str)
                return new_saved

            async with sem:
                if _stop_requested():
                    _safe_call(on_status, idx, "Stop")
                    return

                _safe_call(on_status, idx, "Đang tạo ảnh")
                await _throttle()

                retries = 5
                result = None
                status = 0
                
                while retries > 0:
                    current_hd = token_holder["headers"]
                    current_prof = token_holder["profile"]
                    _safe_call(on_info, f"[GROK-IMG {idx+1}] tạo ảnh qua tài khoản {current_prof}: {prompt[:40]}")
                    
                    result = await _await_with_stop(
                        generate_image_in_page(page, prompt, current_hd, cfg,
                                               timeout_seconds=STREAM_TIMEOUT_SECONDS, job_index=idx),
                        step_name="tạo ảnh",
                        idx=idx,
                    )

                    status = int(result.get("status") or 0) if isinstance(result, dict) else 0
                    err = (result or {}).get("error") if isinstance(result, dict) else ""
                    
                    # Phát hiện cờ lỗi hết lượt (429 hoặc chữ limit trong lỗi)
                    is_rate_limit = False
                    if status == 429 or "limit" in str(err).lower() or "rate limit" in str(err).lower():
                        is_rate_limit = True

                    if is_rate_limit:
                        try:
                            await _rotate_account(current_prof)
                            retries -= 1
                            await _throttle()
                            continue
                        except grok_account_manager.AllAccountsExhaustedError as ae:
                            _safe_call(on_status, idx, "Hết tài khoản")
                            _safe_call(on_info, f"[GROK-IMG {idx+1}] dừng toàn bộ luồng: {ae}")
                            if stop_event is not None:
                                stop_event.set()
                            return
                        except Exception as rotate_exc:
                            _safe_call(on_status, idx, "Lỗi")
                            _safe_call(on_info, f"[GROK-IMG {idx+1}] lỗi chuyển tài khoản: {rotate_exc}")
                            return

                    # 403 -> refresh statsig của tài khoản hiện tại, thử lại 1 lần
                    if status == 403:
                        async with headers_lock:
                            _safe_call(on_info, f"[GROK-IMG {idx+1}] 403, refresh headers cho {current_prof}...")
                            new_hd = await _await_with_stop(
                                auto_discover_statsig_headers(page, CACHE_PATH, current_prof, force=True, persist=True),
                                step_name="refresh headers",
                                idx=idx,
                            )
                            if token_holder["profile"] == current_prof:
                                token_holder["headers"] = new_hd
                        await _throttle()
                        result = await _await_with_stop(
                            generate_image_in_page(page, prompt, token_holder["headers"], cfg,
                                                   timeout_seconds=STREAM_TIMEOUT_SECONDS, job_index=idx),
                            step_name="tạo lại ảnh",
                            idx=idx,
                        )
                        status = int(result.get("status") or 0) if isinstance(result, dict) else 0
                    
                    break

                if _stop_requested():
                    _safe_call(on_status, idx, "Stop")
                    return

                if not isinstance(result, dict) or result.get("error") or status != 200:
                    err = (result or {}).get("error") if isinstance(result, dict) else "unknown"
                    _safe_call(on_status, idx, f"Lỗi {status or ''}")
                    _safe_call(on_info, f"[GROK-IMG {idx+1}] lỗi: {err or status}")
                    return

                title = result.get("title") or ""
                base64_imgs = result.get("imageBase64") or []
                url_imgs = result.get("imageUrls") or []

                _safe_call(on_info, f"[GROK-IMG {idx+1}] stream trả về: {len(base64_imgs)} base64, {len(url_imgs)} url")
                if not base64_imgs and not url_imgs:
                    dbg = result.get("debugSample") or "(không có dữ liệu image trong stream)"
                    _safe_call(on_info, f"[GROK-IMG {idx+1}] DEBUG stream: {dbg[:800]}")

                _safe_call(on_progress, idx, 100)
                _safe_call(on_status, idx, "Đang lưu ảnh")
                basename = _build_image_basename(idx, prompt, title)
                base_no_ext = DOWNLOAD_DIR / basename
                saved: list[str] = []

                # Ưu tiên base64 (ảnh có sẵn trong stream)
                for i, b64 in enumerate(base64_imgs):
                    val = b64.get("data") if isinstance(b64, dict) else b64
                    out = save_base64_image(val, base_no_ext, i)
                    if out:
                        saved.append(str(out))

                # Fallback: tải từ URL (có thể là dict {imageUrl,...} hoặc string)
                if not saved:
                    for i, u in enumerate(url_imgs):
                        url_str = u.get("imageUrl") if isinstance(u, dict) else u
                        if not url_str:
                            continue
                        out = base_no_ext.with_name(f"{basename}_i{i}.jpg")
                        ok = await _await_with_stop(
                            download_image(context, url_str, out, timeout_ms=DOWNLOAD_TIMEOUT_MS, page=page),
                            step_name="tải ảnh",
                            idx=idx,
                        )
                        if ok:
                            saved.append(str(out))

                if not saved:
                    _safe_call(on_status, idx, "Lỗi lưu")
                    _safe_call(on_info, f"[GROK-IMG {idx+1}] không lưu được ảnh nào")
                    return

                # Báo ảnh đầu tiên (UI hiển thị); log tất cả
                final_saved = await handle_image_upscale_if_needed(saved)
                _safe_call(on_image, idx, final_saved[0])
                _safe_call(on_status, idx, "Hoàn thành")
                _safe_call(on_info, f"[GROK-IMG {idx+1}] hoàn thành | {len(final_saved)} ảnh")

        async def run_one_job_guarded(idx: int, prompt: str) -> None:
            timeout_seconds = max(60, int(JOB_HARD_TIMEOUT_SECONDS or 240))
            try:
                await asyncio.wait_for(run_one_job(idx, prompt), timeout=timeout_seconds)
            except asyncio.TimeoutError:
                if not _stop_requested():
                    _safe_call(on_status, idx, "Lỗi timeout")
                    _safe_call(on_info, f"[GROK-IMG {idx+1}] timeout sau {timeout_seconds}s")
            except asyncio.CancelledError:
                pass
            except Exception as e:
                _safe_call(on_status, idx, "Lỗi")
                _safe_call(on_info, f"[GROK-IMG {idx+1}] lỗi runtime: {e}")

        tasks = [asyncio.create_task(run_one_job_guarded(i, p)) for i, p in enumerate(prompts)]
        await asyncio.gather(*tasks, return_exceptions=True)
        _safe_call(on_info, "✅ GROK tạo ảnh hoàn tất.")

    finally:
        await session.close()


def run_create_image_jobs(
    prompts: list[str],
    aspect_ratio: str = "1:1",
    image_count: int = 2,
    max_concurrency: int = 3,
    download_dir: str | None = None,
    offscreen_chrome: bool = True,
    stop_event: threading.Event | None = None,
    on_status: StatusCallback | None = None,
    on_progress: ProgressCallback | None = None,
    on_image: ImageCallback | None = None,
    on_info: InfoCallback | None = None,
    upscale_mode: str = "Không nâng cấp",
) -> None:
    global DOWNLOAD_DIR
    cleaned = [p.strip() for p in (prompts or []) if isinstance(p, str) and p.strip()]
    if not cleaned:
        raise ValueError("Danh sách prompt rỗng.")

    if isinstance(download_dir, str) and download_dir.strip():
        try:
            DOWNLOAD_DIR = Path(download_dir.strip()) / "grok_image"
            DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    else:
        try:
            DOWNLOAD_DIR = Path(DOWNLOAD_DIR) / "grok_image"
            DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    ar = str(aspect_ratio or "1:1").strip()
    if ar not in {"1:1", "16:9", "9:16", "4:3", "3:4", "2:3", "3:2"}:
        ar = "1:1"

    cfg = CreateImageConfig(aspect_ratio=ar, image_count=int(image_count or 2))
    asyncio.run(
        _run_image_jobs_async_ui(
            prompts=cleaned,
            cfg=cfg,
            max_concurrency=max_concurrency,
            on_status=on_status,
            on_progress=on_progress,
            on_image=on_image,
            on_info=on_info,
            stop_event=stop_event,
            offscreen_chrome=bool(offscreen_chrome),
            upscale_mode=upscale_mode,
        )
    )

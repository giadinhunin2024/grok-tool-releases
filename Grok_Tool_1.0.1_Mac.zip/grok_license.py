import subprocess
import requests
import json
from pathlib import Path
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
    QPushButton, QMessageBox, QApplication, QFrame
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QPixmap

# Cấu hình URL Google Sheet Web App kích hoạt bản quyền của bạn tại đây
LICENSE_SERVER_URL = "https://script.google.com/macros/s/AKfycbzgkjgKQvvH2t40j4BwJIPA1M1dt7vCadzXgH8ftWAP1vb-Eu0KKdh8fhxKvWREZg-bgg/exec"

import sys
if getattr(sys, 'frozen', False):
    EXE_DIR = Path(sys.executable).resolve().parent
else:
    EXE_DIR = Path(__file__).resolve().parent

LICENSE_FILE = EXE_DIR / "grok_license_key.json"

def get_hwid() -> str:
    """Lấy Unique UUID phần cứng của hệ điều hành."""
    if sys.platform == "win32":
        try:
            output = subprocess.check_output('wmic csproduct get uuid', shell=True).decode().split()
            if len(output) >= 2:
                return output[1].strip()
        except Exception:
            pass
    elif sys.platform == "darwin":
        try:
            output = subprocess.check_output("ioreg -d2 -c IOPlatformExpertDevice | awk -F\\\" '/IOPlatformUUID/ {print $(NF-1)}'", shell=True).decode().strip()
            if output:
                return output
        except Exception:
            pass
            
    try:
        import uuid
        return f"FALLBACK-{uuid.getnode()}"
    except Exception:
        return "UNKNOWN-HWID"

def verify_license(key: str, hwid: str) -> dict:
    """Gửi yêu cầu xác thực key bản quyền lên Google Sheet Apps Script (thử lại 3 lần, timeout 30s)."""
    if not LICENSE_SERVER_URL or "YOUR_APPS_SCRIPT_ID" in LICENSE_SERVER_URL:
        return {"status": "error", "message": "Chưa cấu hình URL xác thực bản quyền (LICENSE_SERVER_URL)!"}
        
    params = {
        "action": "verify",
        "key": key.strip(),
        "hwid": hwid.strip()
    }
    
    last_exc = None
    for attempt in range(1, 4):
        try:
            resp = requests.get(LICENSE_SERVER_URL, params=params, timeout=30)
            if resp.status_code == 200:
                return resp.json()
            else:
                return {"status": "error", "message": f"Server phản hồi HTTP {resp.status_code} (Lần thử {attempt}/3)"}
        except requests.exceptions.RequestException as e:
            last_exc = e
            # Chờ 1 giây trước khi thử lại
            import time
            time.sleep(1.0)
            continue
        except Exception as e:
            return {"status": "error", "message": f"Lỗi hệ thống: {e}"}
            
    err_msg = f"Không thể kết nối đến server xác thực: {last_exc}\n\n👉 Mẹo: Kết nối mạng của bạn tới Google Script đang bị chậm/nghẽn. Hãy thử bật VPN (như 1.1.1.1) hoặc kiểm tra lại đường truyền mạng rồi bấm kích hoạt lại!"
    return {"status": "error", "message": err_msg}

class LicenseDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Xác thực bản quyền - GROK Tool")
        self.setFixedSize(620, 320)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)
        
        self.hwid = get_hwid()
        self.init_ui()
        self.apply_theme()
        self.load_qr_code()
        
    def init_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)
        
        # --- CỘT TRÁI: Nhập Key ---
        left_widget = QFrame(self)
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(15)
        
        title = QLabel("KÍCH HOẠT BẢN QUYỀN", self)
        title.setObjectName("dialogTitle")
        left_layout.addWidget(title)
        
        hint_lbl = QLabel("Vui lòng nhập Key kích hoạt để sử dụng phần mềm. Mỗi Key có thời hạn sử dụng riêng biệt.", self)
        hint_lbl.setWordWrap(True)
        hint_lbl.setObjectName("hintLabel")
        left_layout.addWidget(hint_lbl)
        
        self.key_edit = QLineEdit(self)
        self.key_edit.setPlaceholderText("Nhập key bản quyền tại đây...")
        self.key_edit.setMinimumHeight(40)
        
        # Load key cũ nếu có
        if LICENSE_FILE.exists():
            try:
                saved = json.loads(LICENSE_FILE.read_text(encoding="utf-8"))
                if saved.get("key"):
                    self.key_edit.setText(saved["key"])
            except Exception:
                pass
        left_layout.addWidget(self.key_edit)
        
        # Nút kích hoạt và thoát
        btn_layout = QHBoxLayout()
        exit_btn = QPushButton("Thoát", self)
        exit_btn.setMinimumHeight(36)
        exit_btn.clicked.connect(self.reject)
        
        self.activate_btn = QPushButton("Kích hoạt", self)
        self.activate_btn.setObjectName("primary")
        self.activate_btn.setMinimumHeight(36)
        self.activate_btn.clicked.connect(self.on_activate)
        
        btn_layout.addWidget(exit_btn)
        btn_layout.addWidget(self.activate_btn)
        left_layout.addLayout(btn_layout)
        left_layout.addStretch()
        
        # --- CỘT PHẢI: Thông tin hỗ trợ & QR Code Zalo ---
        right_widget = QFrame(self)
        right_widget.setObjectName("rightPanel")
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(15, 15, 15, 15)
        right_layout.setSpacing(10)
        right_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        contact_title = QLabel("LIÊN HỆ MUA KEY", self)
        contact_title.setObjectName("contactTitle")
        contact_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        right_layout.addWidget(contact_title)
        
        zalo_num = QLabel("📞 Zalo: 0982921046", self)
        zalo_num.setObjectName("zaloNum")
        zalo_num.setAlignment(Qt.AlignmentFlag.AlignCenter)
        right_layout.addWidget(zalo_num)
        
        # QR Code Label
        self.qr_label = QLabel(self)
        self.qr_label.setFixedSize(140, 140)
        self.qr_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.qr_label.setStyleSheet("background: #ffffff; border-radius: 6px;")
        right_layout.addWidget(self.qr_label)
        
        zalo_link = QLabel('<a href="https://zalo.me/0982921046" style="color: #22d3ee; text-decoration: none;">Chat Zalo Ngay</a>', self)
        zalo_link.setAlignment(Qt.AlignmentFlag.AlignCenter)
        zalo_link.setOpenExternalLinks(True)
        right_layout.addWidget(zalo_link)
        
        # Thêm vào layout chính
        main_layout.addWidget(left_widget, 6)
        main_layout.addWidget(right_widget, 4)
        
    def load_qr_code(self):
        """Tải mã QR Zalo từ API công cộng và hiển thị lên giao diện."""
        try:
            url = "https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=https://zalo.me/0982921046"
            resp = requests.get(url, timeout=5)
            if resp.status_code == 200:
                pix = QPixmap()
                pix.loadFromData(resp.content)
                self.qr_label.setPixmap(pix)
            else:
                self.qr_label.setText("No QR")
        except Exception:
            self.qr_label.setText("Lỗi mạng")
            
    def apply_theme(self):
        from theme import COLORS
        self.setStyleSheet(f"""
            QDialog {{
                background: {COLORS['bg2']};
                border: 1px solid {COLORS['border']};
            }}
            QFrame#rightPanel {{
                background: {COLORS['card']};
                border: 1px solid {COLORS['border']};
                border-radius: 12px;
            }}
            QLabel {{
                color: {COLORS['text']};
            }}
            QLabel#dialogTitle {{
                font-size: 18px;
                font-weight: bold;
                color: {COLORS['cyan']};
            }}
            QLabel#hintLabel {{
                font-size: 12px;
                color: {COLORS['text_dim']};
                line-height: 16px;
            }}
            QLabel#contactTitle {{
                font-size: 13px;
                font-weight: bold;
                color: {COLORS['yellow']};
            }}
            QLabel#zaloNum {{
                font-size: 12px;
                font-weight: bold;
                color: {COLORS['text']};
            }}
            QLineEdit {{
                background: {COLORS['card']};
                border: 1.5px solid {COLORS['border']};
                border-radius: 8px;
                padding: 6px 10px;
                color: {COLORS['text']};
                font-size: 13px;
            }}
            QLineEdit:focus {{
                border: 1.5px solid {COLORS['accent']};
            }}
            QPushButton {{
                background: {COLORS['card']};
                border: 1.5px solid {COLORS['border']};
                border-radius: 8px;
                padding: 6px 16px;
                color: {COLORS['text']};
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                border: 1.5px solid {COLORS['accent']};
                background: {COLORS['card_hover']};
            }}
            QPushButton#primary {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {COLORS['accent']}, stop:1 {COLORS['accent2']});
                border: none;
                color: white;
            }}
            QPushButton#primary:hover {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {COLORS['accent2']}, stop:1 {COLORS['cyan']});
            }}
        """)
        
    def on_activate(self):
        key = self.key_edit.text().strip()
        if not key:
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng nhập Key bản quyền!")
            return
            
        self.activate_btn.setEnabled(False)
        self.activate_btn.setText("Xác thực...")
        QApplication.processEvents()
        
        res = verify_license(key, self.hwid)
        
        self.activate_btn.setEnabled(True)
        self.activate_btn.setText("Kích hoạt")
        
        status = res.get("status")
        msg = res.get("message", "Lỗi xác thực")
        
        if status == "success":
            try:
                LICENSE_FILE.write_text(json.dumps({
                    "key": key,
                    "hwid": self.hwid,
                    "expiry": res.get("expiry", "")
                }, indent=2), encoding="utf-8")
            except Exception:
                pass
            QMessageBox.information(self, "Thành công", f"Kích hoạt thành công!\nHạn dùng: {res.get('expiry')}")
            self.accept()
        else:
            QMessageBox.critical(self, "Lỗi kích hoạt", msg)

def check_license_silent() -> bool:
    """Kiểm tra key bản quyền âm thầm khi khởi động.
    Trả về True nếu key hợp lệ và còn hạn (hỗ trợ chạy offline nếu server nghẽn nhưng key còn hạn).
    """
    if not LICENSE_FILE.exists():
        return False
    try:
        saved = json.loads(LICENSE_FILE.read_text(encoding="utf-8"))
        key = saved.get("key")
        hwid = saved.get("hwid")
        current_hwid = get_hwid()
        if not key or hwid != current_hwid:
            return False
            
        # Phân tích hạn dùng offline
        import datetime
        expiry_str = saved.get("expiry")
        expiry_dt = None
        if expiry_str:
            for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%SZ"):
                try:
                    expiry_dt = datetime.datetime.strptime(expiry_str, fmt)
                    break
                except Exception:
                    continue

        res = verify_license(key, current_hwid)
        status = res.get("status")
        
        if status == "success":
            # Cập nhật hạn dùng mới nhất từ server nếu kết nối thành công
            try:
                LICENSE_FILE.write_text(json.dumps({
                    "key": key,
                    "hwid": current_hwid,
                    "expiry": res.get("expiry", expiry_str)
                }, indent=2), encoding="utf-8")
            except Exception:
                pass
            return True
            
        elif status in ("invalid", "inactive", "expired", "bound_error"):
            # Server chủ động từ chối (Key bị khóa/hết hạn/sai máy) -> Xóa file kích hoạt
            try:
                LICENSE_FILE.unlink(missing_ok=True)
            except Exception:
                pass
            return False
            
        else:
            # Lỗi kết nối mạng (status == "error") -> Cho phép dùng offline nếu key trong máy vẫn còn hạn
            if expiry_dt:
                now_dt = datetime.datetime.utcnow() if "Z" in expiry_str else datetime.datetime.now()
                if now_dt < expiry_dt:
                    return True
    except Exception:
        pass
    return False

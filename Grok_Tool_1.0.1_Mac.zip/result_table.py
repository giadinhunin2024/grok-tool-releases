from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from PyQt6.QtCore import Qt, pyqtSignal, QSize
from PyQt6.QtGui import QPixmap, QImage
from PyQt6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from theme import COLORS


def open_in_explorer(path: str):
    """Mở file/thư mục trong trình quản lý file của hệ điều hành."""
    p = Path(path)
    if not p.exists():
        return
    try:
        if sys.platform.startswith("win"):
            if p.is_file():
                subprocess.Popen(["explorer", "/select,", str(p)])
            else:
                os.startfile(str(p))  # type: ignore
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R" if p.is_file() else "", str(p)])
        else:
            subprocess.Popen(["xdg-open", str(p.parent if p.is_file() else p)])
    except Exception:
        pass


class ClickableThumb(QLabel):
    """Thumbnail bấm được để mở file."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(96, 96)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet(
            f"background:{COLORS['bg2']}; border:1px solid {COLORS['border']};"
            f"border-radius:8px; color:{COLORS['text_dim']};"
        )
        self.setText("—")
        self._path = ""
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_media(self, path: str):
        self._path = path or ""
        if not self._path:
            self.setText("—")
            self.setStyleSheet(
                f"background:{COLORS['bg2']}; border:1px solid {COLORS['border']};"
                f"border-radius:8px; color:{COLORS['text_dim']};"
            )
            return
        p = Path(self._path)
        # Nếu là ảnh -> hiện ảnh
        if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}:
            pix = QPixmap(self._path)
            if not pix.isNull():
                self.setPixmap(pix.scaled(
                    QSize(92, 92), Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation))
                self.setStyleSheet(
                    f"background:{COLORS['bg2']}; border:1px solid {COLORS['border']};"
                    f"border-radius:8px; color:{COLORS['text_dim']};"
                )
                return
        # Nếu là video -> trích xuất frame đầu làm thumbnail
        if p.suffix.lower() in {".mp4", ".mov", ".avi", ".mkv", ".webm"}:
            if p.exists() and p.stat().st_size > 0:
                try:
                    import cv2
                    vidcap = cv2.VideoCapture(self._path)
                    success, image = vidcap.read()
                    vidcap.release()
                    if success:
                        height, width, channel = image.shape
                        bytesPerLine = 3 * width
                        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                        qimg = QImage(image_rgb.data, width, height, bytesPerLine, QImage.Format.Format_RGB888).copy()
                        pix = QPixmap.fromImage(qimg)
                        if not pix.isNull():
                            scaled_pix = pix.scaled(
                                QSize(92, 92), Qt.AspectRatioMode.KeepAspectRatio,
                                Qt.TransformationMode.SmoothTransformation)
                            
                            # Vẽ nút play đè lên ảnh đại diện video
                            from PyQt6.QtGui import QPainter, QColor
                            from PyQt6.QtCore import QPointF
                            
                            painter = QPainter(scaled_pix)
                            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
                            
                            # Vẽ vòng tròn nền mờ ở giữa
                            center_x = scaled_pix.width() // 2
                            center_y = scaled_pix.height() // 2
                            radius = 16
                            
                            painter.setBrush(QColor(0, 0, 0, 160))
                            painter.setPen(QColor(255, 255, 255, 200))
                            painter.drawEllipse(center_x - radius, center_y - radius, radius * 2, radius * 2)
                            
                            # Vẽ hình tam giác Play màu trắng
                            painter.setBrush(QColor(255, 255, 255, 220))
                            painter.setPen(Qt.PenStyle.NoPen)
                            
                            half_w = 5
                            half_h = 6
                            points = [
                                QPointF(center_x - half_w + 1, center_y - half_h),
                                QPointF(center_x - half_w + 1, center_y + half_h),
                                QPointF(center_x + half_w + 1, center_y)
                            ]
                            painter.drawPolygon(points)
                            painter.end()
                            
                            self.setPixmap(scaled_pix)
                            self.setStyleSheet(
                                f"background:{COLORS['bg2']}; border:1px solid {COLORS['border']};"
                                f"border-radius:8px; color:{COLORS['text_dim']};"
                            )
                            return
                except Exception as e:
                    print(f"Không thể trích xuất thumbnail video: {e}")

        # Trường hợp video lỗi hoặc không lấy được frame -> hiện icon mặc định
        self.setText("🎬\nxem")
        self.setStyleSheet(
            f"background:{COLORS['card']}; border:1px solid {COLORS['green']};"
            f"border-radius:8px; color:{COLORS['green']}; font-size:12px;"
        )

    def mousePressEvent(self, e):
        if self._path:
            open_in_explorer(self._path)


class ResultTable(QWidget):
    """Bảng kết quả đầy đủ: checkbox, thumbnail, trạng thái, mode, prompt + Sửa.
    Có thanh công cụ + bộ đếm. Phát signal khi bấm Tạo lại / Tạo lại lỗi / Nối / Cắt / Xóa."""

    retry_selected = pyqtSignal(list)   # list[int] row indices
    retry_failed = pyqtSignal()
    merge_videos = pyqtSignal(list)
    cut_last_frame = pyqtSignal(list)
    clear_results = pyqtSignal()
    edit_prompt = pyqtSignal(int)       # row index

    def __init__(self, mode_label: str = "", show_video_tools: bool = True, parent=None):
        super().__init__(parent)
        self._mode_label = mode_label
        self._show_video_tools = show_video_tools
        self._row_by_id: dict[str, int] = {}
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(8)

        # ===== Thanh công cụ =====
        toolbar = QHBoxLayout()
        toolbar.setSpacing(8)

        def tool_btn(text, slot, danger=False):
            b = QPushButton(text)
            b.setObjectName("danger" if danger else "")
            b.clicked.connect(slot)
            return b

        if self._show_video_tools:
            toolbar.addWidget(tool_btn("🔗 Nối video", lambda: self.merge_videos.emit(self.checked_rows())))
        toolbar.addWidget(tool_btn("🔁 Tạo lại", lambda: self.retry_selected.emit(self.checked_rows())))
        toolbar.addWidget(tool_btn("⚠️ Tạo lại lỗi", lambda: self.retry_failed.emit()))
        if self._show_video_tools:
            toolbar.addWidget(tool_btn("✂️ Cắt ảnh cuối", lambda: self.cut_last_frame.emit(self.checked_rows())))
        toolbar.addWidget(tool_btn("🗑 Xóa kết quả", lambda: self.clear_results.emit(), danger=True))
        toolbar.addStretch(1)
        root.addLayout(toolbar)

        # ===== Bộ đếm =====
        counters = QHBoxLayout()
        counters.setSpacing(16)
        self.lbl_done = QLabel("Hoàn thành: 0")
        self.lbl_done.setStyleSheet(f"color:{COLORS['green']}; font-weight:700;")
        self.lbl_running = QLabel("Đang tạo: 0")
        self.lbl_running.setStyleSheet(f"color:{COLORS['cyan']}; font-weight:700;")
        self.lbl_pending = QLabel("Đang chờ: 0")
        self.lbl_pending.setStyleSheet(f"color:{COLORS['text_dim']}; font-weight:700;")
        self.lbl_error = QLabel("Lỗi: 0")
        self.lbl_error.setStyleSheet(f"color:{COLORS['red']}; font-weight:700;")
        for w in (self.lbl_done, self.lbl_running, self.lbl_pending, self.lbl_error):
            counters.addWidget(w)
        counters.addStretch(1)
        root.addLayout(counters)

        # ===== Bảng =====
        headers = ["", "#", "Kết quả", "Trạng thái", "Mode", "Prompt", ""]
        self.table = QTableWidget(0, len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 36)
        self.table.setColumnWidth(1, 40)
        self.table.setColumnWidth(2, 110)
        self.table.setColumnWidth(3, 120)
        self.table.setColumnWidth(4, 150)
        self.table.setColumnWidth(6, 70)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setDefaultSectionSize(104)

        # checkbox "chọn tất cả" — đặt nút nhỏ trên thanh công cụ
        self._select_all = QCheckBox("Chọn tất cả")
        self._select_all.stateChanged.connect(self._toggle_all)
        counters.insertWidget(0, self._select_all)

        root.addWidget(self.table, 1)

        self._checks: list[QCheckBox] = []
        self._prompts: list[str] = []
        self._status: list[str] = []

    # ---------- API ----------
    def set_rows(self, items: list[dict], clear_state: bool = False):
        """items: [{id, prompt, mode}]"""
        # Lưu lại trạng thái cũ dựa trên prompt để khôi phục
        old_states = {}
        if not clear_state:
            for r in range(self.table.rowCount()):
                if r < len(self._prompts):
                    full_prompt = self._prompts[r]
                    status = self._status[r]
                    w = self.table.cellWidget(r, 2)
                    media_path = w._path if isinstance(w, ClickableThumb) else ""
                    old_states[full_prompt] = {"status": status, "media_path": media_path}

        self.table.setRowCount(0)
        self._row_by_id.clear()
        self._checks.clear()
        self._prompts.clear()
        self._status.clear()
        for i, it in enumerate(items):
            pid = str(it.get("id") or (i + 1))
            prompt = str(it.get("prompt") or "")
            r = self.table.rowCount()
            self.table.insertRow(r)

            # checkbox
            cb = QCheckBox()
            holder = QWidget(); hl = QHBoxLayout(holder)
            hl.setContentsMargins(10, 0, 0, 0); hl.addWidget(cb)
            self.table.setCellWidget(r, 0, holder)
            self._checks.append(cb)

            self.table.setItem(r, 1, QTableWidgetItem(pid))
            
            # ClickableThumb
            thumb = ClickableThumb()
            self.table.setCellWidget(r, 2, thumb)
            
            # Status
            status_text = "Chờ"
            
            # Khôi phục trạng thái cũ nếu trùng prompt
            if prompt in old_states:
                state = old_states[prompt]
                status_text = state["status"]
                if state["media_path"]:
                    thumb.set_media(state["media_path"])

            self.table.setItem(r, 3, QTableWidgetItem(status_text))
            self.table.setItem(r, 4, QTableWidgetItem(it.get("mode") or self._mode_label))
            self.table.setItem(r, 5, QTableWidgetItem(prompt[:120]))

            # nút Sửa
            btn = QPushButton("✏ Sửa")
            btn.clicked.connect(lambda _=False, row=r: self.edit_prompt.emit(row))
            self.table.setCellWidget(r, 6, btn)

            self._row_by_id[pid] = r
            self._prompts.append(prompt)
            self._status.append(status_text)
        self._update_counters()

    def add_rows(self, items: list[dict]):
        """items: [{id, prompt, mode}]"""
        for i, it in enumerate(items):
            pid = str(it.get("id"))
            if pid in self._row_by_id:
                continue
            r = self.table.rowCount()
            self.table.insertRow(r)

            # checkbox
            cb = QCheckBox()
            holder = QWidget(); hl = QHBoxLayout(holder)
            hl.setContentsMargins(10, 0, 0, 0); hl.addWidget(cb)
            self.table.setCellWidget(r, 0, holder)
            self._checks.append(cb)

            self.table.setItem(r, 1, QTableWidgetItem(pid))
            self.table.setCellWidget(r, 2, ClickableThumb())
            self.table.setItem(r, 3, QTableWidgetItem("Chờ"))
            self.table.setItem(r, 4, QTableWidgetItem(it.get("mode") or self._mode_label))
            self.table.setItem(r, 5, QTableWidgetItem(str(it.get("prompt") or "")[:120]))

            # nút Sửa
            btn = QPushButton("✏ Sửa")
            btn.clicked.connect(lambda _=False, row=r: self.edit_prompt.emit(row))
            self.table.setCellWidget(r, 6, btn)

            self._row_by_id[pid] = r
            self._prompts.append(str(it.get("prompt") or ""))
            self._status.append("Chờ")
        self._update_counters()

    def checked_rows(self) -> list[int]:
        return [i for i, cb in enumerate(self._checks) if cb.isChecked()]

    def failed_rows(self) -> list[int]:
        return [i for i, s in enumerate(self._status) if "lỗi" in s.lower() or "lỗi" in s.lower()]

    def get_prompt(self, row: int) -> str:
        if 0 <= row < len(self._prompts):
            return self._prompts[row]
        return ""

    def set_prompt(self, row: int, text: str):
        if 0 <= row < len(self._prompts):
            self._prompts[row] = text
            self.table.setItem(row, 5, QTableWidgetItem(text[:120]))

    def set_status(self, pid: str, text: str = None, progress: int = None):
        r = self._row_by_id.get(str(pid))
        if r is None:
            return
        if text is not None:
            self.table.setItem(r, 3, QTableWidgetItem(text))
            if r < len(self._status):
                self._status[r] = text
        elif progress is not None:
            self.table.setItem(r, 3, QTableWidgetItem(f"{progress}%"))
            if r < len(self._status):
                self._status[r] = f"{progress}%"
        self._update_counters()

    def set_media(self, pid: str, path: str):
        r = self._row_by_id.get(str(pid))
        if r is None:
            return
        w = self.table.cellWidget(r, 2)
        if isinstance(w, ClickableThumb):
            w.set_media(path)
        self.table.setItem(r, 3, QTableWidgetItem("✅ Hoàn thành"))
        if r < len(self._status):
            self._status[r] = "✅ Hoàn thành"
        self._update_counters()

    def get_video_path(self, row: int) -> str:
        """Lấy đường dẫn tệp video của một dòng."""
        w = self.table.cellWidget(row, 2)
        if isinstance(w, ClickableThumb):
            return w._path
        return ""

    def _toggle_all(self, state):
        checked = state == Qt.CheckState.Checked.value
        for cb in self._checks:
            cb.setChecked(checked)

    def _update_counters(self):
        done = running = pending = error = 0
        for s in self._status:
            sl = s.lower()
            if "hoàn thành" in sl or "✅" in s:
                done += 1
            elif "lỗi" in sl or "❌" in s:
                error += 1
            elif "chờ" in sl:
                pending += 1
            else:
                running += 1
        self.lbl_done.setText(f"Hoàn thành: {done}")
        self.lbl_running.setText(f"Đang tạo: {running}")
        self.lbl_pending.setText(f"Đang chờ: {pending}")
        self.lbl_error.setText(f"Lỗi: {error}")

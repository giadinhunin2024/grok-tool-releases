import sys
import json
from pathlib import Path

if getattr(sys, 'frozen', False):
    WORKSPACE_DIR = Path(sys.executable).resolve().parent
else:
    WORKSPACE_DIR = Path(__file__).resolve().parent

PROFILES_CONFIG_FILE = WORKSPACE_DIR / "grok_profiles.json"

# Tập hợp các profile đang bị hết lượt trong phiên chạy hiện tại
_RATE_LIMITED_PROFILES = set()

# Profile đang được chọn hoạt động chính
_CURRENT_ACTIVE_PROFILE = "PROFILE_1"

class AllAccountsExhaustedError(Exception):
    """Lỗi ném ra khi toàn bộ tài khoản trong danh sách đều đã hết lượt."""
    pass

def load_profiles_info() -> dict:
    """Tải thông tin chi tiết các profile (gồm email, password) từ file json."""
    if not PROFILES_CONFIG_FILE.is_file():
        default_data = {"PROFILE_1": {"email": "", "password": ""}}
        save_profiles_info(default_data)
        return default_data
    try:
        with open(PROFILES_CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                # Backwards compatibility: convert list of strings to dict
                new_data = {}
                for p in data:
                    p_clean = str(p or "").strip()
                    if p_clean:
                        new_data[p_clean] = {"email": "", "password": ""}
                save_profiles_info(new_data)
                return new_data
            elif isinstance(data, dict):
                res = {}
                for k, v in data.items():
                    k_clean = str(k or "").strip()
                    if k_clean:
                        if isinstance(v, dict):
                            res[k_clean] = {
                                "email": str(v.get("email") or "").strip(),
                                "password": str(v.get("password") or "").strip()
                            }
                        else:
                            res[k_clean] = {"email": "", "password": ""}
                return res
    except Exception:
        pass
    return {"PROFILE_1": {"email": "", "password": ""}}

def save_profiles_info(info_dict: dict) -> None:
    """Lưu thông tin chi tiết các profile vào file json."""
    try:
        with open(PROFILES_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(info_dict, f, indent=4, ensure_ascii=False)
    except Exception:
        pass

def load_profiles() -> list[str]:
    """Tải danh sách profile từ file cấu hình json."""
    return list(load_profiles_info().keys())

def save_profiles(profiles_list: list[str]) -> None:
    """Lưu danh sách profile vào file cấu hình json."""
    current_info = load_profiles_info()
    new_info = {}
    for p in profiles_list:
        p_clean = str(p or "").strip()
        if p_clean:
            if p_clean in current_info:
                new_info[p_clean] = current_info[p_clean]
            else:
                new_info[p_clean] = {"email": "", "password": ""}
    if not new_info:
        new_info = {"PROFILE_1": {"email": "", "password": ""}}
    save_profiles_info(new_info)

def update_profile_credentials(profile_name: str, email: str, password: str) -> None:
    """Cập nhật tài khoản và mật khẩu của profile."""
    info = load_profiles_info()
    p_clean = str(profile_name or "").strip()
    if p_clean in info:
        info[p_clean]["email"] = str(email or "").strip()
        info[p_clean]["password"] = str(password or "").strip()
        save_profiles_info(info)

def get_profiles() -> list[str]:
    """Lấy danh sách các profile hiện có."""
    return load_profiles()

def add_profile() -> str:
    """Tự động thêm một profile mới (ví dụ: PROFILE_2, PROFILE_3) và lưu lại."""
    profiles = load_profiles()
    
    # Tìm chỉ số số lớn nhất hiện có trong tên PROFILE_X
    max_idx = 1
    import re
    for p in profiles:
        m = re.match(r"^PROFILE_(\d+)$", p, re.IGNORECASE)
        if m:
            idx = int(m.group(1))
            if idx > max_idx:
                max_idx = idx
                
    new_profile_name = f"PROFILE_{max_idx + 1}"
    profiles.append(new_profile_name)
    save_profiles(profiles)
    return new_profile_name

def delete_profile(profile_name: str) -> None:
    """Xóa một profile khỏi danh sách cấu hình và xóa cờ hết lượt của nó."""
    profiles = load_profiles()
    profile_name = str(profile_name).strip()
    if profile_name in profiles:
        profiles.remove(profile_name)
        if not profiles:
            profiles = ["PROFILE_1"]
        save_profiles(profiles)
        
    global _CURRENT_ACTIVE_PROFILE
    if _CURRENT_ACTIVE_PROFILE == profile_name:
        _CURRENT_ACTIVE_PROFILE = profiles[0]
        
    if profile_name in _RATE_LIMITED_PROFILES:
        _RATE_LIMITED_PROFILES.remove(profile_name)

def get_active_profile() -> str:
    """Lấy profile đang hoạt động chính hiện tại."""
    global _CURRENT_ACTIVE_PROFILE
    profiles = load_profiles()
    if _CURRENT_ACTIVE_PROFILE not in profiles:
        _CURRENT_ACTIVE_PROFILE = profiles[0]
    return _CURRENT_ACTIVE_PROFILE

def set_active_profile(profile_name: str) -> None:
    """Thiết lập profile hoạt động chính."""
    global _CURRENT_ACTIVE_PROFILE
    profiles = load_profiles()
    profile_name = str(profile_name).strip()
    if profile_name in profiles:
        _CURRENT_ACTIVE_PROFILE = profile_name

def mark_profile_rate_limited(profile_name: str) -> None:
    """Đánh dấu một profile đã hết lượt sử dụng."""
    profile_name = str(profile_name).strip()
    _RATE_LIMITED_PROFILES.add(profile_name)

def is_profile_rate_limited(profile_name: str) -> bool:
    """Kiểm tra xem profile có đang bị hết lượt không."""
    return str(profile_name).strip() in _RATE_LIMITED_PROFILES

def reset_rate_limits() -> None:
    """Xóa bỏ đánh dấu hết lượt của tất cả tài khoản để chạy lại từ đầu."""
    _RATE_LIMITED_PROFILES.clear()

def all_profiles_rate_limited() -> bool:
    """Kiểm tra xem tất cả các tài khoản có đang bị báo hết lượt hay không."""
    profiles = load_profiles()
    return len(profiles) > 0 and all(p in _RATE_LIMITED_PROFILES for p in profiles)

def get_next_active_profile() -> str:
    """
    Tìm kiếm và chuyển sang profile tiếp theo chưa bị hết lượt.
    Nếu toàn bộ các tài khoản đều đã hết lượt, ném ra lỗi AllAccountsExhaustedError.
    """
    global _CURRENT_ACTIVE_PROFILE
    profiles = load_profiles()
    
    # Tìm kiếm xoay vòng bắt đầu từ vị trí sau profile hiện tại
    try:
        current_idx = profiles.index(_CURRENT_ACTIVE_PROFILE)
    except ValueError:
        current_idx = 0
        
    n = len(profiles)
    for i in range(1, n + 1):
        idx = (current_idx + i) % n
        candidate = profiles[idx]
        if candidate not in _RATE_LIMITED_PROFILES:
            _CURRENT_ACTIVE_PROFILE = candidate
            return candidate
            
    # Nếu kiểm tra hết danh sách vẫn không thấy profile nào trống
    raise AllAccountsExhaustedError("Tất cả các tài khoản đăng nhập đều đã báo hết lượt tạo ảnh/video!")

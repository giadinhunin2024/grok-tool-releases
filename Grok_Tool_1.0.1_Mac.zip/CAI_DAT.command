#!/bin/bash
# CAI_DAT.command - Tự động cài đặt 100% môi trường cho Grok Tool trên macOS

# Chuyển vào thư mục chứa script
cd "$(dirname "$0")"

echo "========================================================="
echo "  TỰ ĐỘNG CÀI ĐẶT MÔI TRƯỜNG CHO GROK TOOL (macOS)"
echo "========================================================="
echo ""

# 1. Kiểm tra Homebrew (công cụ cài đặt ứng dụng cho Mac)
if ! command -v brew &> /dev/null; then
    echo "[!] Không tìm thấy Homebrew. Đang tiến hành cài đặt Homebrew..."
    echo "    (Quá trình này có thể yêu cầu bạn nhập Mật khẩu máy Mac của bạn)"
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    
    # Kích hoạt brew trong session hiện tại
    eval "$(/opt/homebrew/bin/brew shellenv)" &> /dev/null
    eval "$(/usr/local/bin/brew shellenv)" &> /dev/null
else
    echo "[✓] Đã tìm thấy Homebrew."
fi

# Đảm bảo brew có trong PATH cho các lệnh tiếp theo
if command -v brew &> /dev/null; then
    eval "$(brew shellenv)"
fi

# 2. Kiểm tra và cài đặt Python 3
if ! command -v python3 &> /dev/null; then
    echo "[!] Không tìm thấy Python 3. Đang cài đặt Python 3..."
    brew install python
else
    echo "[✓] Đã cài đặt Python 3: $(python3 --version)"
fi

# 3. Kiểm tra và cài đặt FFmpeg (xử lý video)
if ! command -v ffmpeg &> /dev/null; then
    echo "[!] Không tìm thấy FFmpeg. Đang cài đặt FFmpeg..."
    brew install ffmpeg
else
    echo "[✓] Đã cài đặt FFmpeg."
fi

# 4. Cài đặt các thư viện Python
echo ""
echo "---------------------------------------------------------"
echo "[1/2] Đang cài đặt các thư viện PyQt6 và Playwright..."
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt

# 5. Cài đặt trình duyệt ẩn cho Playwright
echo ""
echo "---------------------------------------------------------"
echo "[2/2] Đang tải Chromium cho trình duyệt đăng nhập GROK..."
python3 -m playwright install chromium

echo ""
echo "========================================================="
echo "  CÀI ĐẶT HOÀN TẤT!"
echo "  Bây giờ bạn có thể click đúp file CHAY_TOOL.command để chạy."
echo "========================================================="
read -p "Nhấn Enter để đóng cửa sổ này..."

from __future__ import annotations

import asyncio
import os
import re
import threading
from pathlib import Path
from typing import Callable

from grok_api_create_image import (
    CreateImageConfig,
    generate_ref_image_in_page,
    download_image,
    save_base64_image,
)
from grok_api_text_to_video import auto_discover_statsig_headers
from grok_chrome_manager import open_chrome_session, resolve_profile_dir
import grok_account_manager


CDP_HOST = os.getenv("GROK_CDP_HOST", os.getenv("CDP_HOST", "127.0.0.1"))
CDP_PORT = int(os.getenv("GROK_CDP_PORT", os.getenv("CDP_PORT", "9223")))

import sys

if getattr(sys, 'frozen', False):
    WORKSPACE_DIR = Path(sys.executable).resolve().parent
else:
    WORKSPACE_DIR = Path(__file__).resolve().parent
PROFILE_NAME = os.getenv("GROK_PROFILE_NAME", os.getenv("PROFILE_NAME", "PROFILE_1"))
USER_DATA_DIR = resolve_profile_dir(PROFILE_NAME)
CACHE_PATH = Path(os.getenv("GROK_CACHE_PATH", str(WORKSPACE_DIR / "grok_cache.json")))

DOWNLOAD_DIR = Path(os.getenv("GROK_DOWNLOAD_DIR", str(WORKSPACE_DIR / "downloads")))
DOWNLOAD_TIMEOUT_MS = int(os.getenv("GROK_DOWNLOAD_TIMEOUT_MS", "120000"))
STREAM_TIMEOUT_SECONDS = int(os.getenv("GROK_IMG_STREAM_TIMEOUT", "180"))
JOB_HARD_TIMEOUT_SECONDS = int(os.getenv("GROK_IMG_JOB_TIMEOUT", "240"))

StatusCallback = Callable[[int, str], None]
ProgressCallback = Callable[[int, int], None]
ImageCallback = Callable[[int, str], None]
InfoCallback = Callable[[str], None]


def _safe_call(cb, *args) -> None:
    try:
        if cb:
            cb(*args)
    except Exception:
        pass


def _safe_filename(value: str, fallback: str) -> str:
    raw = (value or "").strip()
    raw = re.sub(r"[^a-zA-Z0-9\u00C0-\u024F\u1E00-\u1EFF ]", "", raw)
    raw = re.sub(r"\s+", "_", raw).strip("_")
    return raw[:50] or fallback


def _build_image_basename(idx: int, angle_code: str, title: str | None) -> str:
    import datetime
    num = str(idx + 1).zfill(3)
    slug = _safe_filename(title or angle_code or "image", "image")
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return f"{num}_{slug}_{ts}"


async def _run_ref_image_jobs_async(
    char_image_path: str,
    outfit_image_path: str,
    common_prompt: str,
    cfg: CreateImageConfig,
    max_concurrency: int,
    on_status: StatusCallback | None,
    on_progress: ProgressCallback | None,
    on_image: ImageCallback | None,
    on_info: InfoCallback | None,
    stop_event: threading.Event | None = None,
    offscreen_chrome: bool = True,
    upscale_mode: str = "Không nâng cấp",
    custom_prompts: list = None,
    run_indices: list = None,
) -> None:
    def _stop_requested() -> bool:
        try:
            return bool(stop_event is not None and stop_event.is_set())
        except Exception:
            return False

    async def _await_with_stop(coro, *, step_name: str, idx: int | None = None, check_interval: float = 0.2):
        task = asyncio.create_task(coro)
        interval = max(0.05, float(check_interval or 0.2))
        try:
            while True:
                if _stop_requested():
                    try:
                        task.cancel()
                    except Exception:
                        pass
                    await asyncio.gather(task, return_exceptions=True)
                    if isinstance(idx, int):
                        _safe_call(on_status, idx, "Stop")
                    raise asyncio.CancelledError()
                if task.done():
                    return await task
                await asyncio.sleep(interval)
        finally:
            if _stop_requested() and not task.done():
                try:
                    task.cancel()
                except Exception:
                    pass

    if _stop_requested():
        _safe_call(on_info, "🛑 Đã nhận STOP trước khi mở Chrome GROK")
        return

    current_profile = grok_account_manager.get_active_profile()
    _safe_call(on_info, f"👤 Khởi chạy bằng tài khoản: {current_profile}")
    user_data_dir = resolve_profile_dir(current_profile)

    session = await open_chrome_session(
        host=CDP_HOST,
        port=CDP_PORT,
        user_data_dir=user_data_dir,
        start_url="https://grok.com/",
        cdp_wait_seconds=30,
        offscreen=bool(offscreen_chrome),
    )

    try:
        context = session.context
        page = None
        for candidate in list(context.pages):
            try:
                if not candidate.is_closed() and "grok.com" in (candidate.url or ""):
                    page = candidate
                    break
            except Exception:
                continue
        if page is None:
            page = await context.new_page()

        try:
            await _await_with_stop(
                page.goto("https://grok.com/", wait_until="domcontentloaded", timeout=30000),
                step_name="mở trang GROK",
            )
        except Exception:
            pass

        _safe_call(on_info, "🚀 Khởi động luồng Ghép Trang Phục (Xoay vòng tài khoản)")
        _safe_call(on_info, "🔍 Đang tự động quét thông tin xác thực statsig headers...")
        headers = await _await_with_stop(
            auto_discover_statsig_headers(page, CACHE_PATH, current_profile, force=True, persist=False),
            step_name="lấy statsig headers",
        )
        if not headers or not headers.get("x-statsig-id"):
            _safe_call(on_info, "❌ Không lấy được statsig headers. Hãy đăng nhập Grok trong Chrome.")
            return

        # Token/Profile holder dùng chung giữa các luồng
        token_holder = {"headers": headers, "profile": current_profile}
        token_lock = asyncio.Lock()

        async def _rotate_account(failed_profile: str) -> dict:
            nonlocal session, page, context
            async with token_lock:
                if token_holder["profile"] != failed_profile:
                    return token_holder["headers"]
                
                _safe_call(on_info, f"⚠️ Tài khoản {failed_profile} đã báo HẾT LƯỢT. Đang chuyển đổi...")
                grok_account_manager.mark_profile_rate_limited(failed_profile)
                
                # Lấy profile tiếp theo trước khi đóng session cũ
                next_prof = grok_account_manager.get_next_active_profile()

                try:
                    await session.close(keep_chrome=False)
                except Exception:
                    pass
                
                _safe_call(on_info, f"🔄 Đang mở Chrome cho tài khoản tiếp theo: {next_prof}...")
                
                next_dir = resolve_profile_dir(next_prof)
                session = await open_chrome_session(
                    host=CDP_HOST,
                    port=CDP_PORT,
                    user_data_dir=next_dir,
                    start_url="https://grok.com/",
                    cdp_wait_seconds=30,
                    offscreen=bool(offscreen_chrome),
                )
                
                context = session.context
                page = None
                for candidate in list(context.pages):
                    try:
                        if not candidate.is_closed() and "grok.com" in (candidate.url or ""):
                            page = candidate
                            break
                    except Exception:
                        continue
                if page is None:
                    page = await context.new_page()
                    
                try:
                    await page.goto("https://grok.com/", wait_until="domcontentloaded", timeout=30000)
                except Exception:
                    pass
                    
                new_headers = await auto_discover_statsig_headers(page, CACHE_PATH, next_prof, force=True, persist=False)
                if not new_headers or not new_headers.get("x-statsig-id"):
                    raise RuntimeError(f"Không lấy được Headers của tài khoản {next_prof}!")
                    
                token_holder["headers"] = new_headers
                token_holder["profile"] = next_prof
                _safe_call(on_info, f"✅ Đã chuyển thành công sang tài khoản {next_prof}!")
                return new_headers

        # 6 Camera Angles
        ANGLES = [
            ("truoc_1", "front view, full body shot, standing straight"),
            ("truoc_2", "slight front three-quarters angle view, full body shot"),
            ("ben_1", "left side profile view, full body shot"),
            ("ben_2", "right side profile view, full body shot"),
            ("sau_1", "back view, full body shot, standing straight"),
            ("sau_2", "back three-quarters angle view, full body shot"),
        ]

        # Xây dựng 6 prompt cho 6 góc
        jobs_data = []
        for i, (code, desc) in enumerate(ANGLES):
            # Nếu có chỉ số chạy cụ thể và i không nằm trong đó, bỏ qua
            if run_indices is not None and i not in run_indices:
                continue
            # Sử dụng prompt tùy chỉnh nếu có, ngược lại dùng prompt mặc định
            if custom_prompts and i < len(custom_prompts) and custom_prompts[i].strip():
                prompt = custom_prompts[i].strip()
            else:
                prompt = f"A high-quality full-body fashion photograph of the character from reference image 1, wearing the exact same outfit shown in reference image 2. Camera angle: {desc}."
                if common_prompt.strip():
                    prompt += f" Additional requirements: {common_prompt.strip()}."
            jobs_data.append((i, code, prompt))

        # Cài đặt concurrency
        sem = asyncio.Semaphore(max(1, max_concurrency))
        headers_lock = asyncio.Lock()
        api_lock = asyncio.Lock()
        _gap_lock = asyncio.Lock()
        _last_send = {"t": 0.0}

        async def _throttle():
            async with _gap_lock:
                import time as _t
                now = _t.monotonic()
                wait = 2.0 - (now - _last_send["t"]) # Gap 2s
                if wait > 0:
                    await asyncio.sleep(wait)
                _last_send["t"] = _t.monotonic()

        async def run_one_job(idx: int, angle_code: str, prompt: str) -> None:
            if _stop_requested():
                _safe_call(on_status, idx, "Stop")
                return

            async def handle_image_upscale_if_needed(saved_paths: list[Path]) -> list[Path]:
                if "AI" not in upscale_mode:
                    return saved_paths
                
                _safe_call(on_status, idx, "Nâng cấp AI")
                _safe_call(on_info, f"[GROK-REF {idx+1}] Đang nâng cấp ảnh AI ({upscale_mode})...")
                
                loop = asyncio.get_running_loop()
                from grok_upscaler import upscale_image_ai
                
                new_saved = []
                for path in saved_paths:
                    suffix_lbl = "2k" if "2K" in upscale_mode else "4k"
                    out_path = path.parent / f"{path.stem}_{suffix_lbl}{path.suffix}"
                    
                    ok = await loop.run_in_executor(
                        None,
                        upscale_image_ai,
                        path,
                        out_path,
                        upscale_mode,
                        lambda msg: _safe_call(on_info, f"[GROK-REF {idx+1}] {msg}")
                    )
                    if ok and out_path.exists():
                        try:
                            path.unlink(missing_ok=True)
                        except Exception:
                            pass
                        new_saved.append(out_path)
                    else:
                        new_saved.append(path)
                return new_saved

            async with sem:
                if _stop_requested():
                    _safe_call(on_status, idx, "Stop")
                    return

                _safe_call(on_status, idx, "Đang ghép...")
                await _throttle()

                ref_paths = [char_image_path, outfit_image_path]

                retries = 5
                result = None
                status = 0
                
                async with api_lock:
                    while retries > 0:
                        current_headers = token_holder["headers"]
                        current_prof = token_holder["profile"]
                        _safe_call(on_info, f"[GROK-REF {idx+1}] gửi request ghép góc '{angle_code}' (REST) qua tài khoản {current_prof}")
                        
                        try:
                            result = await _await_with_stop(
                                generate_ref_image_in_page(
                                    page=page,
                                    prompt=prompt,
                                    ref_image_paths=ref_paths,
                                    statsig_headers=current_headers,
                                    cfg=cfg,
                                    timeout_seconds=STREAM_TIMEOUT_SECONDS
                                ),
                                step_name=f"tạo ảnh góc {angle_code}",
                                idx=idx,
                            )
                        except Exception as e:
                            _safe_call(on_info, f"[GROK-REF {idx+1}] ⚠️ Lỗi gọi API (mất kết nối/đổi tài khoản): {e}. Đang chờ ổn định và tự động thử lại...")
                            await asyncio.sleep(4)
                            retries -= 1
                            continue

                        status = int(result.get("status") or 0) if isinstance(result, dict) else 0
                        err = (result or {}).get("error") if isinstance(result, dict) else ""
                        
                        # Phát hiện rate limit (chỉ 429 hoặc chữ limit trong lỗi)
                        is_rate_limit = False
                        if status == 429 or "limit" in str(err).lower() or "rate limit" in str(err).lower():
                            is_rate_limit = True

                        if is_rate_limit:
                            try:
                                await _rotate_account(current_prof)
                                retries -= 1
                                await _throttle()
                                continue
                            except grok_account_manager.AllAccountsExhaustedError as ae:
                                _safe_call(on_status, idx, "Hết tài khoản")
                                _safe_call(on_info, f"[GROK-REF {idx+1}] dừng toàn bộ luồng: {ae}")
                                if stop_event is not None:
                                    stop_event.set()
                                return
                            except Exception as rotate_exc:
                                _safe_call(on_status, idx, "Lỗi")
                                _safe_call(on_info, f"[GROK-REF {idx+1}] lỗi chuyển tài khoản: {rotate_exc}")
                                return

                        # 401 hoặc 403 -> refresh headers của tài khoản hiện tại và thử lại
                        if status in (401, 403):
                            _safe_call(on_info, f"[GROK-REF {idx+1}] Cookies/Headers hết hạn trên {current_prof}, đang làm mới...")
                            new_headers = await _await_with_stop(
                                auto_discover_statsig_headers(page, CACHE_PATH, current_prof, force=True, persist=False),
                                step_name="lấy lại statsig headers",
                                idx=idx,
                            )
                            if token_holder["profile"] == current_prof and new_headers:
                                token_holder["headers"] = new_headers
                            
                            await _throttle()
                            result = await _await_with_stop(
                                generate_ref_image_in_page(
                                    page=page,
                                    prompt=prompt,
                                    ref_image_paths=ref_paths,
                                    statsig_headers=token_holder["headers"],
                                    cfg=cfg,
                                    timeout_seconds=STREAM_TIMEOUT_SECONDS
                                ),
                                step_name=f"tạo lại ảnh góc {angle_code}",
                                idx=idx,
                            )
                            status = int(result.get("status") or 0) if isinstance(result, dict) else 0
                        
                        break

                if _stop_requested():
                    _safe_call(on_status, idx, "Stop")
                    return

                if not isinstance(result, dict) or result.get("error") or status != 200:
                    err = (result or {}).get("error") if isinstance(result, dict) else "unknown"
                    _safe_call(on_status, idx, f"Lỗi {status or ''}")
                    _safe_call(on_info, f"[GROK-REF {idx+1}] lỗi: {err or status}")
                    return

                title = result.get("title") or ""
                base64_imgs = result.get("imageBase64") or []
                urls = result.get("imageUrls") or []

                basename = _build_image_basename(idx, angle_code, title)
                download_dir = Path(DOWNLOAD_DIR)
                download_dir.mkdir(parents=True, exist_ok=True)

                saved_paths = []

                # 1. Lưu ảnh base64 trước
                for file_idx, b64 in enumerate(base64_imgs):
                    p = save_base64_image(b64, download_dir / basename, file_idx)
                    if p:
                        saved_paths.append(p)

                # 2. Tải ảnh từ URL
                for file_idx, url in enumerate(urls):
                    p = download_dir / f"{basename}_i{file_idx}.jpg"
                    ok = await download_image(context, url, p, DOWNLOAD_TIMEOUT_MS, page)
                    if ok:
                        saved_paths.append(p)

                if not saved_paths:
                    _safe_call(on_status, idx, "Lỗi tải ảnh")
                    _safe_call(on_info, f"[GROK-REF {idx+1}] Lỗi: Không lưu được bức ảnh nào.")
                    return

                final_saved = await handle_image_upscale_if_needed(saved_paths)
                final_path = str(final_saved[0].resolve())
                _safe_call(on_image, idx, final_path)
                _safe_call(on_status, idx, "Hoàn thành")

        # Chạy song song 6 jobs
        tasks = [
            run_one_job(idx, code, prompt)
            for idx, code, prompt in jobs_data
        ]
        await asyncio.gather(*tasks)

    finally:
        try:
            await session.stop()
        except Exception:
            pass


def run_ref_image_jobs(
    char_image_path: str,
    outfit_image_path: str,
    common_prompt: str,
    aspect_ratio: str,
    max_concurrency: int,
    download_dir: str,
    offscreen_chrome: bool = True,
    stop_event: threading.Event | None = None,
    on_status: StatusCallback | None = None,
    on_progress: ProgressCallback | None = None,
    on_image: ImageCallback | None = None,
    on_info: InfoCallback | None = None,
    upscale_mode: str = "Không nâng cấp",
    custom_prompts: list = None,
    run_indices: list = None,
) -> None:
    global DOWNLOAD_DIR
    if isinstance(download_dir, str) and download_dir.strip():
        try:
            DOWNLOAD_DIR = Path(download_dir.strip()) / "grok_image"
            DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    cfg = CreateImageConfig(aspect_ratio=aspect_ratio, image_count=1)

    async def _main():
        await _run_ref_image_jobs_async(
            char_image_path=char_image_path,
            outfit_image_path=outfit_image_path,
            common_prompt=common_prompt,
            cfg=cfg,
            max_concurrency=max_concurrency,
            on_status=on_status,
            on_progress=on_progress,
            on_image=on_image,
            on_info=on_info,
            stop_event=stop_event,
            offscreen_chrome=offscreen_chrome,
            upscale_mode=upscale_mode,
            custom_prompts=custom_prompts,
            run_indices=run_indices,
        )

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(_main())
    except Exception as exc:
        _safe_call(on_info, f"❌ Lỗi chạy workflow ghép ảnh: {exc}")

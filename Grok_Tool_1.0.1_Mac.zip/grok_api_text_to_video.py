import asyncio
import datetime
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


GROK_BASE = "https://grok.com"

ENDPOINT_CREATE_POST = f"{GROK_BASE}/rest/media/post/create"
ENDPOINT_CONVO_NEW = f"{GROK_BASE}/rest/app-chat/conversations/new"
ENDPOINT_UPSCALE = f"{GROK_BASE}/rest/media/video/upscale"

# ============================================================
# OAUTH + API.X.AI MODE — port chính xác từ tool ngon (VideoService.js + browser.js)
# Đây là cách tool ngon chạy: lấy OAuth token rồi gọi api.x.ai chính thức
# -> KHÔNG bị anti-bot, chạy được 3 luồng song song.
# ============================================================
OAUTH_CLIENT_ID = "b1a00492-073a-47ea-816f-4c329264a828"
OAUTH_REDIRECT = "http://127.0.0.1:56121/callback"
OAUTH_AUTHORIZE = "https://auth.x.ai/oauth2/authorize"
OAUTH_TOKEN = "https://auth.x.ai/oauth2/token"
API_X_AI_GEN = "https://api.x.ai/v1/videos/generations"
API_X_AI_POLL = "https://api.x.ai/v1/videos"


async def get_oauth_api_token(page, on_info=None) -> str | None:
    """Lấy OAuth access_token qua PKCE flow (giống browser.js tool ngon).
    Mở authUrl trong page, tự click consent, bắt code từ redirect 127.0.0.1:56121/callback,
    rồi đổi code lấy token. Trả về access_token hoặc None."""
    import hashlib, base64, secrets, urllib.parse

    def _emit(m):
        if on_info:
            try: on_info(m)
            except Exception: pass

    verifier = secrets.token_hex(32)
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()
    ).decode().rstrip("=")
    state = secrets.token_hex(16)
    scope = "openid profile email offline_access grok-cli:access api:access"
    auth_url = (
        f"{OAUTH_AUTHORIZE}?client_id={OAUTH_CLIENT_ID}"
        f"&redirect_uri={urllib.parse.quote(OAUTH_REDIRECT, safe='')}"
        f"&response_type=code"
        f"&scope={urllib.parse.quote(scope)}"
        f"&state={state}"
        f"&code_challenge={challenge}&code_challenge_method=S256"
    )

    loop = asyncio.get_running_loop()
    code_future: asyncio.Future = loop.create_future()

    def on_request(req):
        try:
            u = req.url or ""
            if u.startswith("http://127.0.0.1:56121/callback"):
                parsed = urllib.parse.urlparse(u)
                qs = urllib.parse.parse_qs(parsed.query)
                if "code" in qs and not code_future.done():
                    code_future.set_result(qs["code"][0])
        except Exception:
            pass

    # Bắt code qua NHIỀU kênh: request, response, framenavigated, và poll page.url
    def on_framenav(frame):
        try:
            u = frame.url or ""
            if u.startswith("http://127.0.0.1:56121/callback"):
                parsed = urllib.parse.urlparse(u)
                qs = urllib.parse.parse_qs(parsed.query)
                if "code" in qs and not code_future.done():
                    code_future.set_result(qs["code"][0])
        except Exception:
            pass

    print("DEBUG GET_TOKEN 1: registering page.on", flush=True)
    page.on("request", on_request)
    try:
        page.on("framenavigated", on_framenav)
    except Exception:
        pass

    # Chặn callback bằng route -> bắt code NGAY, trả về trang rỗng (tránh lỗi ERR_CONNECTION)
    async def _route_callback(route):
        try:
            u = route.request.url or ""
            if u.startswith("http://127.0.0.1:56121/callback"):
                parsed = urllib.parse.urlparse(u)
                qs = urllib.parse.parse_qs(parsed.query)
                if "code" in qs and not code_future.done():
                    code_future.set_result(qs["code"][0])
                try:
                    await route.fulfill(status=200, content_type="text/html",
                                        body="<html><body>OK, ban co the dong tab nay.</body></html>")
                    return
                except Exception:
                    pass
            await route.continue_()
        except Exception:
            try:
                await route.continue_()
            except Exception:
                pass

    print("DEBUG GET_TOKEN 2: registering page.route", flush=True)
    try:
        await page.route("http://127.0.0.1:56121/**", _route_callback)
    except Exception as e:
        print(f"DEBUG GET_TOKEN 2.5: page.route failed: {e}", flush=True)

    print("DEBUG GET_TOKEN 3: about to emit start message", flush=True)
    auth_code = None
    try:
        _emit("🔑 Lấy OAuth API token...")
        try:
            await page.goto(auth_url, wait_until="domcontentloaded", timeout=15000)
        except Exception:
            pass  # navigation tới 127.0.0.1 sẽ lỗi, bình thường

        # Thử tự click consent nhiều lần (trang có thể load chậm)
        async def _try_click_consent():
            try:
                clicked = await asyncio.wait_for(
                    page.evaluate("""() => {
                        const btns = Array.from(document.querySelectorAll('button, [role=button], a'));
                        const t = btns.find(b => {
                            const x = ((b.innerText||b.textContent)||'').toLowerCase().trim();
                            // KHÔNG bấm nút từ chối (refuser/deny/cancel/refuse/từ chối)
                            if (x.includes('refus')||x.includes('deny')||x.includes('cancel')
                                ||x.includes('từ chối')||x.includes('décliner')||x.includes('decline')) return false;
                            return x.includes('authorize')||x.includes('autoriser')||x.includes('allow')
                                ||x.includes('accept')||x.includes('accepter')||x.includes('approve')
                                ||x.includes('đồng ý')||x.includes('cho phép')||x.includes('xác nhận')
                                ||x.includes('continue')||x.includes('continuer')||x.includes('tiếp tục')
                                ||x.includes('confirm')||x.includes('confirmer');
                        });
                        if (t) { t.click(); return (t.innerText||t.textContent||'').trim().slice(0,30); }
                        return null;
                    }"""),
                    timeout=4.0
                )
                return clicked
            except Exception:
                return None

        # Poll: kiểm tra url + thử click consent, tối đa ~60s, cho bạn click tay nếu cần
        _emit("⏳ Đang chờ cấp quyền (nếu hiện nút Authorize, code sẽ tự bấm; nếu không, bạn bấm tay)...")
        manual_hint_shown = False
        for i in range(60):
            if code_future.done():
                break
            try:
                cur = page.url or ""
            except Exception:
                cur = ""
            # Bắt code từ url hiện tại nếu lọt
            if "127.0.0.1:56121/callback" in cur and "code=" in cur:
                try:
                    qs = urllib.parse.parse_qs(urllib.parse.urlparse(cur).query)
                    if "code" in qs and not code_future.done():
                        code_future.set_result(qs["code"][0])
                        break
                except Exception:
                    pass
            if "/oauth2/consent" in cur or "/oauth2/authorize" in cur or "auth.x.ai" in cur:
                clicked = await _try_click_consent()
                if clicked:
                    _emit(f"🔄 Đã bấm nút: {clicked}")
                elif not manual_hint_shown and i >= 3:
                    _emit("👉 Nếu Chrome hiện nút Authorize/Cho phép, hãy BẤM TAY giúp 1 lần.")
                    manual_hint_shown = True
            await asyncio.sleep(1.0)

        try:
            auth_code = await asyncio.wait_for(code_future, timeout=3)
        except asyncio.TimeoutError:
            auth_code = None
    finally:
        try:
            page.off("request", on_request)
        except Exception:
            pass
        try:
            page.off("framenavigated", on_framenav)
        except Exception:
            pass
        try:
            await page.unroute("http://127.0.0.1:56121/**", _route_callback)
        except Exception:
            pass

    if not auth_code:
        _emit("❌ Không lấy được OAuth code (cần login Grok trước)")
        return None

    # Đổi code lấy token bằng page.request (Playwright APIRequest - KHÔNG dính CORS).
    # KHÔNG dùng page.evaluate(fetch) vì lúc này page ở origin 127.0.0.1 -> CORS chặn auth.x.ai.
    _emit("🔁 Đổi code lấy token...")
    try:
        resp = await page.request.post(
            OAUTH_TOKEN,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            form={
                "grant_type": "authorization_code",
                "client_id": OAUTH_CLIENT_ID,
                "code": auth_code,
                "redirect_uri": OAUTH_REDIRECT,
                "code_verifier": verifier,
            },
            timeout=30000,
        )
        if not resp.ok:
            body = ""
            try:
                body = (await resp.text())[:150]
            except Exception:
                pass
            _emit(f"❌ Đổi token thất bại: HTTP {resp.status} {body}")
            return None
        data = await resp.json()
        access = data.get("access_token") if isinstance(data, dict) else None
        if access:
            _emit("🎉 Lấy OAuth API token thành công!")
            return access
        _emit(f"❌ Token response không có access_token: {str(data)[:120]}")
        return None
    except Exception as e:
        _emit(f"❌ Đổi token lỗi: {e}")
        return None


async def generate_video_via_api(page, prompt, api_token, cfg, on_progress=None, timeout_seconds=900):
    """Gọi api.x.ai/v1/videos/generations với Bearer token (giống VideoService.generateViaAPI).
    Trả về dict: { videoUrl, progress, error, videoId }"""
    d = cfg.as_dict()
    # api.x.ai dùng resolution '720p', aspect '16:9' kiểu khác web
    payload = {
        "model": "grok-imagine-video",
        "prompt": prompt,
        "duration": int(d.get("videoLength") or 6),
        "resolution": d.get("resolutionName") or "720p",
        "aspect_ratio": d.get("aspectRatio") or "16:9",
    }
    # Gọi bằng page.request (Playwright APIRequest - KHÔNG dính CORS, giống Node của tool ngon)
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api_token}"}
    try:
        gen = await page.request.post(API_X_AI_GEN, headers=headers, data=payload, timeout=60000)
        if not gen.ok:
            body = ""
            try: body = (await gen.text())[:200]
            except Exception: pass
            return {"error": f"API HTTP {gen.status}: {body}"}
        gen_data = await gen.json()
        request_id = gen_data.get("request_id") or gen_data.get("id")
        if not request_id:
            return {"error": "No request_id"}
    except Exception as e:
        return {"error": f"gen request lỗi: {e}"}

    # Poll mỗi 5s tới khi done
    import time as _t
    deadline = _t.monotonic() + int(timeout_seconds)
    last_prog = -1
    while _t.monotonic() < deadline:
        await asyncio.sleep(5)
        try:
            pr = await page.request.get(f"{API_X_AI_POLL}/{request_id}", headers=headers, timeout=30000)
            if not pr.ok:
                continue
            pd = await pr.json()
        except Exception:
            continue
        prog = pd.get("progress") if isinstance(pd, dict) else None
        if isinstance(prog, (int, float)) and prog != last_prog:
            last_prog = prog
            if on_progress:
                try: on_progress(int(prog))
                except Exception: pass
        status = pd.get("status") if isinstance(pd, dict) else None
        if status == "done":
            video = pd.get("video") or {}
            if not video.get("url"):
                return {"error": "Done but no video url", "progress": 100}
            if video.get("respect_moderation") is False:
                return {"error": "Content blocked by moderation", "progress": 100}
            return {"videoUrl": video.get("url"), "progress": 100, "videoId": request_id}
        if status in ("failed", "expired"):
            err = (pd.get("error") or {}).get("code") if isinstance(pd.get("error"), dict) else status
            return {"error": f"API failed: {err}", "progress": prog or 0}
    return {"error": "API Timeout"}


async def generate_i2v_via_api(page, image_path, prompt, api_token, cfg, on_progress=None, timeout_seconds=900):
    """Image-to-video qua api.x.ai (giống I2VService.generateViaAPI tool ngon).
    Chỉ khác generate_video_via_api ở field image: {url: data:base64}.
    Trả về dict: { videoUrl, progress, error, videoId }"""
    import base64 as _b64
    from pathlib import Path as _P
    p = _P(str(image_path))
    if not p.is_file():
        return {"error": f"Ảnh không tồn tại: {p}"}
    ext = p.suffix.lower().lstrip(".")
    mime = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
            "webp": "image/webp", "gif": "image/gif"}.get(ext, "image/jpeg")
    try:
        b64 = _b64.b64encode(p.read_bytes()).decode()
    except Exception as e:
        return {"error": f"Đọc ảnh lỗi: {e}"}
    data_url = f"data:{mime};base64,{b64}"

    d = cfg.as_dict()
    payload = {
        "model": "grok-imagine-video",
        "prompt": prompt or "",
        "duration": int(d.get("videoLength") or 6),
        "resolution": d.get("resolutionName") or "720p",
        "aspect_ratio": d.get("aspectRatio") or "16:9",
        "image": {"url": data_url},
    }
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api_token}"}
    try:
        gen = await page.request.post(API_X_AI_GEN, headers=headers, data=payload, timeout=90000)
        if not gen.ok:
            body = ""
            try: body = (await gen.text())[:200]
            except Exception: pass
            return {"error": f"API HTTP {gen.status}: {body}"}
        gen_data = await gen.json()
        request_id = gen_data.get("request_id") or gen_data.get("id")
        if not request_id:
            return {"error": "No request_id"}
    except Exception as e:
        return {"error": f"gen request lỗi: {e}"}

    import time as _t
    deadline = _t.monotonic() + int(timeout_seconds)
    last_prog = -1
    while _t.monotonic() < deadline:
        await asyncio.sleep(5)
        try:
            pr = await page.request.get(f"{API_X_AI_POLL}/{request_id}", headers=headers, timeout=30000)
            if not pr.ok:
                continue
            pd = await pr.json()
        except Exception:
            continue
        prog = pd.get("progress") if isinstance(pd, dict) else None
        if isinstance(prog, (int, float)) and prog != last_prog:
            last_prog = prog
            if on_progress:
                try: on_progress(int(prog))
                except Exception: pass
        status = pd.get("status") if isinstance(pd, dict) else None
        if status == "done":
            video = pd.get("video") or {}
            if not video.get("url"):
                return {"error": "Done but no video url", "progress": 100}
            if video.get("respect_moderation") is False:
                return {"error": "Content blocked by moderation", "progress": 100}
            return {"videoUrl": video.get("url"), "progress": 100, "videoId": request_id}
        if status in ("failed", "expired"):
            err = (pd.get("error") or {}).get("code") if isinstance(pd.get("error"), dict) else status
            return {"error": f"API failed: {err}", "progress": prog or 0}
    return {"error": "API Timeout"}




def _mask(value: str | None) -> str:
    if not value:
        return ""
    if len(value) <= 80:
        return value
    return f"{value[:60]}...({len(value)} chars)"


@dataclass(frozen=True)
class VideoGenConfig:
    aspect_ratio: str = "9:16"
    video_length_seconds: int = 6
    resolution_name: str = "480p"

    def as_dict(self) -> dict[str, Any]:
        resolution = str(self.resolution_name or "480p").strip().lower()
        if resolution not in {"480p", "720p"}:
            resolution = "480p"
        return {
            "aspectRatio": self.aspect_ratio,
            "videoLength": int(self.video_length_seconds),
            "resolutionName": resolution,
        }


def payload_create_post(prompt: str) -> dict[str, Any]:
    return {"mediaType": "MEDIA_POST_TYPE_VIDEO", "prompt": prompt}


def payload_conversation_new(prompt: str, parent_post_id: str, cfg: VideoGenConfig) -> dict[str, Any]:
    return {
        "temporary": True,
        "modelName": "grok-3",
        "message": prompt,
        "toolOverrides": {"videoGen": True},
        "enableSideBySide": True,
        "responseMetadata": {
            "experiments": [],
            "modelConfigOverride": {
                "modelMap": {"videoGenModelConfig": {**cfg.as_dict(), "parentPostId": parent_post_id}},
            },
        },
    }


def payload_upscale(video_id: str) -> dict[str, Any]:
    return {"videoId": video_id}


def _load_cache(cache_path: Path) -> dict:
    try:
        if cache_path.exists():
            return json.loads(cache_path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return {}


def _save_cache(cache_path: Path, cache: dict) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")


def get_cached_headers(cache_path: Path, profile_name: str) -> dict:
    cache = _load_cache(cache_path)
    profiles = cache.get("profiles") if isinstance(cache, dict) else None
    if not isinstance(profiles, dict):
        return {}
    entry = profiles.get(profile_name)
    if not isinstance(entry, dict):
        return {}
    headers = entry.get("custom_headers")
    if not isinstance(headers, dict):
        return {}
    headers = dict(headers)
    headers.pop("x-xai-request-id", None)
    return headers


def set_cached_headers(cache_path: Path, profile_name: str, headers: dict) -> None:
    headers = dict(headers or {})
    headers.pop("x-xai-request-id", None)

    cache = _load_cache(cache_path)
    if not isinstance(cache, dict):
        cache = {}
    profiles = cache.get("profiles")
    if not isinstance(profiles, dict):
        profiles = {}
        cache["profiles"] = profiles

    entry = profiles.get(profile_name)
    if not isinstance(entry, dict):
        entry = {}
    entry["custom_headers"] = headers
    entry["updated_at"] = datetime.datetime.now().isoformat(timespec="seconds")
    profiles[profile_name] = entry
    _save_cache(cache_path, cache)


def profile_cache_age_seconds(cache_path: Path, profile_name: str) -> float | None:
    cache = _load_cache(cache_path)
    profiles = cache.get("profiles") if isinstance(cache, dict) else None
    if not isinstance(profiles, dict):
        return None
    entry = profiles.get(profile_name)
    if not isinstance(entry, dict):
        return None
    updated_at = entry.get("updated_at")
    if not isinstance(updated_at, str) or not updated_at.strip():
        return None
    try:
        dt = datetime.datetime.fromisoformat(updated_at.strip())
        return (datetime.datetime.now() - dt).total_seconds()
    except Exception:
        return None


def is_valid_statsig(val: str | None) -> bool:
    if not val or not isinstance(val, str):
        return False
    v = val.strip()
    if not v or " " in v:
        return False
    # Check if literal base64 string contains error indicators
    if "TypeError" in v or "undefined" in v or "null" in v:
        return False
    # Decode and check decoded payload
    if v.startswith("eDA6"):
        try:
            import base64
            encoded = v[4:]
            missing_padding = len(encoded) % 4
            if missing_padding:
                encoded += '=' * (4 - missing_padding)
            decoded = base64.b64decode(encoded).decode("utf-8", errors="ignore")
            if "TypeError" in decoded or "undefined" in decoded or "Error" in decoded or "childNodes" in decoded:
                return False
        except Exception:
            pass
    return True


async def auto_discover_statsig_headers(
  page,
  cache_path: Path,
  profile_name: str,
  force: bool = False,
  persist: bool = False,
) -> dict:
    cached = get_cached_headers(cache_path, profile_name)
    if cached and not force:
        # Kiểm tra tính hợp lệ của cache
        cached_id = cached.get("x-statsig-id")
        if is_valid_statsig(cached_id):
            return cached

    loop = asyncio.get_running_loop()
    future: asyncio.Future = loop.create_future()

    def on_request(req):
        try:
            headers = req.headers or {}
            if not isinstance(headers, dict):
                return
            statsig = headers.get("x-statsig-id")
            if statsig and is_valid_statsig(statsig) and not future.done():
                future.set_result(headers)
        except Exception:
            return

    page.on("request", on_request)
    try:
        try:
            await page.goto(f"{GROK_BASE}/", wait_until="domcontentloaded", timeout=20000)
        except Exception:
            pass

        captured_headers = None
        try:
            captured_headers = await asyncio.wait_for(future, timeout=12)
        except asyncio.TimeoutError:
            captured_headers = None

        if isinstance(captured_headers, dict):
            custom = {}
            for k, v in captured_headers.items():
                k_lower = k.lower()
                if k_lower.startswith("x-statsig"):
                    custom[k] = v
            
            if is_valid_statsig(custom.get("x-statsig-id")):
                if persist:
                    set_cached_headers(cache_path, profile_name, custom)
                print(f"✅ Auto-discovered full headers with statsig-id: {_mask(custom.get('x-statsig-id'))}")
                if persist:
                    print(f"💾 Saved cache: {cache_path}")
                return custom

        statsig = await page.evaluate(
            """() => {
              try { return localStorage.getItem('x-statsig-id'); } catch (e) { return null; }
            }"""
        )
        if isinstance(statsig, str) and is_valid_statsig(statsig):
            custom = {"x-statsig-id": statsig.strip()}
            try:
                ua = await page.evaluate("() => navigator.userAgent")
                if ua:
                    custom["user-agent"] = ua
            except Exception:
                pass
            if persist:
                set_cached_headers(cache_path, profile_name, custom)
            print("✅ Derived x-statsig-id from localStorage")
            if persist:
                print(f"💾 Saved cache: {cache_path}")
            return custom

        print("⚠️ Không auto-discover được x-statsig-id hợp lệ, bỏ qua header này")
        return {}
    finally:
        try:
            page.off("request", on_request)
        except Exception:
            pass


async def api_run_single_job_in_page(
    page,
    prompt: str,
    statsig_headers: dict,
    cfg: VideoGenConfig,
    timeout_seconds: int,
    job_index: int,
) -> dict:
    """API call sequence run inside the authenticated browser page.

    - Create video post -> returns parentPostId
    - Start conversation -> stream progress
    - Upscale -> returns hdMediaUrl

    Expects workflow to expose globalThis.py_progress for progress updates.
    """

    payload = {
        "prompt": prompt,
        "statsigHeaders": statsig_headers or {},
        "cfg": cfg.as_dict(),
        "timeoutSeconds": int(timeout_seconds),
        "jobIndex": int(job_index),
    }

    result = await page.evaluate(
        """(async ({ prompt, statsigHeaders, cfg, timeoutSeconds, jobIndex }) => {
          function parseJsonObjectsFromBuffer(buffer) {
            const out = [];
            let depth = 0;
            let inString = false;
            let escape = false;
            let start = -1;
            for (let i = 0; i < buffer.length; i++) {
              const ch = buffer[i];
              if (start === -1) {
                if (ch === '{') { start = i; depth = 1; inString = false; escape = false; }
                continue;
              }
              if (inString) {
                if (escape) escape = false;
                else if (ch && ch.charCodeAt(0) === 92) escape = true;
                else if (ch === '"') inString = false;
                continue;
              }
              if (ch === '"') { inString = true; continue; }
              if (ch === '{') depth++;
              else if (ch === '}') {
                depth--;
                if (depth === 0) {
                  const slice = buffer.slice(start, i + 1);
                  try { out.push(JSON.parse(slice)); } catch (e) {}
                  start = -1;
                }
              }
            }
            let tail = '';
            if (start !== -1) tail = buffer.slice(start);
            return { objects: out, tail };
          }

          function pickLastProgressEvent(objects) {
            let last = null;
            for (const obj of objects) {
              const svr = obj && obj.result && obj.result.response && obj.result.response.streamingVideoGenerationResponse;
              if (svr && typeof svr.progress === 'number') {
                last = { progress: svr.progress, videoUrl: svr.videoUrl || null, parentPostId: svr.parentPostId || null };
              }
            }
            return last;
          }

          function reportProgress(pct, videoUrl) {
            try {
              if (typeof globalThis.py_progress === 'function') {
                globalThis.py_progress({ index: jobIndex, progress: pct, videoUrl: videoUrl || null });
              }
            } catch (e) {}
          }

          async function createPost() {
            const res = await fetch('https://grok.com/rest/media/post/create', {
              method: 'POST',
              headers: Object.assign({ 'content-type': 'application/json' }, statsigHeaders || {}),
              credentials: 'include',
              body: JSON.stringify({ mediaType: 'MEDIA_POST_TYPE_VIDEO', prompt }),
            });
            const ct = res.headers.get('content-type') || '';
            if (!ct.includes('json')) {
              return { status: 401, parentPostId: null, data: { error: 'Chưa đăng nhập Grok' } };
            }
            const data = await res.json().catch(() => null);
            const id = data && data.post && data.post.id;
            return { status: res.status, parentPostId: id || null, data };
          }

          async function startConversation(parentPostId) {
            const requestId = (crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()) + Math.random();
            const convoPayload = {
              temporary: true,
              modelName: 'grok-3',
              message: prompt,
              toolOverrides: { videoGen: true },
              enableSideBySide: true,
              responseMetadata: {
                experiments: [],
                modelConfigOverride: {
                  modelMap: { videoGenModelConfig: Object.assign({ parentPostId }, cfg) },
                },
              },
            };

            const controller = new AbortController();
            const t = setTimeout(() => controller.abort(), Math.max(1, timeoutSeconds) * 1000);

            let res;
            try {
              res = await fetch('https://grok.com/rest/app-chat/conversations/new', {
                method: 'POST',
                headers: Object.assign({ 'content-type': 'application/json', 'x-xai-request-id': requestId }, statsigHeaders || {}),
                credentials: 'include',
                body: JSON.stringify(convoPayload),
                signal: controller.signal,
              });
            } catch (e) {
              clearTimeout(t);
              return { status: 0, error: String(e), lastEvent: null, objectsHead: [] };
            }

            const status = res.status;
            const ct = res.headers.get('content-type') || '';
            if (!ct.includes('json') && !ct.includes('event-stream')) {
              clearTimeout(t);
              return { status: 401, error: 'Chưa đăng nhập Grok', lastEvent: null, objectsHead: [] };
            }
            if (status !== 200) {
              const errText = await res.text().catch(() => 'No body');
              clearTimeout(t);
              return { status, error: errText, lastEvent: null, objectsHead: [] };
            }
            const objectsHead = [];
            let lastEvent = null;

            try {
              if (!res.body) {
                const text = await res.text();
                const parsed = parseJsonObjectsFromBuffer(text);
                if (parsed.objects.length) objectsHead.push(...parsed.objects.slice(0, 2));
                lastEvent = pickLastProgressEvent(parsed.objects);
                if (lastEvent) reportProgress(lastEvent.progress, lastEvent.videoUrl);
                clearTimeout(t);
                return { status, lastEvent, objectsHead };
              }

              const reader = res.body.getReader();
              const decoder = new TextDecoder('utf-8');
              let buffer = '';

              while (true) {
                const { value, done } = await reader.read();
                if (done) break;
                if (!value) continue;

                buffer += decoder.decode(value, { stream: true });
                const parsed = parseJsonObjectsFromBuffer(buffer);
                buffer = parsed.tail;
                if (parsed.objects.length) {
                  if (objectsHead.length < 2) objectsHead.push(...parsed.objects.slice(0, 2 - objectsHead.length));
                  const ev = pickLastProgressEvent(parsed.objects);
                  if (ev) {
                    lastEvent = ev;
                    reportProgress(lastEvent.progress, lastEvent.videoUrl);
                    if (lastEvent.progress >= 100 && lastEvent.videoUrl) break;
                  }
                }
              }

              clearTimeout(t);
              return { status, lastEvent, objectsHead };
            } catch (e) {
              clearTimeout(t);
              return { status, error: String(e), lastEvent, objectsHead };
            }
          }

          async function upscaleVideo(videoId, maxRetries = 3) {
            for (let attempt = 1; attempt <= maxRetries; attempt++) {
              try {
                const res = await fetch('https://grok.com/rest/media/video/upscale', {
                  method: 'POST',
                  headers: Object.assign({ 'content-type': 'application/json' }, statsigHeaders || {}),
                  credentials: 'include',
                  body: JSON.stringify({ videoId }),
                });
                const data = await res.json().catch(() => null);
                const hdMediaUrl = (data && data.hdMediaUrl) ? data.hdMediaUrl : null;
                
                if (res.status === 200 && hdMediaUrl) {
                  return { status: res.status, hdMediaUrl, data, attempt };
                }
                
                if (attempt < maxRetries) {
                  await new Promise(r => setTimeout(r, 2000 * attempt));
                  continue;
                }
                return { status: res.status, hdMediaUrl, data, attempt };
              } catch (e) {
                if (attempt < maxRetries) {
                  await new Promise(r => setTimeout(r, 2000 * attempt));
                  continue;
                }
                return { status: 0, hdMediaUrl: null, data: null, error: String(e), attempt };
              }
            }
            return { status: 0, hdMediaUrl: null, data: null, attempt: maxRetries };
          }

          const created = await createPost();
          if (!created.parentPostId) {
            return { prompt, createStatus: created.status, parentPostId: null, convoStatus: 0, lastEvent: null, upscaleStatus: 0, hdMediaUrl: null, objectsHead: [created.data || null] };
          }

          const convo = await startConversation(created.parentPostId);
          let upscale = null;
          let finalMediaUrl = (convo && convo.lastEvent && convo.lastEvent.videoUrl) ? convo.lastEvent.videoUrl : null;
          const is720p = String((cfg && cfg.resolutionName) || '').toLowerCase() === '720p';
          let usedUpscale = false;
          if (convo && convo.status === 200 && convo.lastEvent && typeof convo.lastEvent.progress === 'number' && convo.lastEvent.progress >= 100) {
            if (!is720p) {
              upscale = await upscaleVideo(created.parentPostId, 3);
              if (upscale && upscale.hdMediaUrl) {
                finalMediaUrl = upscale.hdMediaUrl;
                usedUpscale = true;
              }
            }
          }

          return {
            prompt,
            createStatus: created.status,
            parentPostId: created.parentPostId,
            convoStatus: convo.status,
            lastEvent: convo.lastEvent || null,
            objectsHead: convo.objectsHead || [],
            upscaleStatus: upscale ? upscale.status : 0,
            usedUpscale,
            mediaUrl: finalMediaUrl || null,
            hdMediaUrl: usedUpscale ? (upscale ? (upscale.hdMediaUrl || null) : null) : null,
            upscaleData: upscale ? (upscale.data || null) : null,
          };
        })""",
        payload,
    )

    return result if isinstance(result, dict) else {"error": "unexpected", "raw": result}


async def api_run_jobs_in_page(
    page,
    prompts: list[str],
    statsig_headers: dict,
    cfg: VideoGenConfig,
    timeout_seconds: int,
    index_offset: int = 0,
) -> list[dict]:
    """Run multiple video generations concurrently inside ONE page.

    This avoids opening extra tabs/pages and still runs jobs in parallel using browser fetch.
    """

    payload = {
        "prompts": prompts,
        "statsigHeaders": statsig_headers or {},
        "cfg": cfg.as_dict(),
        "timeoutSeconds": int(timeout_seconds),
        "indexOffset": int(index_offset or 0),
    }

    js = """(async ({ prompts, statsigHeaders, cfg, timeoutSeconds, indexOffset }) => {
          function log(jobIndex, message, data) {
            try {
              if (typeof globalThis.py_log === 'function') {
                globalThis.py_log({
                  index: (indexOffset || 0) + jobIndex,
                  message: String(message || ''),
                  data: (data === undefined ? null : data),
                  ts: Date.now(),
                });
              }
            } catch (e) {}
          }

          function parseJsonObjectsFromBuffer(buffer) {
            const out = [];
            let depth = 0;
            let inString = false;
            let escape = false;
            let start = -1;
            for (let i = 0; i < buffer.length; i++) {
              const ch = buffer[i];
              if (start === -1) {
                if (ch === '{') { start = i; depth = 1; inString = false; escape = false; }
                continue;
              }
              if (inString) {
                if (escape) escape = false;
                else if (ch && ch.charCodeAt(0) === 92) escape = true;
                else if (ch === '"') inString = false;
                continue;
              }
              if (ch === '"') { inString = true; continue; }
              if (ch === '{') depth++;
              else if (ch === '}') {
                depth--;
                if (depth === 0) {
                  const slice = buffer.slice(start, i + 1);
                  try { out.push(JSON.parse(slice)); } catch (e) {}
                  start = -1;
                }
              }
            }
            let tail = '';
            if (start !== -1) tail = buffer.slice(start);
            return { objects: out, tail };
          }

          function pickLastProgressEvent(objects) {
            let last = null;
            for (const obj of objects) {
              const svr = obj && obj.result && obj.result.response && obj.result.response.streamingVideoGenerationResponse;
              if (svr && typeof svr.progress === 'number') {
                last = { progress: svr.progress, videoUrl: svr.videoUrl || null, parentPostId: svr.parentPostId || null };
              }
            }
            return last;
          }

          function reportProgress(jobIndex, pct, videoUrl) {
            try {
              if (typeof globalThis.py_progress === 'function') {
                globalThis.py_progress({ index: (indexOffset || 0) + jobIndex, progress: pct, videoUrl: videoUrl || null });
              }
            } catch (e) {}
          }

          async function createPost(prompt) {
            const res = await fetch('https://grok.com/rest/media/post/create', {
              method: 'POST',
              headers: Object.assign({ 'content-type': 'application/json' }, statsigHeaders || {}),
              credentials: 'include',
              body: JSON.stringify({ mediaType: 'MEDIA_POST_TYPE_VIDEO', prompt }),
            });
            const data = await res.json().catch(() => null);
            const id = data && data.post && data.post.id;
            return { status: res.status, parentPostId: id || null, data };
          }

          async function upscaleVideo(videoId, jobIndex, maxRetries = 3) {
            // Retry up to maxRetries times
            for (let attempt = 1; attempt <= maxRetries; attempt++) {
              try {
                const res = await fetch('https://grok.com/rest/media/video/upscale', {
                  method: 'POST',
                  headers: Object.assign({ 'content-type': 'application/json' }, statsigHeaders || {}),
                  credentials: 'include',
                  body: JSON.stringify({ videoId }),
                });
                const data = await res.json().catch(() => null);
                const hdMediaUrl = (data && data.hdMediaUrl) ? data.hdMediaUrl : null;
                
                // Success if status=200 and hdMediaUrl exists
                if (res.status === 200 && hdMediaUrl) {
                  return { status: res.status, hdMediaUrl, data, attempt };
                }
                
                // Failed but can retry
                if (attempt < maxRetries) {
                  log(jobIndex, 'upscale_retry', { attempt, status: res.status, hdMediaUrl: hdMediaUrl || null });
                  await new Promise(r => setTimeout(r, 2000 * attempt)); // Wait 2s, 4s before retry
                  continue;
                }
                
                // Last attempt failed
                return { status: res.status, hdMediaUrl, data, attempt };
              } catch (e) {
                if (attempt < maxRetries) {
                  log(jobIndex, 'upscale_retry_error', { attempt, error: String(e) });
                  await new Promise(r => setTimeout(r, 2000 * attempt));
                  continue;
                }
                return { status: 0, hdMediaUrl: null, data: null, error: String(e), attempt };
              }
            }
            return { status: 0, hdMediaUrl: null, data: null, attempt: maxRetries };
          }

          async function startConversation(prompt, parentPostId, jobIndex) {
            log(jobIndex, 'conversation_start', { parentPostId });
            const requestId = (crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()) + Math.random();
            const convoPayload = {
              temporary: true,
              modelName: 'grok-3',
              message: prompt,
              toolOverrides: { videoGen: true },
              enableSideBySide: true,
              responseMetadata: {
                experiments: [],
                modelConfigOverride: {
                  modelMap: { videoGenModelConfig: Object.assign({ parentPostId }, cfg) },
                },
              },
            };

            const controller = new AbortController();
            const t = setTimeout(() => controller.abort(), Math.max(1, timeoutSeconds) * 1000);

            let res;
            try {
              res = await fetch('https://grok.com/rest/app-chat/conversations/new', {
                method: 'POST',
                headers: Object.assign({ 'content-type': 'application/json', 'x-xai-request-id': requestId }, statsigHeaders || {}),
                credentials: 'include',
                body: JSON.stringify(convoPayload),
                signal: controller.signal,
              });
            } catch (e) {
              clearTimeout(t);
              log(jobIndex, 'conversation_fetch_error', { error: String(e) });
              return { status: 0, error: String(e), lastEvent: null, objectsHead: [] };
            }

            const status = res.status;
            log(jobIndex, 'conversation_status', { status });
            const objectsHead = [];
            let lastEvent = null;

            try {
              if (!res.body) {
                const text = await res.text();
                const parsed = parseJsonObjectsFromBuffer(text);
                if (parsed.objects.length) objectsHead.push(...parsed.objects.slice(0, 2));
                lastEvent = pickLastProgressEvent(parsed.objects);
                if (lastEvent) reportProgress(jobIndex, lastEvent.progress, lastEvent.videoUrl);
                clearTimeout(t);
                return { status, lastEvent, objectsHead };
              }

              const reader = res.body.getReader();
              const decoder = new TextDecoder('utf-8');
              let buffer = '';

              while (true) {
                const { value, done } = await reader.read();
                if (done) break;
                if (!value) continue;

                buffer += decoder.decode(value, { stream: true });
                const parsed = parseJsonObjectsFromBuffer(buffer);
                buffer = parsed.tail;
                if (parsed.objects.length) {
                  if (objectsHead.length < 2) objectsHead.push(...parsed.objects.slice(0, 2 - objectsHead.length));
                  const ev = pickLastProgressEvent(parsed.objects);
                  if (ev) {
                    lastEvent = ev;
                    reportProgress(jobIndex, lastEvent.progress, lastEvent.videoUrl);
                    if (lastEvent.progress >= 100 && lastEvent.videoUrl) break;
                  }
                }
              }

              clearTimeout(t);
              return { status, lastEvent, objectsHead };
            } catch (e) {
              clearTimeout(t);
              log(jobIndex, 'conversation_parse_error', { error: String(e) });
              return { status, error: String(e), lastEvent, objectsHead };
            }
          }

          const createResults = await Promise.all((prompts || []).map((p, i) => {
            log(i, 'create_post_start');
            return createPost(p);
          }));
          const results = await Promise.all(createResults.map(async (cr, i) => {
            const prompt = prompts[i];
            const parentPostId = cr.parentPostId;
            log(i, 'create_post_done', { status: cr.status, parentPostId: parentPostId || null });
            if (!parentPostId) {
              return { prompt, createStatus: cr.status, parentPostId: null, convoStatus: 0, lastEvent: null, upscaleStatus: 0, hdMediaUrl: null, objectsHead: [cr.data || null] };
            }

            const convo = await startConversation(prompt, parentPostId, i);
            if (convo && convo.lastEvent && typeof convo.lastEvent.progress === 'number' && convo.lastEvent.progress >= 100) {
              log(i, 'video_generated', { parentPostId, videoUrl: convo.lastEvent.videoUrl || null });
            }
            let upscale = null;
            let finalMediaUrl = (convo && convo.lastEvent && convo.lastEvent.videoUrl) ? convo.lastEvent.videoUrl : null;
            const is720p = String((cfg && cfg.resolutionName) || '').toLowerCase() === '720p';
            let usedUpscale = false;

            if (convo && convo.status === 200 && convo.lastEvent && typeof convo.lastEvent.progress === 'number' && convo.lastEvent.progress >= 100) {
              if (is720p) {
                log(i, 'upscale_skip', { reason: 'already_720p', mediaUrl: finalMediaUrl || null });
              } else {
                log(i, 'upscale_start', { videoId: parentPostId });
                upscale = await upscaleVideo(parentPostId, i, 3);
                log(i, 'upscale_done', { status: upscale.status, hdMediaUrl: upscale.hdMediaUrl || null, attempt: upscale.attempt || 1 });
                if (upscale && upscale.hdMediaUrl) {
                  finalMediaUrl = upscale.hdMediaUrl;
                  usedUpscale = true;
                }
              }
            }

            return {
              prompt,
              createStatus: cr.status,
              parentPostId,
              convoStatus: convo.status,
              lastEvent: convo.lastEvent || null,
              objectsHead: convo.objectsHead || [],
              upscaleStatus: upscale ? upscale.status : 0,
              usedUpscale,
              mediaUrl: finalMediaUrl || null,
              hdMediaUrl: usedUpscale ? (upscale ? (upscale.hdMediaUrl || null) : null) : null,
              upscaleData: upscale ? (upscale.data || null) : null,
            };
          }));

          return results;
        })"""

    # Playwright can throw: "Execution context was destroyed" if the page navigates/reloads.
    # This happens occasionally if Grok refreshes, Cloudflare kicks in, or the user clicks around.
    last_exc: Exception | None = None
    for attempt in range(1, 4):
        try:
            result = await page.evaluate(js, payload)
            return result if isinstance(result, list) else []
        except Exception as exc:
            last_exc = exc
            msg = str(exc)
            is_ctx_destroyed = (
                "Execution context was destroyed" in msg
                or "Most likely the page has been closed" in msg
                or "Navigation" in msg
            )
            if not is_ctx_destroyed or attempt >= 3:
                raise

            # wait for navigation to settle, then try to get back to the imagine page
            try:
                await page.wait_for_load_state("domcontentloaded", timeout=30000)
            except Exception:
                pass
            try:
                await page.goto("https://grok.com/imagine", wait_until="domcontentloaded", timeout=30000)
            except Exception:
                pass
            try:
                import asyncio

                await asyncio.sleep(0.6 * attempt)
            except Exception:
                pass

    # unreachable, but keep mypy happy
    if last_exc is not None:
        raise last_exc
    return []


async def download_mp4(context, url: str, out_path: Path, timeout_ms: int, page=None) -> bool:
    out_path.parent.mkdir(parents=True, exist_ok=True)

    def looks_like_mp4(buf: bytes) -> bool:
        return isinstance(buf, (bytes, bytearray)) and len(buf) > 12 and buf[4:8] == b"ftyp"

    target = (url or "").strip()
    if not target:
        print("⚠️ Download failed: empty URL")
        return False

    headers = {
        "accept": "video/mp4,application/octet-stream,*/*",
        "referer": f"{GROK_BASE}/imagine",
    }

    max_attempts = 3
    last_body: bytes | None = None
    last_status: int | None = None
    last_ctype: str | None = None
    last_exc: Exception | None = None

    # FIX DOWNLOAD: tải trong browser bằng cookie thật (context.request không gửi cookie -> 403)
    if page is not None:
      try:
        arr = await page.evaluate(
          """async (u) => {
            try {
              const r = await fetch(u, { credentials: 'include' });
              if (!r.ok) return { ok:false, status: r.status };
              const ab = await (await r.blob()).arrayBuffer();
              return { ok:true, status: r.status, data: Array.from(new Uint8Array(ab)) };
            } catch (e) { return { ok:false, error: String(e) }; }
          }""",
          target,
        )
        if isinstance(arr, dict) and arr.get("ok") and arr.get("data"):
          body = bytes(bytearray(arr["data"]))
          if len(body) > 50000:
            out_path.write_bytes(body)
            print(f"⬇️ Saved (browser fetch): {out_path} ({len(body)} bytes)")
            return True
      except Exception as _be:
        print(f"⚠️ Browser fetch lỗi: {_be}")

    for attempt in range(1, max_attempts + 1):
      print(f"⬇️ Downloading via context.request ({attempt}/{max_attempts}): {target}")
      try:
        resp = await context.request.get(target, timeout=timeout_ms, headers=headers)
        body = await resp.body()
        ctype = (resp.headers.get("content-type") or "").lower()
        last_body = body
        last_status = getattr(resp, "status", None)
        last_ctype = ctype

        if resp.status == 200 and ("video" in ctype or "octet-stream" in ctype) and looks_like_mp4(body):
          out_path.write_bytes(body)
          print(f"⬇️ Saved: {out_path}")
          return True

        sample = body[:200].decode("utf-8", errors="replace") if body else ""
        print(
          f"⚠️ Download failed: status={resp.status} ctype={ctype} url={target} sample={sample!r}"
        )
      except Exception as exc:
        last_exc = exc
        print(f"⚠️ Download exception: {exc}")

      if attempt < max_attempts:
        # small backoff for flaky CDN / transient network errors
        try:
          import asyncio

          await asyncio.sleep(0.8 * attempt)
        except Exception:
          pass

    # Final failure: no file logging (per UI requirement)
    print(f"⚠️ Download failed after {max_attempts} attempts (status={last_status} ctype={last_ctype} exc={last_exc})")
    return False

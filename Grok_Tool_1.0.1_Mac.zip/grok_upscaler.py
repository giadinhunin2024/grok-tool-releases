import os
import sys
import shutil
import subprocess
import asyncio
import threading
import urllib.request
import zipfile
import io
import tempfile
from pathlib import Path
from PyQt6.QtCore import QThread, pyqtSignal, Qt
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QProgressBar, QPushButton, QMessageBox

if getattr(sys, 'frozen', False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent

# Cấu hình đường dẫn
REALESRGAN_DIR = APP_DIR / "realesrgan"
if sys.platform == "win32":
    REALESRGAN_EXE = REALESRGAN_DIR / "realesrgan-ncnn-vulkan.exe"
    ZIP_URL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip"
elif sys.platform == "darwin":
    REALESRGAN_EXE = REALESRGAN_DIR / "realesrgan-ncnn-vulkan"
    ZIP_URL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-macos.zip"
else:
    REALESRGAN_EXE = REALESRGAN_DIR / "realesrgan-ncnn-vulkan"
    ZIP_URL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-ubuntu.zip"

class RealEsrganDownloaderThread(QThread):
    progress = pyqtSignal(int)
    finished_success = pyqtSignal(str)
    finished_error = pyqtSignal(str)

    def __init__(self, dest_dir: Path, parent=None):
        super().__init__(parent)
        self.dest_dir = dest_dir
        self.is_cancelled = False

    def run(self):
        try:
            req = urllib.request.Request(ZIP_URL, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                total_size = int(response.info().get('Content-Length', 0))
                downloaded = 0
                chunk_size = 1024 * 64
                data_buffer = io.BytesIO()
                
                while not self.is_cancelled:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    data_buffer.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = int((downloaded / total_size) * 100)
                        self.progress.emit(percent)
                        
                if self.is_cancelled:
                    return
                    
                self.progress.emit(99)
                data_buffer.seek(0)
                
                with zipfile.ZipFile(data_buffer) as z:
                    # Tạo thư mục đích nếu chưa có
                    self.dest_dir.mkdir(parents=True, exist_ok=True)
                    
                    # Giải nén chỉ các file cần thiết
                    extracted_count = 0
                    exe_name = "realesrgan-ncnn-vulkan.exe" if sys.platform == "win32" else "realesrgan-ncnn-vulkan"
                    for name in z.namelist():
                        if exe_name in name and not name.endswith("/"):
                            target_path = self.dest_dir / exe_name
                            with z.open(name) as source, open(target_path, "wb") as target:
                                target.write(source.read())
                            if sys.platform != "win32":
                                try:
                                    target_path.chmod(0o755)
                                except Exception:
                                    pass
                            extracted_count += 1
                        elif "models/" in name and not name.endswith("/"):
                            # Lấy tên file model tương đối
                            parts = name.split("models/")
                            if len(parts) > 1 and parts[1]:
                                model_file_name = parts[1]
                                model_target_dir = self.dest_dir / "models"
                                model_target_dir.mkdir(parents=True, exist_ok=True)
                                target_path = model_target_dir / model_file_name
                                with z.open(name) as source, open(target_path, "wb") as target:
                                    target.write(source.read())
                                extracted_count += 1
                                
                    if extracted_count > 0:
                        self.progress.emit(100)
                        self.finished_success.emit(str(self.dest_dir))
                    else:
                        self.finished_error.emit("Không tìm thấy các tệp tin của AI UPSCALE Ngocluudan 0982921046 trong file nén tải về.")
        except Exception as e:
            self.finished_error.emit(str(e))

class RealEsrganDownloaderDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Tải Bộ Nâng Cấp Video AI")
        self.setFixedSize(380, 130)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)
        
        layout = QVBoxLayout(self)
        self.lbl = QLabel("Đang kết nối tải thư viện nâng cấp video AI UPSCALE Ngocluudan 0982921046 (khoảng 28MB)...")
        self.lbl.setWordWrap(True)
        layout.addWidget(self.lbl)
        
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        layout.addWidget(self.bar)
        
        self.btn_cancel = QPushButton("Hủy")
        self.btn_cancel.clicked.connect(self.close)
        layout.addWidget(self.btn_cancel)
        
        self.thread = RealEsrganDownloaderThread(REALESRGAN_DIR, self)
        self.thread.progress.connect(self.bar.setValue)
        self.thread.finished_success.connect(self._on_success)
        self.thread.finished_error.connect(self._on_error)
        
        self.success = False
        self.error_msg = ""
        
        self.thread.start()

    def _on_success(self, path):
        self.success = True
        self.close()

    def _on_error(self, err):
        self.error_msg = err
        self.close()

    def closeEvent(self, event):
        if self.thread.isRunning():
            self.thread.is_cancelled = True
            self.thread.wait()
        super().closeEvent(event)

def ensure_realesrgan_installed(parent_widget=None) -> bool:
    """Kiểm tra và tự động hiển thị hộp thoại tải xuống Real-ESRGAN nếu chưa có."""
    if REALESRGAN_EXE.exists():
        return True
        
    dialog = RealEsrganDownloaderDialog(parent_widget)
    dialog.exec()
    
    if dialog.success:
        return True
    else:
        if dialog.error_msg:
            QMessageBox.critical(
                parent_widget,
                "Lỗi tải bộ nâng cấp AI",
                f"Không thể tải xuống thư viện nâng cấp AI:\n{dialog.error_msg}"
            )
        return False

def get_ffmpeg_path() -> str:
    """Trả về đường dẫn tới ffmpeg."""
    ffmpeg_name = "ffmpeg.exe" if sys.platform == "win32" else "ffmpeg"
    local_ffmpeg = APP_DIR / ffmpeg_name
    if local_ffmpeg.exists():
        return str(local_ffmpeg)
    import shutil
    sys_ffmpeg = shutil.which("ffmpeg")
    if sys_ffmpeg:
        return sys_ffmpeg
    return "ffmpeg"

def upscale_video_ai(
    input_video_path: Path,
    output_video_path: Path,
    upscale_mode: str,
    on_info=None
) -> bool:
    """Nâng cấp video bằng Real-ESRGAN AI lên 1080p, 2K hoặc 4K với progress tracking."""
    if not input_video_path.exists():
        if on_info: on_info(f"❌ Lỗi: Video đầu vào không tồn tại: {input_video_path}")
        return False

    if "1080p" not in upscale_mode and "2K" not in upscale_mode and "4K" not in upscale_mode:
        # Không cần nâng cấp
        shutil.copy2(input_video_path, output_video_path)
        return True

    if not REALESRGAN_EXE.exists():
        if on_info: on_info("❌ Lỗi: Chưa cài đặt thư viện AI UPSCALE Ngocluudan 0982921046!")
        return False

    ffmpeg_bin = get_ffmpeg_path()

    # 1. Lấy FPS và kích thước của video gốc bằng cv2
    fps = 30.0
    width = 1280
    height = 720
    try:
        import cv2
        cap = cv2.VideoCapture(str(input_video_path))
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cap.release()
        if not fps or fps < 1:
            fps = 30.0
    except Exception:
        pass
    is_vertical = height > width

    if on_info: on_info(f"✨ Bắt đầu nâng cấp video AI ({upscale_mode}) | {width}x{height} @ {fps:.0f}fps")

    # Tạo thư mục tạm
    temp_dir = Path(tempfile.gettempdir()) / f"grok_upscale_{os.urandom(4).hex()}"
    temp_dir.mkdir(parents=True, exist_ok=True)

    frames_in_dir = temp_dir / "frames_in"
    frames_out_dir = temp_dir / "frames_out"
    frames_in_dir.mkdir(exist_ok=True)
    frames_out_dir.mkdir(exist_ok=True)

    # Ẩn cửa sổ console trên Windows
    sub_kwargs_base = {}
    if sys.platform == "win32":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        sub_kwargs_base["startupinfo"] = startupinfo

    try:
        # 2. Tách khung hình bằng FFmpeg
        if on_info: on_info("🎞 [1/3] Đang tách khung hình video...")
        cmd_extract = [
            ffmpeg_bin, "-y", "-i", str(input_video_path),
            "-qscale:v", "2",
            str(frames_in_dir / "frame_%06d.png")
        ]
        proc = subprocess.run(
            cmd_extract,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            **sub_kwargs_base
        )
        if proc.returncode != 0:
            raise RuntimeError(f"FFmpeg tách khung hình thất bại: {proc.stderr.decode('utf-8', errors='ignore')[:300]}")

        extracted_frames = sorted(frames_in_dir.glob("*.png"))
        total_frames = len(extracted_frames)
        if not total_frames:
            raise RuntimeError("Không tách được khung hình nào từ video.")

        if on_info: on_info(f"📸 Đã tách {total_frames} frame (≈{total_frames/fps:.0f}s video)")

        # 3. Real-ESRGAN nâng cấp bằng AI (với progress tracking)
        # Chọn model: anime-optimized nhanh hơn general model, phù hợp ảnh AI/thời trang
        if "4K" in upscale_mode:
            esrgan_model = "realesrgan-x4plus-anime"  # 4x, nhanh hơn x4plus cho ảnh AI
            esrgan_scale = "4"
        else:  # 1080p hoặc 2K
            esrgan_model = "realesr-animevideov3-x2"  # Tối ưu cho video, rất nhanh
            esrgan_scale = "2"

        if on_info: on_info(
            f"🤖 [2/3] AI upscale {total_frames} frame | model={esrgan_model} | scale={esrgan_scale}x"
        )

        cmd_upscale = [
            str(REALESRGAN_EXE),
            "-i", str(frames_in_dir),
            "-o", str(frames_out_dir),
            "-n", esrgan_model,
            "-s", esrgan_scale,
            "-f", "png",
            "-g", "0",      # GPU device 0 (tự fallback CPU nếu không có GPU/Vulkan)
            "-j", "2:4:2",  # load:process:save threads — tăng throughput đáng kể
        ]

        # Dùng Popen để đọc progress real-time từ stderr
        proc_upscale = subprocess.Popen(
            cmd_upscale,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            **sub_kwargs_base
        )

        last_pct_reported = -1
        stderr_lines = []
        try:
            for raw_line in proc_upscale.stderr:
                line = raw_line.decode("utf-8", errors="ignore").strip()
                if line:
                    stderr_lines.append(line)
                # ESRGAN output: "X/Y" (số frame đã xong / tổng)
                parts = line.split("/")
                if len(parts) == 2:
                    try:
                        done_frames = int(parts[0].strip())
                        pct = int(done_frames / total_frames * 100)
                        if pct >= last_pct_reported + 10:
                            last_pct_reported = pct
                            if on_info:
                                on_info(f"  🖼 AI upscale: {done_frames}/{total_frames} frame ({pct}%)")
                    except ValueError:
                        pass
        except Exception:
            pass

        proc_upscale.wait()
        if proc_upscale.returncode != 0:
            err_txt = "\n".join(stderr_lines[-5:]) if stderr_lines else "unknown error"
            raise RuntimeError(f"ESRGAN thất bại (code {proc_upscale.returncode}): {err_txt[:300]}")

        done_out = list(frames_out_dir.glob("*.png"))
        if on_info: on_info(f"  ✅ AI upscale xong: {len(done_out)}/{total_frames} frame")

        # 4. Ghép lại thành video + âm thanh
        if on_info: on_info("🎬 [3/3] Đang mã hóa video đầu ra...")

        # Resolution target
        if "1080p" in upscale_mode:
            out_w, out_h = (1080, 1920) if is_vertical else (1920, 1080)
        elif "2K" in upscale_mode:
            out_w, out_h = (1440, 2560) if is_vertical else (2560, 1440)
        elif "4K" in upscale_mode:
            out_w, out_h = (2160, 3840) if is_vertical else (3840, 2160)
        else:
            out_w, out_h = (width, height)

        # Scale + pad để đảm bảo width/height chia hết cho 2 (H.264 bắt buộc)
        scale_filter = (
            f"scale={out_w}:{out_h}:flags=lanczos,"
            f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2"
        )

        cmd_merge = [
            ffmpeg_bin, "-y",
            "-framerate", str(fps),
            "-i", str(frames_out_dir / "frame_%06d.png"),
            "-i", str(input_video_path),
            "-map", "0:v:0",
            "-map", "1:a:0?",
            "-vf", scale_filter,
            "-c:v", "libx264",
            "-crf", "18",       # Chất lượng cao (0=lossless, 51=worst), 18 ≈ visually lossless
            "-preset", "fast",  # Nhanh hơn "slow" mà chất lượng gần như tương đương
            "-pix_fmt", "yuv420p",
            "-movflags", "+faststart",  # Cho phép stream/xem ngay khi đang tải
            "-c:a", "copy",
            str(output_video_path)
        ]

        proc_merge = subprocess.run(
            cmd_merge,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            **sub_kwargs_base
        )
        if proc_merge.returncode != 0:
            raise RuntimeError(f"FFmpeg đóng gói thất bại: {proc_merge.stderr.decode('utf-8', errors='ignore')[:300]}")

        size_mb = output_video_path.stat().st_size / 1024 / 1024 if output_video_path.exists() else 0
        if on_info: on_info(f"✅ Nâng cấp xong: {output_video_path.name} ({size_mb:.1f} MB)")
        return True

    except Exception as e:
        if on_info: on_info(f"❌ Lỗi nâng cấp video: {e}")
        return False
    finally:
        # Dọn dẹp thư mục tạm
        shutil.rmtree(temp_dir, ignore_errors=True)

def upscale_image_ai(input_path: Path, output_path: Path, upscale_mode: str, on_info=None) -> bool:
    """Nâng cấp ảnh bằng AI (UPSCALE Ngocluudan 0982921046) lên 2K hoặc 4K."""
    if not REALESRGAN_EXE.exists():
        if on_info: on_info("❌ Lỗi: Chưa cài đặt thư viện AI UPSCALE Ngocluudan 0982921046!")
        return False
        
    scale_factor = "2"
    if "4K" in upscale_mode:
        scale_factor = "4"
        
    cmd = [
        str(REALESRGAN_EXE),
        "-i", str(input_path),
        "-o", str(output_path),
        "-n", "realesr-animevideov3-x2" if scale_factor == "2" else "realesrgan-x4plus",
        "-s", scale_factor,
        "-f", "jpg" if input_path.suffix.lower() in {".jpg", ".jpeg"} else "png"
    ]
    
    sub_kwargs = {"stdout": subprocess.PIPE, "stderr": subprocess.PIPE}
    if sys.platform == "win32":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        sub_kwargs["startupinfo"] = startupinfo
    
    try:
        proc = subprocess.run(cmd, **sub_kwargs)
        if proc.returncode != 0:
            if on_info: on_info(f"AI UPSCALE thất bại: {proc.stderr.decode('utf-8', errors='ignore')}")
            return False
        return True
    except Exception as e:
        if on_info: on_info(f"AI UPSCALE lỗi: {e}")
        return False

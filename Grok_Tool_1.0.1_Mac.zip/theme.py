"""Theme tím/xanh gradient hiện đại cho GROK Tool."""

# Bảng màu
COLORS = {
    "bg": "#0f0b1e",            # nền tổng (tím rất tối)
    "bg2": "#16112b",          # nền panel
    "card": "#1d1838",         # nền thẻ
    "card_hover": "#241d45",
    "border": "#332a5c",
    "text": "#e8e6f5",
    "text_dim": "#9b94c4",
    "accent": "#8b5cf6",       # tím
    "accent2": "#6366f1",      # indigo
    "cyan": "#22d3ee",         # xanh cyan nhấn
    "green": "#34d399",
    "red": "#f87171",
    "yellow": "#fbbf24",
}

STYLESHEET = f"""
* {{
    font-family: 'Segoe UI', 'Inter', sans-serif;
    color: {COLORS['text']};
    outline: none;
}}

QMainWindow, QWidget#root {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 {COLORS['bg']}, stop:0.5 {COLORS['bg2']}, stop:1 {COLORS['bg']});
}}

/* ===== TAB BAR ===== */
QTabWidget::pane {{
    border: none;
    background: transparent;
    top: -1px;
}}
QTabBar {{
    qproperty-drawBase: 0;
}}
QTabBar::tab {{
    background: {COLORS['card']};
    color: {COLORS['text_dim']};
    padding: 11px 26px;
    margin-right: 6px;
    border: 1px solid {COLORS['border']};
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    font-size: 13px;
    font-weight: 600;
}}
QTabBar::tab:selected {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {COLORS['accent']}, stop:1 {COLORS['accent2']});
    color: white;
    border: 1px solid {COLORS['accent']};
}}
QTabBar::tab:hover:!selected {{
    background: {COLORS['card_hover']};
    color: {COLORS['text']};
}}

/* ===== LABELS ===== */
QLabel {{
    color: {COLORS['text']};
    background: transparent;
    font-size: 13px;
}}
QLabel#sectionTitle {{
    font-size: 15px;
    font-weight: 700;
    color: {COLORS['cyan']};
    padding: 2px 0;
}}
QLabel#hint {{
    color: {COLORS['text_dim']};
    font-size: 12px;
}}

/* ===== INPUTS ===== */
QPlainTextEdit, QLineEdit {{
    background: {COLORS['card']};
    border: 1.5px solid {COLORS['border']};
    border-radius: 10px;
    padding: 9px 12px;
    font-size: 13px;
    selection-background-color: {COLORS['accent']};
}}
QPlainTextEdit:focus, QLineEdit:focus {{
    border: 1.5px solid {COLORS['accent']};
    background: {COLORS['card_hover']};
}}

/* ===== COMBO / SPIN ===== */
QComboBox, QSpinBox {{
    background: {COLORS['card']};
    border: 1.5px solid {COLORS['border']};
    border-radius: 9px;
    padding: 7px 12px;
    min-height: 20px;
    font-size: 13px;
}}
QComboBox:hover, QSpinBox:hover {{
    border: 1.5px solid {COLORS['accent']};
}}
QComboBox::drop-down {{
    border: none;
    width: 26px;
}}
QComboBox::down-arrow {{
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid {COLORS['cyan']};
    margin-right: 8px;
}}
QComboBox QAbstractItemView {{
    background: {COLORS['card']};
    border: 1.5px solid {COLORS['accent']};
    border-radius: 8px;
    selection-background-color: {COLORS['accent']};
    padding: 4px;
}}
QSpinBox::up-button, QSpinBox::down-button {{
    background: {COLORS['accent2']};
    border-radius: 4px;
    width: 18px;
}}

/* ===== BUTTONS ===== */
QPushButton {{
    background: {COLORS['card']};
    border: 1.5px solid {COLORS['border']};
    border-radius: 10px;
    padding: 9px 18px;
    font-size: 13px;
    font-weight: 600;
    color: {COLORS['text']};
}}
QPushButton:hover {{
    background: {COLORS['card_hover']};
    border: 1.5px solid {COLORS['accent']};
}}
QPushButton:pressed {{
    background: {COLORS['bg2']};
}}
QPushButton:disabled {{
    color: {COLORS['text_dim']};
    background: {COLORS['bg2']};
    border: 1.5px solid {COLORS['border']};
}}

QPushButton#primary {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {COLORS['accent']}, stop:1 {COLORS['accent2']});
    border: none;
    color: white;
    font-weight: 700;
    padding: 11px 22px;
}}
QPushButton#primary:hover {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {COLORS['accent2']}, stop:1 {COLORS['cyan']});
}}
QPushButton#primary:disabled {{
    background: {COLORS['bg2']};
    color: {COLORS['text_dim']};
}}

QPushButton#danger {{
    background: transparent;
    border: 1.5px solid {COLORS['red']};
    color: {COLORS['red']};
}}
QPushButton#danger:hover {{
    background: {COLORS['red']};
    color: white;
}}

/* ===== TABLE ===== */
QTableWidget {{
    background: {COLORS['card']};
    border: 1.5px solid {COLORS['border']};
    border-radius: 12px;
    gridline-color: {COLORS['border']};
    font-size: 12px;
}}
QTableWidget::item {{
    padding: 6px;
    border: none;
}}
QTableWidget::item:selected {{
    background: {COLORS['accent']};
    color: white;
}}
QHeaderView::section {{
    background: {COLORS['bg2']};
    color: {COLORS['cyan']};
    padding: 9px;
    border: none;
    border-bottom: 2px solid {COLORS['accent']};
    font-weight: 700;
    font-size: 12px;
}}
QTableWidget QTableCornerButton::section {{
    background: {COLORS['bg2']};
    border: none;
}}

/* ===== LOG ===== */
QPlainTextEdit#log {{
    background: #0a0716;
    border: 1.5px solid {COLORS['border']};
    border-radius: 10px;
    color: {COLORS['green']};
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 12px;
}}

/* ===== DROP ZONE ===== */
QLabel#dropzone {{
    background: {COLORS['card']};
    border: 2px dashed {COLORS['border']};
    border-radius: 14px;
    color: {COLORS['text_dim']};
    font-size: 13px;
    padding: 18px;
}}
QLabel#dropzone[active="true"] {{
    border: 2px dashed {COLORS['cyan']};
    background: {COLORS['card_hover']};
    color: {COLORS['cyan']};
}}
QLabel#dropzone[filled="true"] {{
    border: 2px solid {COLORS['green']};
    color: {COLORS['green']};
}}

/* ===== SCROLLBAR ===== */
QScrollBar:vertical {{
    background: transparent;
    width: 10px;
    margin: 2px;
}}
QScrollBar::handle:vertical {{
    background: {COLORS['border']};
    border-radius: 5px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: {COLORS['accent']};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}

/* ===== HEADER BANNER ===== */
QLabel#appTitle {{
    font-size: 20px;
    font-weight: 800;
    color: white;
}}
QLabel#appSubtitle {{
    font-size: 12px;
    color: {COLORS['text_dim']};
}}
QWidget#headerBar {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(139,92,246,0.18), stop:1 rgba(34,211,238,0.10));
    border-radius: 14px;
    border: 1px solid {COLORS['border']};
}}

QWidget#card {{
    background: {COLORS['card']};
    border: 1.5px solid {COLORS['border']};
    border-radius: 14px;
}}

QSplitter::handle:horizontal {{
    background-color: {COLORS['border']};
    width: 2px;
}}
QSplitter::handle:horizontal:hover {{
    background-color: {COLORS['accent']};
}}

/* ===== QMessageBox ===== */
QMessageBox {{
    background-color: {COLORS['bg2']};
    border: 1.5px solid {COLORS['border']};
}}
QMessageBox QLabel {{
    color: {COLORS['text']};
    font-size: 13px;
}}
QMessageBox QPushButton {{
    min-width: 80px;
    background: {COLORS['card']};
    border: 1.5px solid {COLORS['border']};
    color: {COLORS['text']};
    border-radius: 6px;
    padding: 5px 12px;
}}
QMessageBox QPushButton:hover {{
    background: {COLORS['card_hover']};
    border: 1.5px solid {COLORS['accent']};
}}
"""

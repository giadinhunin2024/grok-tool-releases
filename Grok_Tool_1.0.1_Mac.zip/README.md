# GROK TOOL — Tạo ảnh & Video (độc lập)

Tool độc lập dùng tài khoản GROK (x.ai) để:
- 🎨 **Tạo ảnh** từ prompt
- 🎬 **Text → Video** (tạo video từ chữ)
- 🖼 **Image → Video** (tạo video từ ảnh)

Dùng cơ chế OAuth + api.x.ai chính thức (giống tool tham khảo) nên chạy được nhiều luồng, không bị chặn anti-bot.

---

## CÀI ĐẶT (chỉ làm 1 lần)

1. Cài **Python 3.10+** (nếu chưa có): https://www.python.org/downloads/ — nhớ tick "Add Python to PATH".
2. Bấm đúp **`CAI_DAT.bat`** — tự cài thư viện + trình duyệt. Chờ tới khi báo "HOÀN TẤT".

## CHẠY TOOL

Bấm đúp **`CHAY_TOOL.bat`** (hoặc mở terminal gõ `python main.py`).

## CÁCH DÙNG

### Lần đầu: đăng nhập GROK
1. Mở tab **⚙ Cài đặt** → bấm **"Mở Chrome đăng nhập GROK"**.
2. Cửa sổ Chrome hiện ra → đăng nhập tài khoản GROK (x.ai) của bạn.
3. Đăng nhập xong, **để nguyên cửa sổ Chrome đó** (đừng tắt). Tool sẽ dùng lại phiên này.

### Tạo ảnh / video
1. Chọn tab tương ứng (Tạo ảnh / Text→Video / Image→Video).
2. Nhập prompt (mỗi dòng 1 cái), chọn tỷ lệ / độ dài / thư mục lưu.
3. Bấm **▶ Tạo**.
4. Lần đầu chạy có thể hiện màn hình **cấp quyền** trong Chrome — tool tự bấm "Autoriser/Authorize". Nếu không tự bấm được, bạn **bấm tay** nút đó 1 lần. Sau đó GROK nhớ, các lần sau không hỏi lại.

### Kết quả
- Ảnh lưu trong: `downloads/grok_image/`
- Video lưu trong: `downloads/grok_video/`
- (Hoặc thư mục bạn tự chọn trong tool.)

---

## LƯU Ý

- **Tài khoản**: nên dùng tài khoản GROK trả phí (Super) để tạo được nhiều.
- **Số luồng**: mặc định 3 (giống tool tham khảo). Không nên để quá cao.
- Nếu báo "Không lấy được OAuth token": kiểm tra đã đăng nhập GROK trong Chrome chưa (tab Cài đặt).

## CẤU TRÚC FILE

| File | Vai trò |
|------|---------|
| `main.py` | Giao diện chính (chạy file này) |
| `grok_workers.py` | Luồng chạy nền (QThread) |
| `grok_workflow_*.py` | Điều phối tạo ảnh/video |
| `grok_api_*.py` | Gọi API GROK (OAuth + api.x.ai) |
| `grok_chrome_manager.py` | Quản lý Chrome |

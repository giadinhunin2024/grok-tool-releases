from __future__ import annotations

import os
import socket
import subprocess
import time
import asyncio
import json
from dataclasses import dataclass
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

from playwright.async_api import Browser, BrowserContext, Error, async_playwright

import sys

if getattr(sys, 'frozen', False):
    BASE_DIR = str(Path(sys.executable).resolve().parent)
else:
    BASE_DIR = str(Path(__file__).resolve().parent)


GROK_URL = "https://grok.com/"
GROK_CHROME_LANGUAGE = os.getenv("GROK_CHROME_LANGUAGE", "vi")
CDP_HOST = os.getenv("GROK_CDP_HOST", os.getenv("CDP_HOST", "127.0.0.1"))
CDP_PORT = int(os.getenv("GROK_CDP_PORT", os.getenv("CDP_PORT", "9223")))
PROFILE_NAME = os.getenv("GROK_PROFILE_NAME", os.getenv("PROFILE_NAME", "PROFILE_1"))
GROK_USER_DATA_ROOT = Path(
    os.getenv("GROK_CHROME_USER_DATA_ROOT", str(Path(BASE_DIR) / "chrome_user_data_grok"))
)

GROK_WORKFLOW_CHROME_EXTRA_ARGS = [
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-blink-features=AutomationControlled",
    "--window-size=1280,860",
]


def _win_hidden_kwargs() -> dict:
    if os.name != "nt":
        return {}
    try:
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        return {"startupinfo": si, "creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
    except Exception:
        return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}


def _find_chrome_exe() -> str:
    custom = os.getenv("CHROME_EXE_PATH")
    if custom and Path(custom).exists():
        return custom
    if sys.platform == "win32":
        candidates = [
            Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
            Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
            Path(os.getenv("LOCALAPPDATA", "")) / "Google" / "Chrome" / "Application" / "chrome.exe",
        ]
    elif sys.platform == "darwin":
        candidates = [
            Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
            Path(os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")),
        ]
    else:
        candidates = [
            Path("/usr/bin/google-chrome"),
            Path("/usr/bin/chrome"),
            Path("/usr/bin/chromium"),
            Path("/usr/bin/chromium-browser"),
        ]
    for p in candidates:
        if p.exists():
            return str(p)
    raise FileNotFoundError("Không tìm thấy Google Chrome. Hãy cài đặt Google Chrome hoặc set CHROME_EXE_PATH.")


def resolve_profile_dir(profile_name: str | None = None) -> Path:
    name = str(profile_name or PROFILE_NAME).strip() or "PROFILE_1"
    root = GROK_USER_DATA_ROOT
    root.mkdir(parents=True, exist_ok=True)
    return root / name


def _is_cdp_ready(host: str, port: int) -> bool:
    try:
        with urlopen(f"http://{host}:{int(port)}/json/version", timeout=1.5) as response:
            return int(response.status or 0) == 200
    except (URLError, OSError):
        return False
    except Exception:
        return False


def _can_bind(host: str, port: int) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, int(port)))
        return True
    except Exception:
        return False


def _pick_port(host: str, start_port: int, tries: int = 50) -> int:
    base = int(start_port or CDP_PORT)
    for p in range(base, base + int(tries or 1)):
        if _is_cdp_ready(host, p):
            continue
        if _can_bind(host, p):
            return p
    raise RuntimeError(f"Không tìm được port CDP trống từ {base}")


def _find_running_cdp_port_for_user_data(user_data_dir: Path) -> int | None:
    target = str(Path(user_data_dir).resolve())
    if os.name == "nt":
        target_win = target.lower().replace("/", "\\")
        try:
            proc = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-Command",
                    "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | Select-Object -ExpandProperty CommandLine",
                ],
                capture_output=True,
                text=True,
                check=False,
                **_win_hidden_kwargs(),
            )
            text = str(proc.stdout or "")
        except Exception:
            return None

        import re
        for line in text.splitlines():
            cmd = str(line or "").strip()
            if not cmd:
                continue
            low = cmd.lower().replace("/", "\\")
            if "--remote-debugging-port=" not in low or "--user-data-dir=" not in low:
                continue
            if target_win not in low:
                continue
            m = re.search(r"--remote-debugging-port=(\d+)", low)
            if not m:
                continue
            try:
                return int(m.group(1))
            except Exception:
                continue
    else:
        import re
        try:
            proc = subprocess.run(
                ["ps", "ax", "-o", "pid,args"],
                capture_output=True,
                text=True,
                check=False
            )
            stdout = str(proc.stdout or "")
            for line in stdout.splitlines():
                cmd = line.strip()
                if not cmd:
                    continue
                if "chrome" in cmd.lower() and "--remote-debugging-port=" in cmd and "--user-data-dir=" in cmd:
                    if target in cmd:
                        m = re.search(r"--remote-debugging-port=(\d+)", cmd)
                        if m:
                            return int(m.group(1))
        except Exception:
            pass
    return None


def _wait_cdp(host: str, port: int, timeout_seconds: int = 30) -> bool:
    deadline = time.time() + max(1, int(timeout_seconds or 1))
    while time.time() < deadline:
        if _is_cdp_ready(host, int(port)):
            return True
        time.sleep(0.35)
    return False


def _kill_chrome_for_user_data(user_data_dir: Path) -> None:
    target = str(Path(user_data_dir).resolve())
    if os.name == "nt":
        ps = "\n".join(
            [
                "$target = '" + target.replace("'", "''") + "'",
                "$procs = Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | Where-Object {",
                "  $_.CommandLine -and ($_.CommandLine -like '*--user-data-dir*') -and ($_.CommandLine -like ('*' + $target + '*'))",
                "}",
                "foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -ErrorAction SilentlyContinue } catch {} }",
                "Start-Sleep -Milliseconds 800",
                "foreach ($p in $procs) {",
                "  try { if (Get-Process -Id $p.ProcessId -ErrorAction SilentlyContinue) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue } } catch {}",
                "}",
            ]
        )
        try:
            subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
                **_win_hidden_kwargs(),
            )
        except Exception:
            pass
    else:
        try:
            proc = subprocess.run(
                ["ps", "ax", "-o", "pid,args"],
                capture_output=True,
                text=True,
                check=False
            )
            stdout = str(proc.stdout or "")
            for line in stdout.splitlines():
                line = line.strip()
                if not line:
                    continue
                parts = line.split(None, 1)
                if len(parts) < 2:
                    continue
                pid_str, cmd = parts
                if "chrome" in cmd.lower() and "--user-data-dir" in cmd and target in cmd:
                    try:
                        pid = int(pid_str)
                        os.kill(pid, 9)
                    except Exception:
                        pass
        except Exception:
            pass


def _bring_chrome_window_to_front(user_data_dir: Path) -> None:
    if os.name != "nt":
        return
    target = str(Path(user_data_dir).resolve())
    ps = "\n".join(
        [
            "$target = '" + target.replace("'", "''") + "'",
            "$procs = Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | Where-Object {",
            "  $_.CommandLine -and ($_.CommandLine -like '*--user-data-dir*') -and ($_.CommandLine -like ('*' + $target + '*'))",
            "}",
            "if (-not ('WinApi' -as [type])) {",
            "  Add-Type -TypeDefinition @\"",
            "using System;",
            "using System.Runtime.InteropServices;",
            "public static class WinApi {",
            "  [DllImport(\"user32.dll\")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);",
            "  [DllImport(\"user32.dll\")] public static extern bool SetForegroundWindow(IntPtr hWnd);",
            "  [DllImport(\"user32.dll\")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);",
            "}",
            "\"@ | Out-Null",
            "}",
            "$handled = $false",
            "foreach ($p in $procs) {",
            "  try {",
            "    $gp = Get-Process -Id $p.ProcessId -ErrorAction SilentlyContinue",
            "    if ($null -eq $gp) { continue }",
            "    $h = $gp.MainWindowHandle",
            "    if ($h -eq 0) { continue }",
            "    [WinApi]::ShowWindowAsync([IntPtr]$h, 9) | Out-Null",
            "    Start-Sleep -Milliseconds 120",
            "    [WinApi]::SetWindowPos([IntPtr]$h, [IntPtr]::Zero, 40, 40, 1280, 860, 0x0040) | Out-Null",
            "    [WinApi]::SetForegroundWindow([IntPtr]$h) | Out-Null",
            "    $handled = $true",
            "    break",
            "  } catch {}",
            "}",
            "if (-not $handled) {",
            "  try {",
            "    $shell = New-Object -ComObject WScript.Shell",
            "    $shell.AppActivate('Chrome') | Out-Null",
            "  } catch {}",
            "}",
        ]
    )
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            **_win_hidden_kwargs(),
        )
    except Exception:
        pass


def open_profile_chrome(profile_name: str | None = None, url: str = GROK_URL) -> dict:
    profile_dir = resolve_profile_dir(profile_name)
    profile_dir.mkdir(parents=True, exist_ok=True)
    chrome_exe = _find_chrome_exe()

    # KHÔNG dùng --remote-debugging-port để tránh bị x.ai phát hiện và chặn đăng nhập (permission_denied / 403)
    cmd = [
        chrome_exe,
        f"--user-data-dir={str(profile_dir)}",
        f"--lang={GROK_CHROME_LANGUAGE}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-sync",
        "--disable-blink-features=AutomationControlled",
        "--start-maximized",
        str(url or GROK_URL),
    ]
    subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return {"success": True, "profile_dir": str(profile_dir), "port": 0, "host": CDP_HOST}


def kill_profile_chrome(profile_path: str | Path) -> None:
    try:
        _kill_chrome_for_user_data(Path(profile_path))
    except Exception:
        pass


@dataclass
class ChromeSession:
    playwright: any
    browser: Browser
    context: BrowserContext
    user_data_dir: Path

    async def close(self, keep_chrome: bool = True) -> None:
        # keep_chrome=True: CHỈ ngắt kết nối Playwright, GIỮ Chrome chạy ẩn
        # -> lần chạy sau connect lại vào chính Chrome đó (đã login sẵn, không phải đăng nhập lại)
        if keep_chrome:
            # connect_over_cdp: chỉ stop playwright, KHÔNG đóng browser, KHÔNG kill chrome
            try:
                await asyncio.wait_for(self.playwright.stop(), timeout=2.5)
            except Exception:
                pass
            return
        # keep_chrome=False: đóng hẳn (chỉ dùng khi thật sự muốn tắt Chrome)
        try:
            await asyncio.wait_for(self.browser.close(), timeout=2.5)
        except Exception:
            pass
        try:
            await asyncio.wait_for(self.playwright.stop(), timeout=2.5)
        except Exception:
            pass
        try:
            kill_profile_chrome(self.user_data_dir)
        except Exception:
            pass


async def open_chrome_session(
    host: str,
    port: int,
    user_data_dir: Path,
    start_url: str = GROK_URL,
    cdp_wait_seconds: int = 30,
    offscreen: bool = True,
) -> ChromeSession:
    user_data_dir = Path(user_data_dir)
    user_data_dir.mkdir(parents=True, exist_ok=True)

    use_host = str(host or CDP_HOST).strip() or CDP_HOST
    use_port = int(port or CDP_PORT)
    running_port = _find_running_cdp_port_for_user_data(user_data_dir)
    if isinstance(running_port, int) and running_port > 0:
        use_port = running_port
    cdp_already_ready = _is_cdp_ready(use_host, use_port)
    if (not cdp_already_ready) and (not _can_bind(use_host, use_port)):
        use_port = _pick_port(use_host, use_port)
        cdp_already_ready = _is_cdp_ready(use_host, use_port)

    if not cdp_already_ready:
        try:
            kill_profile_chrome(user_data_dir)
        except Exception:
            pass
        chrome_exe = _find_chrome_exe()
        cmd = [
            chrome_exe,
            f"--remote-debugging-port={int(use_port)}",
            f"--remote-debugging-address={use_host}",
            f"--user-data-dir={str(user_data_dir)}",
            f"--lang={GROK_CHROME_LANGUAGE}",
            "--remote-allow-origins=*",
            *GROK_WORKFLOW_CHROME_EXTRA_ARGS,
        ]
        if offscreen:
            cmd.extend([
                "--window-position=-32000,-32000",
                "--start-minimized",
            ])
        cmd.append(str(start_url or GROK_URL))
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    if not _wait_cdp(use_host, use_port, timeout_seconds=cdp_wait_seconds):
        raise RuntimeError(f"Chrome CDP chưa sẵn sàng tại {use_host}:{use_port}")

    pw = await async_playwright().start()
    browser: Browser | None = None
    last_exc: Exception | None = None
    for _ in range(5):
        try:
            browser = await pw.chromium.connect_over_cdp(f"http://{use_host}:{int(use_port)}")
            break
        except Error as exc:
            last_exc = exc
            await __import__("asyncio").sleep(0.35)
    if browser is None:
        try:
            await pw.stop()
        except Exception:
            pass
        raise RuntimeError(f"Không kết nối được CDP {use_host}:{use_port}: {last_exc}")

    context = browser.contexts[0] if browser.contexts else await browser.new_context()
    try:
        await context.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            window.chrome = { runtime: {} };
            try {
                const clean = (obj, prop) => {
                    Object.defineProperty(obj, prop, {
                        get: () => undefined,
                        set: () => {},
                        configurable: true
                    });
                };
                clean(window, 'cdc_adoQy278328sAdwfcZLmcfl_Array');
                clean(window, 'cdc_adoQy278328sAdwfcZLmcfl_Promise');
                clean(window, 'cdc_adoQy278328sAdwfcZLmcfl_Symbol');
            } catch (e) {}
        """)
    except Exception:
        pass
    return ChromeSession(playwright=pw, browser=browser, context=context, user_data_dir=user_data_dir)


async def update_profile_usage_via_dom(page_obj, cache_path: Path, profile_name: str, on_info=None) -> None:
    """Mở menu Cài đặt -> Sử dụng để tự động lấy phần trăm hạn mức và lưu vào grok_cache.json."""
    try:
        # 1. Điều hướng thẳng tới link cài đặt Sử dụng để tự động mở popup
        if on_info: on_info("🔎 Đang mở trực tiếp mục Cài đặt Hạn mức sử dụng...")
        try:
            await page_obj.goto("https://grok.com/?_s=usage", wait_until="networkidle", timeout=15000)
        except Exception:
            try:
                await page_obj.goto("https://grok.com/?_s=usage", wait_until="domcontentloaded", timeout=15000)
            except Exception:
                pass
        await asyncio.sleep(3.0)

        # Kiểm tra xem popup Settings có hiện ra không. Nếu không, thử bấm thủ công
        settings_dialog = page_obj.locator("[role='dialog'], *:has-text('Sử dụng'), *:has-text('Usage')")
        dialog_visible = False
        try:
            await settings_dialog.first.wait_for(state="visible", timeout=3000)
            dialog_visible = True
        except Exception:
            pass

        if not dialog_visible:
            # Fallback: Click Profile Button ở góc dưới bên trái
            if on_info: on_info("🔎 Không tự động mở được popup, đang thử bấm nút Profile...")
            profile_btn = page_obj.locator("button:has-text('@'), button:has-text('Jason Taylor'), button:has-text('SherreeNaple')").first
            try:
                await profile_btn.wait_for(state="visible", timeout=5000)
            except Exception:
                profile_btn = page_obj.locator("button[data-slot='button']").last
                try:
                    await profile_btn.wait_for(state="visible", timeout=3000)
                except Exception:
                    raise RuntimeError("Không tìm thấy nút Profile trên giao diện!")
            
            await profile_btn.click()
            await asyncio.sleep(1.5)
            
            # Click Settings option
            settings_btn = page_obj.locator("[role='menuitem']:has-text('Cài đặt'), [role='menuitem']:has-text('Settings'), [role='menuitem']:has-text('cài đặt'), [role='menuitem']:has-text('settings')").first
            try:
                await settings_btn.wait_for(state="visible", timeout=3000)
            except Exception:
                settings_btn = page_obj.locator("*:has-text('Cài đặt'), *:has-text('Settings')").last
                await settings_btn.wait_for(state="visible", timeout=3000)
            await settings_btn.click()
            await asyncio.sleep(2.0)
            
            # Click Usage tab
            usage_tab = page_obj.locator("button:has-text('Sử dụng'), button:has-text('Usage'), *:has-text('Sử dụng'), *:has-text('Usage')").last
            try:
                await usage_tab.click()
            except Exception:
                # Đóng settings
                close_btn = page_obj.locator("button[aria-label='Close'], button[aria-label='Đóng'], svg[aria-label='Close']").first
                if await close_btn.is_visible():
                    await close_btn.click()
                raise RuntimeError("Không tìm thấy tab Sử dụng (Usage) trong cài đặt!")
            await asyncio.sleep(2.0)
        
        # 4. Bóc tách dữ liệu sử dụng thuật toán leaf-most
        if on_info: on_info("📊 Đang đọc phần trăm và thời gian reset hạn mức...")
        extracted = await page_obj.evaluate("""() => {
            try {
                const textElements = Array.from(document.querySelectorAll('*'));
                
                const percentEls = textElements.filter(el => {
                    const text = (el.innerText || '').trim();
                    return text && text.includes('%') && text.length < 100;
                });
                
                const resetEls = textElements.filter(el => {
                    const text = (el.innerText || '').trim();
                    const t_low = text.toLowerCase();
                    return text && (t_low.includes('đặt lại') || t_low.includes('reset') || t_low.includes('dat lai')) && text.length < 100;
                });
                
                const getLeafMost = (els) => {
                    return els.filter(el => {
                        return !els.some(child => child !== el && el.contains(child));
                    }).map(el => (el.innerText || '').trim());
                };
                
                return {
                    usage: getLeafMost(percentEls),
                    reset: getLeafMost(resetEls)
                };
            } catch (e) {
                return null;
            }
        }""")
        
        # 5. Đóng settings
        try:
            close_btn = page_obj.locator("button[aria-label='Close'], button[aria-label='Đóng'], svg[aria-label='Close']").first
            if await close_btn.is_visible():
                await close_btn.click()
        except Exception:
            pass
            
        # 6. Cập nhật cache
        if extracted and ('usage' in extracted or 'reset' in extracted):
            usage_str = extracted['usage'][0] if (extracted.get('usage') and len(extracted['usage']) > 0) else None
            reset_str = extracted['reset'][0] if (extracted.get('reset') and len(extracted['reset']) > 0) else None
            
            if usage_str:
                cache_data = {}
                if cache_path.is_file():
                    try:
                        with open(cache_path, "r", encoding="utf-8") as f:
                            cache_data = json.load(f)
                    except Exception:
                        pass
                
                if "profiles" not in cache_data:
                    cache_data["profiles"] = {}
                if profile_name not in cache_data["profiles"]:
                    cache_data["profiles"][profile_name] = {}
                
                cache_data["profiles"][profile_name]["usage_percent"] = usage_str
                if reset_str:
                    cache_data["profiles"][profile_name]["usage_reset"] = reset_str
                
                with open(cache_path, "w", encoding="utf-8") as f:
                    json.dump(cache_data, f, indent=2, ensure_ascii=False)
                    
                if on_info:
                    msg = f"📊 Hạn mức đã sử dụng của {profile_name}: {usage_str}"
                    if reset_str:
                        msg += f" ({reset_str})"
                    on_info(msg)
            else:
                raise RuntimeError("Quét thành công giao diện nhưng không tìm thấy chữ số % hạn mức nào!")
        else:
            raise RuntimeError("Không thể bóc tách dữ liệu từ trang Cài đặt!")
    except Exception as e:
        try:
            # Chụp ảnh màn hình debug lỗi lưu vào thư mục chứa cache
            await page_obj.screenshot(path=str(cache_path.parent / "debug_usage_error.png"))
            if on_info:
                on_info("📸 Đã chụp ảnh màn hình debug lưu tại debug_usage_error.png")
        except Exception:
            pass
        raise e

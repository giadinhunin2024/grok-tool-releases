#!/bin/bash
# CHAY_TOOL.command - Khởi chạy Grok Tool trên macOS

# Chuyển vào thư mục chứa script
cd "$(dirname "$0")"

echo "========================================================="
echo "  GROK TOOL - Tạo ảnh & Video (macOS)"
echo "========================================================="
echo ""

# Chạy ứng dụng bằng Python 3
python3 main.py

if [ $? -ne 0 ]; then
  echo ""
  echo "[Lỗi] Tool đóng bất thường. Vui lòng kiểm tra:"
  echo "  1. Bạn đã chạy cài đặt môi trường chưa? (Chạy file CAI_DAT.command)"
  echo "  2. Đảm bảo Python 3 đã cài đặt đúng."
  read -p "Nhấn Enter để đóng..."
fi

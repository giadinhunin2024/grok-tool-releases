from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
from typing import Any


GROK_BASE = "https://grok.com"
ENDPOINT_CONVO_NEW = f"{GROK_BASE}/rest/app-chat/conversations/new"


@dataclass
class CreateImageConfig:
    aspect_ratio: str = "1:1"
    image_count: int = 2  # số ảnh mỗi prompt (Grok mặc định 2)

    def as_dict(self) -> dict[str, Any]:
        return {
            "aspectRatio": self.aspect_ratio,
            "imageCount": int(self.image_count),
        }


def _build_image_body(prompt: str, aspect_ratio: str, image_count: int) -> dict:
    """Body tạo ảnh - port chính xác từ ImageService.buildBody tool ngon."""
    return {
        "temporary": True,
        "modelName": "grok-3",
        "message": prompt,
        "fileAttachments": [],
        "imageAttachments": [],
        "disableSearch": False,
        "enableImageGeneration": True,
        "returnImageBytes": False,
        "returnRawGrokInXaiRequest": False,
        "enableImageStreaming": True,
        "imageGenerationCount": int(image_count),
        "forceConcise": False,
        "toolOverrides": {"imageGen": True},
        "enableSideBySide": True,
        "sendFinalMetadata": True,
        "isReasoning": False,
        "disableTextFollowUps": True,
        "deviceEnvInfo": {
            "darkModeEnabled": False,
            "devicePixelRatio": 2,
            "screenWidth": 1920,
            "screenHeight": 1080,
            "viewportWidth": 1920,
            "viewportHeight": 1080,
        },
        "responseMetadata": {
            "modelConfigOverride": {
                "modelMap": {
                    "imageEditModelConfig": {
                        "imageReferences": [],
                        "aspectRatio": aspect_ratio,
                    },
                    "imageEditModel": "imagine",
                },
            },
        },
        "disableMemory": False,
        "forceSideBySide": False,
    }


def _generate_image_websocket_sync(ws_url, header_list, prompt, aspect_ratio, timeout_seconds):
    import json
    import uuid
    import time
    import websocket

    out = {
        "status": 0,
        "imageUrls": [],
        "imageBase64": [],
        "title": "",
        "error": ""
    }

    try:
        ws = websocket.create_connection(ws_url, header=header_list, timeout=timeout_seconds)
        
        request_id = str(uuid.uuid4())
        msg = {
            "type": "conversation.item.create",
            "timestamp": int(time.time() * 1000),
            "item": {
                "type": "message",
                "content": [
                    {
                        "requestId": request_id,
                        "text": prompt,
                        "type": "input_text",
                        "properties": {
                            "section_count": 0,
                            "is_kids_mode": False,
                            "enable_nsfw": True,
                            "skip_upsampler": False,
                            "enable_side_by_side": True,
                            "is_initial": False,
                            "aspect_ratio": aspect_ratio,
                        },
                    }
                ],
            },
        }
        ws.send(json.dumps(msg))
        
        deadline = time.time() + timeout_seconds
        completed = False
        
        while time.time() < deadline:
            try:
                ws.settimeout(2.0)
                data = ws.recv()
            except websocket.WebSocketTimeoutException:
                if completed and (out["imageUrls"] or out["imageBase64"]):
                    break
                continue
            except Exception:
                break
                
            if not data:
                break
                
            try:
                msg_obj = json.loads(data)
                mtype = msg_obj.get("type")
                
                if mtype == "json":
                    returned_prompt = msg_obj.get("prompt") or msg_obj.get("full_prompt")
                    if returned_prompt:
                        p_ret = returned_prompt.strip().lower()
                        p_mine = prompt.strip().lower()
                        if p_mine not in p_ret and p_ret not in p_mine:
                            continue

                    pct = msg_obj.get("percentage_complete") or 0
                    status = msg_obj.get("current_status")
                    if status == "completed" and pct >= 100:
                        completed = True
                    if msg_obj.get("full_prompt") and not out["title"]:
                        out["title"] = msg_obj["full_prompt"]
                    if msg_obj.get("moderated") is True:
                        out["error"] = "Content moderated"
                        break
                        
                elif mtype == "image":
                    returned_prompt = msg_obj.get("prompt") or msg_obj.get("full_prompt")
                    if returned_prompt:
                        p_ret = returned_prompt.strip().lower()
                        p_mine = prompt.strip().lower()
                        if p_mine not in p_ret and p_ret not in p_mine:
                            continue

                    if msg_obj.get("blob"):
                        blob_str = msg_obj["blob"]
                        try:
                            import base64 as _pyb64
                            data_to_decode = blob_str
                            if data_to_decode.startswith("data:image/"):
                                data_to_decode = data_to_decode.split(",")[1]
                            decoded_len = len(_pyb64.b64decode(data_to_decode))
                            if decoded_len >= 50 * 1024:
                                out["imageBase64"].append(blob_str)
                        except Exception:
                            pass
                    if msg_obj.get("url"):
                        out["imageUrls"].append(msg_obj["url"])
                    if msg_obj.get("full_prompt") and not out["title"]:
                        out["title"] = msg_obj["full_prompt"]
                        
                elif mtype == "error":
                    returned_prompt = msg_obj.get("prompt") or msg_obj.get("full_prompt")
                    if returned_prompt:
                        p_ret = returned_prompt.strip().lower()
                        p_mine = prompt.strip().lower()
                        if p_mine not in p_ret and p_ret not in p_mine:
                            continue
                            
                    out["error"] = msg_obj.get("message") or msg_obj.get("error") or "WebSocket error"
                    break
            except Exception:
                pass
                
            if completed and (out["imageUrls"] or out["imageBase64"]):
                time.sleep(1.0)
                break
                
        try:
            ws.close()
        except Exception:
            pass
            
        out["status"] = 200
        out["imageUrls"] = list(dict.fromkeys(out["imageUrls"]))
        out["imageBase64"] = list(dict.fromkeys(out["imageBase64"]))
        
    except Exception as e:
        out["error"] = f"WebSocket error: {str(e)}"
        
    return out


async def generate_image_in_page(page, prompt, statsig_headers, cfg, timeout_seconds=180, job_index=0):
    """Gửi yêu cầu tạo ảnh qua WebSockets sử dụng thư viện websocket-client của Python chạy trong thread pool,
    truyền đầy đủ cookies và x-statsig-id lấy từ trình duyệt.
    """
    import asyncio
    
    d = cfg.as_dict()
    aspect_ratio = d.get("aspectRatio") or "1:1"
    
    cookies = await page.context.cookies()
    cookie_str = "; ".join([f"{c['name']}={c['value']}" for c in cookies])
    
    headers = {}
    if statsig_headers:
        for k, v in statsig_headers.items():
            k_lower = k.lower()
            if k_lower not in ["host", "content-length", "content-type", "accept"]:
                headers[k] = v
                
    headers["cookie"] = cookie_str
    headers["origin"] = "https://grok.com"
    headers["referer"] = "https://grok.com/imagine"
    
    header_list = [f"{k}: {v}" for k, v in headers.items()]
    ws_url = "wss://grok.com/ws/imagine/listen"
    
    result = await asyncio.to_thread(
        _generate_image_websocket_sync,
        ws_url,
        header_list,
        prompt,
        aspect_ratio,
        timeout_seconds
    )
    return result


ASSETS_BASE_URL = "https://assets.grok.com/"


async def download_image(context, url: str, out_path: Path, timeout_ms: int, page=None) -> bool:
    """Tải ảnh từ URL. imageUrl từ Grok thường là đường dẫn TƯƠNG ĐỐI
    (vd: users/.../generated/.../image.jpg) -> phải ghép assets.grok.com.
    Ưu tiên fetch trong browser (cookie thật)."""
    target = (url or "").strip()
    if not target:
        return False
    # Ghép base URL nếu là đường dẫn tương đối
    if not (target.startswith("http://") or target.startswith("https://")):
        target = ASSETS_BASE_URL + target.lstrip("/")

    # Tải trong browser bằng cookie thật
    if page is not None:
        try:
            arr = await page.evaluate(
                """async (u) => {
                    try {
                        const r = await fetch(u, { credentials: 'include' });
                        if (!r.ok) return { ok:false, status: r.status };
                        const ab = await (await r.blob()).arrayBuffer();
                        return { ok:true, data: Array.from(new Uint8Array(ab)) };
                    } catch (e) { return { ok:false, error: String(e) }; }
                }""",
                target,
            )
            if isinstance(arr, dict) and arr.get("ok") and arr.get("data"):
                body = bytes(bytearray(arr["data"]))
                if len(body) >= 50 * 1024:
                    out_path.write_bytes(body)
                    return True
        except Exception:
            pass

    try:
        resp = await context.request.get(target, timeout=timeout_ms)
        if resp.ok:
            body = await resp.body()
            if len(body) >= 50 * 1024:
                out_path.write_bytes(body)
                return True
    except Exception:
        pass
    return False


def save_base64_image(b64_data: str, out_path_no_ext: Path, index: int) -> Path | None:
    """Lưu ảnh base64 (data URI hoặc raw) thành file. Trả về path đã lưu."""
    import base64 as _b64
    data = b64_data
    ext = "png"
    if data.startswith("data:image/"):
        import re as _re
        m = _re.match(r"^data:image/(png|jpeg|jpg|webp);base64,", data)
        if m:
            ext = "jpg" if m.group(1) == "jpeg" else m.group(1)
            data = data[m.end():]
    try:
        buf = _b64.b64decode(data)
    except Exception:
        return None
    if len(buf) < 50 * 1024:
        return None
    out = out_path_no_ext.with_name(f"{out_path_no_ext.name}_i{index}.{ext}")
    out.write_bytes(buf)
    return out


def _generate_ref_image_websocket_sync(ws_url, header_list, prompt, aspect_ratio, file_metadata_ids, timeout_seconds):
    """Kết nối WebSocket tới Grok Imagine và gửi request tạo ảnh với file đính kèm."""
    import json
    import uuid
    import time
    import websocket

    out = {"status": 0, "imageUrls": [], "imageBase64": [], "title": "", "error": ""}

    try:
        ws = websocket.create_connection(ws_url, header=header_list, timeout=timeout_seconds)

        request_id = str(uuid.uuid4())

        # Thử nhiều format để tìm cái Grok chấp nhận
        # Format 1: file_metadata_ids trong properties của input_text
        msg = {
            "type": "conversation.item.create",
            "timestamp": int(time.time() * 1000),
            "item": {
                "type": "message",
                "content": [
                    {
                        "requestId": request_id,
                        "text": prompt,
                        "type": "input_text",
                        "properties": {
                            "section_count": 0,
                            "is_kids_mode": False,
                            "enable_nsfw": True,
                            "skip_upsampler": False,
                            "enable_side_by_side": True,
                            "is_initial": False,
                            "aspect_ratio": aspect_ratio,
                            "file_metadata_ids": file_metadata_ids,
                        },
                    }
                ],
            },
        }
        ws.send(json.dumps(msg))
        print(f"[WS-REF] Sent msg with {len(file_metadata_ids)} file(s), prompt={prompt[:50]}")

        deadline = time.time() + timeout_seconds
        completed = False
        msg_count = 0

        while time.time() < deadline:
            try:
                ws.settimeout(2.0)
                data = ws.recv()
            except websocket.WebSocketTimeoutException:
                if completed and (out["imageUrls"] or out["imageBase64"]):
                    break
                continue
            except Exception as e:
                print(f"[WS-REF] recv exception: {e}")
                break

            if not data:
                break

            try:
                msg_obj = json.loads(data)
                mtype = msg_obj.get("type")
                msg_count += 1
                # Debug: log first 5 messages
                if msg_count <= 5:
                    print(f"[WS-REF] msg #{msg_count} type={mtype!r} keys={list(msg_obj.keys())}")
                    if mtype == "error" or mtype not in ("json", "image"):
                        print(f"[WS-REF] full msg: {json.dumps(msg_obj)[:300]}")

                if mtype == "json":
                    pct = msg_obj.get("percentage_complete") or 0
                    status = msg_obj.get("current_status")
                    if status == "completed" and pct >= 100:
                        completed = True
                    if msg_obj.get("full_prompt") and not out["title"]:
                        out["title"] = msg_obj["full_prompt"]
                    if msg_obj.get("moderated") is True:
                        out["error"] = "Content moderated"
                        break

                elif mtype == "image":
                    if msg_obj.get("blob"):
                        blob_str = msg_obj["blob"]
                        try:
                            import base64 as _b64
                            data_to_decode = blob_str
                            if data_to_decode.startswith("data:image/"):
                                data_to_decode = data_to_decode.split(",")[1]
                            decoded_len = len(_b64.b64decode(data_to_decode))
                            if decoded_len >= 50 * 1024:
                                out["imageBase64"].append(blob_str)
                        except Exception:
                            pass
                    if msg_obj.get("url"):
                        out["imageUrls"].append(msg_obj["url"])
                    if msg_obj.get("full_prompt") and not out["title"]:
                        out["title"] = msg_obj["full_prompt"]

                elif mtype == "error":
                    err_msg = msg_obj.get("message") or msg_obj.get("error") or ""
                    print(f"[WS-REF] error from server: {json.dumps(msg_obj)[:300]}")
                    out["error"] = err_msg or "WebSocket server error"
                    break

                else:
                    # Unknown type - log it
                    print(f"[WS-REF] unknown msg type: {mtype!r}, data={json.dumps(msg_obj)[:200]}")

            except Exception as e:
                print(f"[WS-REF] parse error: {e}, raw={str(data)[:100]}")

            if completed and (out["imageUrls"] or out["imageBase64"]):
                time.sleep(1.0)
                break

        print(f"[WS-REF] done: {msg_count} msgs, urls={len(out['imageUrls'])}, b64={len(out['imageBase64'])}, err={out['error']!r}")

        try:
            ws.close()
        except Exception:
            pass

        out["status"] = 200
        out["imageUrls"] = list(dict.fromkeys(out["imageUrls"]))
        out["imageBase64"] = list(dict.fromkeys(out["imageBase64"]))

    except Exception as e:
        out["error"] = f"WebSocket error: {str(e)}"
        print(f"[WS-REF] outer exception: {e}")

    return out


async def generate_ref_image_in_page(page, prompt, ref_image_paths, statsig_headers, cfg, timeout_seconds=180):
    """Upload ảnh tham chiếu qua REST (credentials browser), rồi generate qua WebSocket
    (cùng cơ chế với generate_image_in_page đang hoạt động).
    Grok cho phép WebSocket nhưng block REST conversations/new khi phát hiện automation.
    """
    import base64
    import mimetypes
    import uuid
    import json
    from pathlib import Path

    # 1. Đọc ảnh thành base64
    ref_files = []
    for path_str in ref_image_paths:
        p = Path(path_str)
        if not p.exists():
            continue
        with open(p, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")
        mime, _ = mimetypes.guess_type(str(p))
        mime = mime or "image/jpeg"
        ref_files.append({
            "name": f"{uuid.uuid4()}.{mime.split('/')[-1]}",
            "mimeType": mime,
            "b64": b64,
        })

    if not ref_files:
        return {"status": 0, "error": "Không tìm thấy ảnh tham chiếu", "imageUrls": [], "imageBase64": []}

    # 2. Statsig headers cho upload
    extra_headers = {}
    for k, v in (statsig_headers or {}).items():
        kl = k.lower()
        if kl.startswith("x-") or "statsig" in kl:
            extra_headers[k] = v

    d = cfg.as_dict()
    aspect_ratio = d.get("aspectRatio") or "1:1"

    # 3. Navigate sang /imagine để Referer đúng
    try:
        if "grok.com/imagine" not in (page.url or ""):
            await page.goto("https://grok.com/imagine", wait_until="domcontentloaded", timeout=15000)
    except Exception:
        pass

    # 4. Upload ảnh qua JS fetch (REST upload-file - hoạt động tốt)
    UPLOAD_JS = r"""
async (args) => {
    const { refFiles, extraHeaders } = args;
    const now = Date.now().toString();
    const fileMetadataIds = [];
    const h = { 'content-type': 'application/json' };
    for (const [k, v] of Object.entries(extraHeaders || {})) {
        h[k] = k.toLowerCase() === 'x-statsig-client-time' ? now : v;
    }
    for (const ref of refFiles) {
        const ctrl = new AbortController();
        const tid = setTimeout(() => ctrl.abort(), 60000);
        try {
            const r = await fetch('https://grok.com/rest/app-chat/upload-file', {
                method: 'POST',
                headers: h,
                credentials: 'include',
                body: JSON.stringify({
                    fileName: ref.name,
                    fileMimeType: ref.mimeType,
                    content: ref.b64,
                    fileSource: 'IMAGINE_SELF_UPLOAD_FILE_SOURCE',
                }),
                signal: ctrl.signal,
            });
            clearTimeout(tid);
            if (!r.ok) {
                const t = await r.text();
                return { ok: false, error: 'upload HTTP ' + r.status + ': ' + t.slice(0, 200), fileMetadataIds: [] };
            }
            const data = await r.json();
            const mid = data.fileMetadataId || data.metadataId || (data.data && data.data.fileMetadataId);
            if (mid) fileMetadataIds.push(mid);
        } catch (e) {
            clearTimeout(tid);
            return { ok: false, error: 'upload exception: ' + e.message, fileMetadataIds: [] };
        }
    }
    return { ok: fileMetadataIds.length > 0, fileMetadataIds };
}
"""
    try:
        upload_result = await page.evaluate(UPLOAD_JS, {
            "refFiles": ref_files,
            "extraHeaders": extra_headers,
        })
    except Exception as e:
        return {"status": 0, "error": f"Upload lỗi: {e}", "imageUrls": [], "imageBase64": []}

    if not upload_result or not upload_result.get("ok"):
        err = (upload_result or {}).get("error", "upload thất bại")
        return {"status": 0, "error": err, "imageUrls": [], "imageBase64": []}

    file_metadata_ids = upload_result.get("fileMetadataIds", [])
    if not file_metadata_ids:
        return {"status": 0, "error": "Upload không trả về fileMetadataId", "imageUrls": [], "imageBase64": []}

    # 5. Generate qua WebSocket (cùng cơ chế với generate_image_in_page)
    cookies = await page.context.cookies()
    cookie_str = "; ".join([f"{c['name']}={c['value']}" for c in cookies])

    ws_headers = {}
    for k, v in (statsig_headers or {}).items():
        k_lower = k.lower()
        if k_lower not in ["host", "content-length", "content-type", "accept"]:
            ws_headers[k] = v
    ws_headers["cookie"] = cookie_str
    ws_headers["origin"] = "https://grok.com"
    ws_headers["referer"] = "https://grok.com/imagine"

    header_list = [f"{k}: {v}" for k, v in ws_headers.items()]
    ws_url = "wss://grok.com/ws/imagine/listen"

    result = await asyncio.to_thread(
        _generate_ref_image_websocket_sync,
        ws_url,
        header_list,
        prompt,
        aspect_ratio,
        file_metadata_ids,
        timeout_seconds,
    )
    return result

async def generate_ref_image_via_api(prompt: str, ref_image_paths: list[str], api_token: str, cfg, timeout_seconds=180) -> dict:
    """Ghép ảnh tham chiếu sử dụng official developer API (api.x.ai/v1/images/edits).
    Hoàn toàn bằng Python, dùng Authorization Bearer token, không lo bot detection.
    """
    import base64
    import mimetypes
    import requests
    from pathlib import Path
    
    # 1. Đọc và chuyển đổi các ảnh ref thành base64 data URIs
    images_payload = []
    for path_str in ref_image_paths:
        p = Path(path_str)
        if p.exists():
            with open(p, "rb") as f:
                b64 = base64.b64encode(f.read()).decode("utf-8")
            mime, _ = mimetypes.guess_type(str(p))
            mime = mime or "image/jpeg"
            data_uri = f"data:{mime};base64,{b64}"
            images_payload.append({
                "url": data_uri,
                "type": "image_url"
            })
            
    if not images_payload:
        return {"status": 0, "error": "Không tìm thấy ảnh tham chiếu nào", "imageUrls": [], "imageBase64": []}
        
    # 2. Xây dựng request body cho /v1/images/edits
    d = cfg.as_dict()
    aspect_ratio = d.get("aspectRatio") or "1:1"
    
    body = {
        "model": "grok-imagine-image-quality",
        "prompt": prompt,
        "images": images_payload,
        "aspect_ratio": aspect_ratio,
        "n": 2, # Tạo 2 ảnh để lựa chọn
    }
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_token}"
    }
    
    out = {"status": 0, "imageUrls": [], "imageBase64": [], "title": "", "error": ""}
    
    try:
        api_url = "https://api.x.ai/v1/images/edits"
        resp = requests.post(api_url, headers=headers, json=body, timeout=timeout_seconds)
        out["status"] = resp.status_code
        if resp.status_code != 200:
            out["error"] = f"API HTTP {resp.status_code}: {resp.text[:200]}"
            return out
            
        data = resp.json()
        if "data" in data and isinstance(data["data"], list):
            for item in data["data"]:
                if isinstance(item, dict) and item.get("url"):
                    out["imageUrls"].append(item["url"])
                if isinstance(item, dict) and item.get("b64_json"):
                    out["imageBase64"].append(item["b64_json"])
                    
    except Exception as e:
        out["error"] = f"Yêu cầu API thất bại: {e}"
        
    return out


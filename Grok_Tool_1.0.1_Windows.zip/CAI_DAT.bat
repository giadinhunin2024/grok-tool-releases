@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   CAI DAT THU VIEN CHO GROK TOOL
echo ============================================
echo.
echo [1/2] Cai PyQt6 va Playwright...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo.
echo [2/2] Cai trinh duyet Chromium cho Playwright...
python -m playwright install chromium
echo.
echo ============================================
echo   HOAN TAT! Bay gio chay: CHAY_TOOL.bat
echo ============================================
pause

@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   GROK TOOL - Tao anh ^& Video
echo ============================================
echo.
python main.py
if errorlevel 1 (
  echo.
  echo [Loi] Tool dong bat thuong. Kiem tra:
  echo   1. Da cai Python chua? ^(python --version^)
  echo   2. Da cai thu vien chua? Chay: CAI_DAT.bat
  pause
)
